\qecho '<P><A class=awr name=21></A>'
\qecho '<H2 class=awr>Версия, Хост, Инстанс, Базы Данных</H2>'

\qecho '<A class=awr_ital>Скрипт VERS_HOST_INST_DBS.sql</A>'
\qecho '<p></p>'

SELECT version()              as "Версия",
       :'SERVER_VERSION_NAME' as "Версия сервера",
       :'SERVER_VERSION_NUM'  as "Номер версии";

\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Параметры подключения к инстансу</H4>'
\qecho '<p></p>'

SELECT current_user                                                                                                 as "USER"
       ,pg_backend_pid()                                                                                             as "backend_pid"
        --,:'HOST'               as "Хост"
       ,current_setting('cluster_name') AS "cluster_name"
       ,inet_server_addr()
       ,inet_server_port()                                                                                           as "Порт",
       case
           when pg_is_in_recovery() then 'Standby/Reader DB (Read Only)'
           else 'Primary/writer DB (Read write)' end                                                                as standby_mode,
       current_database()                                                                                           as "База данных",
       current_schema                                                                                               as "Текущая схема",
       current_schemas(true)                                                                                        as "Путь поиска",
       to_char(pg_postmaster_start_time(), 'YY-MM-DD HH24:MI:SS')                                                   AS "Старт инстанса",
       current_timestamp - pg_postmaster_start_time()                                                               as "UP_TIME",
       --pg_current_logfile()  as "Путь к текущему журналу сообщений",
       setting                                                                                                      AS block_size
FROM pg_settings
WHERE name = 'block_size'
;

/*
select POSITION('port=' in setting),
       POSITION('host=' in setting),
       substring(setting from POSITION('host=' in setting) for
                 (POSITION('port=' in setting) - POSITION('host=' in setting) ))
FROM pg_settings
WHERE name = 'primary_conninfo';
*/


\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Строка подключения к инстансу</H4>'
\qecho '<p></p>'

select * -- setting
FROM pg_settings
WHERE name = 'primary_conninfo';

\qecho '<p></p>'

-- Время старта сервера
SELECT pg_postmaster_start_time() AS server_start_time;

\qecho '<p></p>'
select pg_current_logfile() as "Путь к текущему журналу сообщений";
\qecho '<p></p>'


-- Cуммарный размер всех БД инстанса
select count(*) as                                    "Всего баз данных на инстансе"
     , pg_size_pretty(sum(pg_database_size(datname))) ALL_DBS_SIZE
     --   , sum(pg_database_size(datname))              AS  dbs_size_bytes
from pg_database;

--\qecho 'dbs_size_bytes:' :dbs_size_bytes

\qecho '<p></p>'

-- Размер используемых табличных пространств
SELECT ts.spcname                              "Tablespace",
       pg_size_pretty(pg_tablespace_size(oid)) "Размер"
FROM pg_tablespace ts;

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Схемы по количеству объектов в них</H4>'
\qecho '<p></p>'

select n.nspname as schema_name,
       count(*)  as object_count
from pg_catalog.pg_class c
         lEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
GROUP BY n.nspname
order by 2 desc;

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Количество типов оъектов в схемах</H4>'
\qecho '<p></p>'

SELECT n.nspname as schema_name
     , CASE c.relkind
           WHEN 'r' THEN 'table'
           WHEN 'v' THEN 'view'
           WHEN 'i' THEN 'index'
           WHEN 'S' THEN 'sequence'
           WHEN 't' THEN 'TOAST table'
           WHEN 'm' THEN 'materialized view'
           WHEN 'c' THEN 'composite type'
           WHEN 'f' THEN 'foreign table'
           WHEN 'p' THEN 'partitioned table'
           WHEN 'I' THEN 'partitioned index'
    END          as object_type
     , count(1)  as object_count
FROM pg_catalog.pg_class c
         LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind IN ('r', 'v', 'i', 'S', 's')
GROUP BY n.nspname,
         CASE c.relkind
             WHEN 'r' THEN 'table'
             WHEN 'v' THEN 'view'
             WHEN 'i' THEN 'index'
             WHEN 'S' THEN 'sequence'
             WHEN 't' THEN 'TOAST table'
             WHEN 'm' THEN 'materialized view'
             WHEN 'c' THEN 'composite type'
             WHEN 'f' THEN 'foreign table'
             WHEN 'p' THEN 'partitioned table'
             WHEN 'I' THEN 'partitioned index'
             END
ORDER BY n.nspname,
         CASE c.relkind
             WHEN 'r' THEN 'table'
             WHEN 'v' THEN 'view'
             WHEN 'i' THEN 'index'
             WHEN 'S' THEN 'sequence'
             WHEN 't' THEN 'TOAST table'
             WHEN 'm' THEN 'materialized view'
             WHEN 'c' THEN 'composite type'
             WHEN 'f' THEN 'foreign table'
             WHEN 'p' THEN 'partitioned table'
             WHEN 'I' THEN 'partitioned index'
             END;
/*
select datname                                   as "БД",
       pg_size_pretty(pg_database_size(datname)) as "Размер"
       --,pg_database_size(datname) db_size_bytes
from pg_database
order by pg_database_size(datname) desc;
*/

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Базы Данных инстанса</H4>'

select db.oid
     , db.datname
     , pa.rolname
     , pg_encoding_to_char(db.encoding) as "Кодировка символов"
     , datcollate                       as "LC_COLLATE"
     , datctype                         as "LC_CTYPE"
     , datistemplate
     , datallowconn
     , datconnlimit                     as "макс число подключений"
     --, db.datlastsysoid as "Последний системный OID"
     , ts.spcname                       as "TS по умолчанию"
     , db.datacl                        as "Права доступа"
from pg_database db
         join pg_authid pa on pa.oid = db.datdba
         join pg_tablespace ts on ts.oid = db.dattablespace;

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Статистика по сессиям Баз Данных инстанса</H4>'
\qecho '<UL>'
\qecho '<LI class=awr>в порядке убывания active_time'
\qecho '</UL>'
\qecho '<p></p>'

\if :ver_14

select
stats_reset
,datname as DB_name
-- ,round(session_time/1000)
,TO_CHAR((round(session_time/1000) || ' second')::interval, 'HH24:MI') as "session_time_HH24:MI"
-- ,active_time/1000
,TO_CHAR((round(active_time/1000) || ' second')::interval, 'HH24:MI') as "active_time_HH24:MI"
-- ,idle_in_transaction_time/1000
,TO_CHAR((round(idle_in_transaction_time/1000) || ' second')::interval, 'HH24:MI') as "idle_in_transaction_time_HH24:MI"
,sessions
,sessions_abandoned
,sessions_fatal
,sessions_killed
from pg_stat_database
where datname is not null
order by active_time desc ;

\else

select CASE
           WHEN current_setting('server_version_num')::integer < 140000::integer
               THEN
               'Эти метрики собираются начиная с 14 версии PostgreSQL'
           ELSE
               ''
           END;
\endif


SELECT * from pg_stat_database

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Статистика по Базам Данных инстанса</H4>'
\qecho '<UL>'
\qecho '<LI class=awr>в порядке убывания размера'
\qecho '<LI class=awr>tup_returned - количество записей, которые были «прочитаны» со страниц данных'
\qecho '<LI class=awr>tup_fetched - количество записей, которые не были отфильтрованы  на этапе Rows Removed by Filter, а ушли «выше» по плану выполнения'
\qecho '<LI class=awr>ret_to_fetch=tup_returned/tup_fetched, должно стремиться к 1, чем больше 1 — тем хуже'
\qecho '</UL>'
\qecho '<p></p>'
-- \qecho '<P>'

select datname
     , pg_size_pretty(pg_database_size(datname))                                                                    as "Размер"
     , datid
     --,sd.*
     , stats_reset::timestamp(0)                                                                                    AS "stats_reset"
     , numbackends -- AS "обслуживающих процессов на момент отчета"
     , xact_commit -- AS "зафиксированных транзакций"
     , xact_rollback
     , pg_size_pretty(blks_hit)                                                                                     as "blks_hit"
     , pg_size_pretty(blks_read)                                                                                    as "blks_read"
     --   , blks_hit/(blks_hit + blks_read) AS "hit_ratio"
     , CASE
           WHEN (blks_hit + blks_read) = 0 THEN NULL
           ELSE round(blks_hit / (blks_hit + blks_read)::numeric, 2) END                                            AS "hit_ratio"
     , round(blk_read_time::double precision)                                                                       AS "blk_read_time_ms"
     , CASE
           WHEN blks_read = 0 THEN NULL
           ELSE round((blk_read_time / blks_read)::numeric, 5) END                                                  AS "avg_one_blk_read_ms"
     , round(blk_write_time::double precision)                                                                      AS "blk_write_time_ms"
     , pg_size_pretty(tup_returned)                                                                                 as "tup_returned"
     , pg_size_pretty(tup_fetched)                                                                                  as "tup_fetched"
     --        , tup_fetched, tup_returned
     , CASE
           WHEN tup_fetched = 0 THEN NULL
           ELSE round((tup_returned / tup_fetched::double precision)::numeric) END                                  as "ret_to_fetch"
     , pg_size_pretty(tup_inserted)                                                                                 as "tup_inserted"
     , pg_size_pretty(tup_updated)                                                                                  as "tup_updated"
     , pg_size_pretty(tup_deleted)                                                                                  as "tup_deleted"
     , conflicts
     , temp_files
     , pg_size_pretty(temp_bytes)                                                                                   as "temp_sum_bts"
     , deadlocks
from pg_stat_database sd
order by pg_database_size(datname) desc;

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Количество типов отношений в текущей БД</H5>'
--\qecho '<UL>'
--\qecho '<LI class=awr>Доступ к функции pg_ls_logdir имеют члены группы pg_monitor'
--\qecho '</UL>'
\qecho '<p></p>'

select CASE
           WHEN a1.rk = 'r' THEN 'таблица обычная'
           WHEN a1.rk = 'p' THEN 'таблица секционированная'
           WHEN a1.rk = 'i' THEN 'индекс обычный'
           WHEN a1.rk = 'S' THEN 'последовательность'
           WHEN a1.rk = 't' THEN 'таблица TOAST'
           WHEN a1.rk = 'v' THEN 'представление'
           WHEN a1.rk = 'm' THEN 'представление материализованное'
           WHEN a1.rk = 'c' THEN 'составной тип'
           WHEN a1.rk = 'f' THEN 'таблица сторонняя'
           WHEN a1.rk = 'I' THEN 'индекс секционированный'

           ELSE 'не определено'
    END as relkind
     , cnt
from (select relkind as rk, count(*) as cnt
      FROM pg_class C
      WHERE 1 = 1
        AND C.relispartition = false
      group by relkind) a1
ORDER BY 1;

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Количество секций отношений в текущей БД</H5>'
--\qecho '<UL>'
--\qecho '<LI class=awr>Доступ к функции pg_ls_logdir имеют члены группы pg_monitor'
--\qecho '</UL>'
\qecho '<p></p>'

select nspname
     , CASE
           WHEN a1.rk = 'r' THEN 'секция таблицы обычной'
           WHEN a1.rk = 'p' THEN 'таблица секционированная'
           WHEN a1.rk = 'i' THEN 'секция индекса обычного'
           WHEN a1.rk = 'S' THEN 'последовательность'
           WHEN a1.rk = 't' THEN 'секция таблицы TOAST'
           WHEN a1.rk = 'v' THEN 'представление'
           WHEN a1.rk = 'm' THEN 'представление материализованное'
           WHEN a1.rk = 'c' THEN 'составной тип'
           WHEN a1.rk = 'f' THEN 'секция таблицы сторонней'
           WHEN a1.rk = 'I' THEN 'индекс секционированный'

           ELSE 'не определено'
    END as relkind
     , cnt
from (select n.nspname, C.relkind as rk, count(*) as cnt
      FROM pg_class C
               LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
      WHERE 1 = 1
        AND C.relispartition = TRUE
      group by n.nspname, C.relkind) a1
ORDER BY 2;

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Каталог с журналами сообщений</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Доступ к функции pg_ls_logdir имеют члены группы pg_monitor'
\qecho '</UL>'
\qecho '<p></p>'

--  SELECT pg_ls_dir('/');
SELECT ld.name, pg_size_pretty(ld.size), ld.modification
FROM pg_ls_logdir() ld
LIMIT 10;
SELECT pg_size_pretty(sum(size)) AS "Общий размер"
FROM pg_ls_logdir();

\qecho '<p></p>'
\qecho '<H5 class=awr>Каталог с WAL-журналами</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Последние по времени  5 файлов'
\qecho '<LI class=awr>Доступ к функции pg_ls_waldir имеют члены группы pg_monitor'
\qecho '</UL>'
\qecho '<p></p>'

SELECT lw.name, pg_size_pretty(lw.size), lw.modification
FROM pg_ls_waldir() lw
ORDER BY 3 DESC
LIMIT 5;
SELECT pg_size_pretty(sum(size)) AS "Общий размер"
FROM pg_ls_waldir();

\qecho '<p></p>'
\qecho '<H5 class=awr>Каталог archive_status хранит статусы архивирования всех сегментов (требующих архивирования)</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Последние по времени  5 файлов'
\qecho '<LI class=awr>Доступ к функции pg_ls_archive_statusdir имеют члены группы pg_monitor'
\qecho '</UL>'
\qecho '<p></p>'

SELECT *
FROM pg_ls_archive_statusdir()
ORDER BY 3 DESC
LIMIT 5;

/*select *
from pg_stat_database sd
order by pg_database_size(datname) desc;*/


\qecho '<p></p>'
\qecho '<H5 class=awr>Роли и grants</H5>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

SELECT m.rolname AS "Role name",
       r.rolname AS "Member of",
       pg_catalog.concat_ws(', ',
                            CASE WHEN pam.admin_option THEN 'ADMIN' END
           --CASE WHEN pam.inherit_option THEN 'INHERIT' END,
           --CASE WHEN pam.set_option THEN 'SET' END
           )     AS "Options",
       g.rolname AS "Grantor"
FROM pg_catalog.pg_roles m
         JOIN pg_catalog.pg_auth_members pam ON (pam.member = m.oid)
         LEFT JOIN pg_catalog.pg_roles r ON (pam.roleid = r.oid)
         LEFT JOIN pg_catalog.pg_roles g ON (pam.grantor = g.oid)
WHERE m.rolname !~ '^pg_'
ORDER BY 1, 2, 4;
\qecho </details>

\qecho '<p></p>'
\qecho '<H5 class=awr>Пользователи</H5>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

select *
FROM pg_user;
\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Репликация</H4>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<H5 class=awr>Активные слоты репликации, упорядоченные по age_xmin</H5>'
\qecho '<p></p>'

select *, age(xmin) age_xmin, age(catalog_xmin) age_catalog_xmin
from pg_replication_slots
where active = true
order by age(xmin) desc;

\qecho '<p></p>'
\qecho '<H5 class=awr>Lag  по слотам репликации, упорядоченные по Lag_MB_behind</H5>'
\qecho '<p></p>'

select slot_name,
       slot_type,
       database,
       active,
       coalesce(round(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn) / 1024 / 1024, 2), 0)        AS Lag_MB_behind,
       coalesce(round(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn) / 1024 / 1024 / 1024, 2), 0) AS Lag_GB_behind
from pg_replication_slots
order by Lag_MB_behind desc;

\qecho '<p></p>'
\qecho '<H5 class=awr>Неактивные слоты репликации, упорядоченные по age_xmin</H5>'
\qecho '<p></p>'

select *, age(xmin) age_xmin, age(catalog_xmin) age_catalog_xmin
from pg_replication_slots
where active = false
order by age(xmin) desc;

\qecho '<p></p>'

\qecho '<A class=awr_ital> Note:</A>'
\qecho '<A class=awr_ital> RDS Postgres instance storage may get full because inactive replication slots were not removed after DMS task completed </A>'
\qecho '<A class=awr_ital> If replication slot is created and it becomes in-active, then transaction logs wont recycle from master instance. So eventually storage gets full </A>'
\qecho '<A class=awr_ital> These replication slots can be cleaned as below </A>'
\qecho <br>
\qecho '<A class=awr_ital> Drop inactive replication slot : </A>'
\qecho '<A class=awr_ital> Use the below SQL to Generate SQL to drop the inactive slots </A>'
\qecho '<A class=awr_ital>  select 'select pg_drop_replication_slot('''||slot_name||''');' from pg_replication_slots where active = false; </A>'
\qecho '<A class=awr_ital> then Verify the CLoudWatch metrics Free Storage Space to confirm that disk space was released </A>'
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<H5 class=awr>Replication Slot wal status</H5>'
\qecho '<p></p>'

select name as parameter_name,
       setting,
       unit,
       short_desc
FROM pg_catalog.pg_settings
WHERE name in ('max_slot_wal_keep_size');

\qecho <br>

select slot_name,
       slot_type,
       database,
       active,
       wal_status,
       safe_wal_size,
       coalesce(round(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn) / 1024 / 1024, 2), 0)        AS Lag_MB_behind,
       coalesce(round(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn) / 1024 / 1024 / 1024, 2), 0) AS Lag_GB_behind
from pg_replication_slots
order by safe_wal_size;

\qecho '<A class=awr_ital> wal_status : the Availability of WAL files claimed by this slot. Possible values are: </A>'
\qecho '<A class=awr_ital> - reserved means that the claimed files are within max_wal_size. </A>'
\qecho '<A class=awr_ital> - extended means that max_wal_size is exceeded but the files are still retained, either by the replication slot or by wal_keep_size. </A>'
\qecho '<A class=awr_ital> - unreserved means that the slot no longer retains the required WAL files and some of them are to be removed at the next checkpoint. This state can return to reserved or extended. </A>'
\qecho '<A class=awr_ital> - lost means that some required WAL files have been removed and this slot is no longer usable. </A>'
\qecho '<A class=awr_ital> The last two states are seen only when max_slot_wal_keep_size is non-negative. If restart_lsn is NULL, this field is null. </A>'
\qecho '<A class=awr_ital> safe_wal_size : The number of bytes that can be written to WAL such that this slot is not in danger of getting in state "lost". It is NULL for lost slots, as well as if max_slot_wal_keep_size is -1. </A>'
\qecho <br>
\qecho '<H5 class=awr> pg_stat_replication_slots view:</H5>'
\qecho '<A class=awr_ital> pg_stat_replication_slots is a statistics view showing statistics about logical replication slot usage, specifically about transactions spilled to disk from the ReorderBuffer once the memory used by logical decoding to decode changes from WAL has exceeded logical_decoding_work_mem </A>'

SELECT *
FROM pg_stat_replication_slots
order by spill_bytes;

\qecho '<H5 class=awr> Параметры репликации</H5>'

select name as parameter_name,
       setting,
       unit,
       short_desc
FROM pg_catalog.pg_settings
WHERE name in ('wal_level', 'max_wal_senders', 'max_replication_slots',
               'max_worker_processes', 'max_logical_replication_workers', 'wal_receiver_timeout',
               'max_sync_workers_per_subscription', 'wal_receiver_status_interval', 'wal_retrieve_retry_interval',
               'logical_decoding_work_mem', 'max_slot_wal_keep_size');

\qecho </details>

\qecho <P><A class=awr href="#21">Back to Версия, Хост, Инстанс, Базы Данных</A> <BR><A class=awr href="#top">Back to Top</A>

-- select * from pg_buffercache
\set h_b 'https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1080039114'
--\qecho :h_b

