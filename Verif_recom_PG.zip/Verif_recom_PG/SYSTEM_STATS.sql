\qecho '<P><A class=awr name=191></A>'
\qecho '<H2 class=awr>Системная статистика по процессам</H2>'

\qecho '<A class=awr_ital>Скрипт SYSTEM_STATS.sql</A>'
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=1911></A>'
\qecho '<H3 class=awr>Использование CPU и памяти по статусам сессий ПГ</H3>'
\qecho '<p></p>'

select state
     ,count(*)
     ,round(SUM(cpu_usage)::numeric ,2) as sum_cpu_usage
     ,pg_size_pretty(SUM(memory_bytes)) as sum_mem_b
     ,round(SUM(memory_usage)::numeric ,2) as sum_mem_usage
     --,SUM(memory_bytes) as sum_mem_b
from pg_sys_cpu_memory_by_process() cmp
         join pg_stat_activity sa on cmp.pid = sa.pid
where (cmp.memory_bytes > 0 OR cpu_usage > 0)
GROUP BY state
order by state;


\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>Использование CPU и памяти по типам сессий ПГ</H3>'
\qecho '<p></p>'

select backend_type
     ,SUM(cpu_usage) as sum_cpu_usage
     ,pg_size_pretty(SUM(memory_bytes)) as sum_mem_pr
     ,round(SUM(memory_usage)::numeric ,2) as sum_mem_usage
     --,SUM(memory_bytes) as sum_mem_b
from pg_sys_cpu_memory_by_process() cmp
         join pg_stat_activity sa on cmp.pid = sa.pid
where (cmp.memory_bytes > 0 OR cpu_usage > 0)
GROUP BY backend_type
order by backend_type;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>Использование CPU и памяти по событиям ожидания и статусам сессий ПГ</H3>'
\qecho '<p></p>'

select wait_event_type, wait_event, state
     ,SUM(cpu_usage) as sum_cpu_usage
     ,pg_size_pretty(SUM(memory_bytes)) as sum_mem_pr
     ,round(SUM(memory_usage)::numeric ,2) as sum_mem_usage
     --,SUM(memory_bytes) as sum_mem_b
from pg_sys_cpu_memory_by_process() cmp
         join pg_stat_activity sa on cmp.pid = sa.pid
where (cmp.memory_bytes > 0 OR cpu_usage > 0)
GROUP BY wait_event_type, wait_event, state
order by wait_event_type, wait_event, state;


\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>Процессы потребляющие CPU</H3>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

select to_char(now(), 'YYYY.MM.DD HH24:MI:SS')  AS snapshot_time
     ,pid as p_pid
     ,name as p_name
     ,running_since_seconds as p_running_since_s
     ,round((running_since_seconds/3600),2) as p_running_since_h
     ,cpu_usage as p_cpu_usage
     ,memory_usage as p_mem_usage
     -- ,memory_bytes as p_mem_b
     ,pg_size_pretty(cmp.memory_bytes) as p_mem_b
 from pg_sys_cpu_memory_by_process() cmp
-- where cmp.cpu_usage  > 0
order by cmp.cpu_usage desc;

\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Сессии ПГ, потребляющие CPU</H3>'
\qecho '<p></p>'

select to_char(now(), 'YYYY.MM.DD HH24:MI:SS')  AS snapshot_time
     ,cmp.pid as p_pid
     ,name as p_name
     ,running_since_seconds as p_run_since_s
     ,round(running_since_seconds/3600,2) as p_run_since_h
     ,cpu_usage as p_cpu_usage
     ,memory_usage as p_mem_usage
     -- ,memory_bytes as p_mem_b
     ,pg_size_pretty(cmp.memory_bytes) as p_mem_b

     ,wait_event_type as s_we_type
     ,wait_event as s_wait_event
     ,state as s_state
     ,backend_type as s_backend_type
     --,datid as s_datid
     ,datname as s_datname
     ,leader_pid as s_leader_pid
     ,usename as s_usename
     ,application_name as s_application_name
     ,client_addr as s_client_addr
     ,client_hostname as s_client_hostname
     ,client_port as s_client_port
     ,to_char(backend_start,'DD HH24:MI:SS:MS') as s_backend_start
     ,to_char(xact_start,'DD HH24:MI:SS:MS') as s_xact_start
     ,to_char(query_start,'DD HH24:MI:SS:MS') as s_query_start
     ,to_char(sa.state_change,'DD HH24:MI:SS:MS') as s_state_change
     ,backend_xid as s_backend_xid
     ,backend_xmin as s_backend_xmin
     ,query_id query_id
     -- ,regexp_replace(trim(query), '\s+', ' ', 'g') AS "Query_text"

     --, sa.*
from pg_sys_cpu_memory_by_process() cmp
         join pg_stat_activity sa on cmp.pid = sa.pid
where cmp.cpu_usage > 0
order by cmp.cpu_usage desc;


\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Процессы потребляющие память</H3>'
\qecho '<p></p>'


\qecho <details>
\qecho   <summary>Раскрыть</summary>

select to_char(now(), 'YYYY.MM.DD HH24:MI:SS')  AS snapshot_time
     ,pid as p_pid
     ,name as p_name
     ,running_since_seconds as p_running_since_s
     ,round(running_since_seconds/3600,2) as p_running_since_h
     ,cpu_usage as p_cpu_usage
     ,memory_usage as p_mem_usage
     -- ,memory_bytes as p_mem_b
     ,pg_size_pretty(cmp.memory_bytes) as p_mem_b
from pg_sys_cpu_memory_by_process() cmp
where cmp.memory_bytes > 0
order by cmp.memory_bytes desc;

\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Сессии ПГ, потребляющие память</H3>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

select to_char(now(), 'YYYY.MM.DD HH24:MI:SS')  AS snapshot_time
     ,cmp.pid as p_pid
     ,name as p_name
     ,running_since_seconds as p_run_since_s
     ,round(running_since_seconds/3600,2) as p_run_since_h
     ,cpu_usage as p_cpu_usage
     ,memory_usage as p_mem_usage
     -- ,memory_bytes as p_mem_b
     ,pg_size_pretty(cmp.memory_bytes) as p_mem_b

     ,wait_event_type as s_WE_type
     ,wait_event as s_wait_event
     ,state as s_state
     ,backend_type as s_backend_type
     -- ,datid as s_datid
     ,datname as s_datname
     ,leader_pid as s_leader_pid
     ,usename as s_usename
     ,application_name as s_application_name
     ,client_addr as s_client_addr
     ,client_hostname as s_client_hostname
     ,client_port as s_client_port
     ,to_char(backend_start,'DD HH24:MI:SS:MS') as s_backend_start
     ,to_char(xact_start,'DD HH24:MI:SS:MS') as s_xact_start
     ,to_char(query_start,'DD HH24:MI:SS:MS') as s_query_start
     ,to_char(sa.state_change,'DD HH24:MI:SS:MS') as s_state_change
     ,backend_xid as s_backend_xid
     ,backend_xmin as s_backend_xmin
     ,query_id query_id
     -- ,regexp_replace(trim(query), '\s+', ' ', 'g') AS "Query_text"

     --, sa.*
from pg_sys_cpu_memory_by_process() cmp
         join pg_stat_activity sa on cmp.pid = sa.pid
where cmp.memory_bytes > 0
order by cmp.memory_bytes desc;

\qecho </details>

\qecho <P><A class=awr href="#191">Back to Системная статистика</A> <BR><A class=awr href="#top">Back to Top</A>
