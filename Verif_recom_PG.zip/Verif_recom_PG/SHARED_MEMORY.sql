\qecho '<p></p>'
\qecho '<P><A class=awr name=601></A>'
\qecho '<H3 class=awr>Разделяемая память</H3>'

\qecho '<A class=awr_ital>Скрипт SHARED_MEMORY.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны состояние на момент создания отчета'
\qecho '</UL>'
\qecho '<p></p>'


\if :set_pg_buffercache

\qecho '<p></p>'
\qecho 'Объекты в буферном кеше'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Упорядочены по размеру занимаемой памяти, показаны все записи'
-- \qecho '<LI class=awr>Доступ к функции pg_ls_archive_statusdir имеют члены группы pg_monitor'
\qecho '</UL>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

SELECT n.nspname,
       c.relname,
       count(*)                        AS buffers,
       pg_size_pretty(count(*) * 8192) AS bytes
FROM pg_buffercache b
         JOIN pg_class c
              ON b.relfilenode = pg_relation_filenode(c.oid) AND
                 b.reldatabase IN (
                                   0,
                                   (SELECT oid FROM pg_database WHERE datname = current_database())
                     )
         JOIN pg_namespace n ON n.oid = c.relnamespace
GROUP BY n.nspname, c.relname
ORDER BY 3 DESC;
-- LIMIT 30;
\qecho </details>

\qecho '<p></p>'
\qecho 'Cоотношение объемов буферов, находящихся в разных состояниях'
\qecho '<p></p>'

SELECT pg_size_pretty(count(*) FILTER (
    WHERE reldatabase IS NULL) * 8192)                           AS free,
       pg_size_pretty(count(*) FILTER (
           WHERE pinning_backends = 0 AND isdirty = 'f') * 8192) AS clean,
       pg_size_pretty(count(*) FILTER (
           WHERE pinning_backends > 0 AND isdirty = 'f') * 8192) AS "clean/pinned",
       pg_size_pretty(count(*) FILTER (
           WHERE pinning_backends = 0 AND isdirty = 't') * 8192) AS dirty,
       pg_size_pretty(count(*) FILTER (
           WHERE pinning_backends > 0 AND isdirty = 't') * 8192) AS "dirty/pinned"
FROM pg_buffercache;

\else
\qecho '<p>Расширение pg_buffercache не установлено</p>'
\endif

-- https://postgrespro.ru/docs/postgresql/16/view-pg-shmem-allocations
-- По умолчанию представление pg_shmem_allocations могут читать только суперпользователи или пользователи c правами роли pg_read_all_stats

-- SELECT * FROM pg_shmem_allocations ORDER BY size DESC LIMIT 10;

\qecho '<p></p>'
\qecho 'Cтруктура общей памяти'
\qecho '<UL>'
\qecho '<LI class=awr>Первые 10 по размеру занимаемой памяти'
-- \qecho '<LI class=awr>Доступ к функции pg_ls_archive_statusdir имеют члены группы pg_monitor'
\qecho '</UL>'
\qecho '<p></p>'


SELECT sa.name, sa."off", sa.size, pg_size_pretty(sa.size) as "size_pr", pg_size_pretty(sa.allocated_size) as "allocated_size_pr"
FROM pg_shmem_allocations sa
ORDER BY size DESC
LIMIT 10;

\qecho '<p></p>'
\qecho 'Используемые сегменты памяти для текущего процесса(сеанса)'
\qecho 'Для тяжелых запроса следует использовать функцию pg_log_backend_memory_contexts, которая принимает в качестве аргумента идентификатор процесса и сбрасывает раскладку памяти в журнал'
\qecho '<p></p>'

SELECT * FROM pg_backend_memory_contexts
ORDER BY used_bytes DESC
LIMIT 10;

\qecho '<p></p>'
\qecho 'Использования SLRU-кешей'
\qecho '<p></p>'

SELECT * FROM pg_stat_slru;

\qecho <P><A class=awr href="#601">Back to Разделяемая память</A> <BR><A class=awr href="#top">Back to Top</A>



