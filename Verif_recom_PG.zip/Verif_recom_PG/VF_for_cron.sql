-- Получение команд для проведения FREEZE для таблиц из запроса в указанный файл sql
-- Пример запуска
-- Перейти в директорию со скриптами
-- \cd d:/PostgreSQL/SQL/Verif_recom_PG
-- \i VF_for_cron.sql

-- \pset footer off
\pset tuples_only
\pset null '(null)'
\timing off

-- ! Задать путь к директории для скрипта
\set vt_path 'd:/temp/'
--\qecho :'vt_path'

-- Задать имя файла
\set vt_file 'VF'
--  Задать расширение файла
\set vt_tail_sql '.sql'
-- ! Сформировать полный путь к файлу
\set vt_out_file_txt :vt_path:vt_file:vt_tail_sql
\qecho :'vt_out_file_txt'

\pset format aligned

\o :vt_out_file_txt

select 'VACUUM (FREEZE, VERBOSE, ANALYZE)  ' || a2.nspname ||  '.' || a2.relname || ';'  AS "VACUUM (FREEZE, VERBOSE, ANALYZE) "
from (
SELECT pg_namespace.nspname
       ,relname
       , to_char(to_number(relfrozenxid::text, '999999999999'), '999 999 999 999') as "relfrozenxid"
       -- , age(relfrozenxid)
       , to_char(to_number(age(relfrozenxid)::text, '999999999999'), '999 999 999 999') AS horizon
       , to_char(txid_current(), '999 999 999 999') as "txid_current"
       , pg_stat_get_autovacuum_count(c.oid) + pg_stat_get_vacuum_count(c.oid) AS all_vacuum_count,
       to_char(now() - coalesce(
               pg_stat_get_last_autovacuum_time(c.oid),
               pg_stat_get_last_vacuum_time(c.oid)
           ), 'DD HH24:MI:SS:MS')                           AS since_last_vacuum
FROM pg_class c
JOIN pg_namespace
                             ON c.relnamespace = pg_namespace.oid
WHERE c.relkind = 'r'
--  AND c.relname ~'pgbench'
   AND age(relfrozenxid) > (to_number(current_setting('autovacuum_freeze_max_age'), '999999999999')/2)
ORDER BY age(relfrozenxid) DESC
limit 15) a2;
-- Закрыть вывод в файл
\o




