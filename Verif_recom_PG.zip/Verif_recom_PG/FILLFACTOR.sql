/*
-- ! Задать имя проекта латиницей
\set vt_project 'AFT_PROD_CAMUNDA'
-- ! Задать путь к директории для отчетов
\set vt_path 'd:/temp/'

-- Пример запуска
-- Перейти в директорию со скриптами
-- \cd d:/PostgreSQL/SQL/Verif_recom_PG
-- Запустить головной  файл
-- \i FILLFACTOR.sql

\set vt_tail_html '.html'

SELECT to_char(LOCALTIMESTAMP, '_YYYY_MM_DD_HH24_MI_SS') AS vt_time;
\gset

\pset format html
-- включают или отключают вывод результирующей строки с количеством выбранных записей (n строк)
\pset footer off
--Отключает вывод имён столбцов и результирующей строки с количеством выбранных записей
--\pset tuples_only

\set vt_out_file_html :vt_path:vt_project:vt_time:vt_tail
\o :vt_out_file_html

\pset null '(null)'
\timing off
*/

\qecho '<H2 class=awr>FILLFACTOR</H2>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Скрипт FILLFACTOR.sql'
\qecho '</UL>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H3 class=awr>Таблицы, кандидаты на изменение fillfactor</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Кол-во UPDATE с момента сбора статистики или Кол-во  модифицированных с момента последнего анализа > 50% строк таблицы'
\qecho '</UL>'
\qecho '<p></p>'

select a1.relname, a1.nspname, a1.main_size, a1.total_size
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]),'100')::real AS fillfactor
     ,round(a1.n_tup_upd*100/reltuples) AS "%tup_upd"
     ,round(a1.n_mod_since_analyze*100/reltuples) AS "%mod_since_alz"
     ,to_char(a1.last_analyzed,'YY-MM-DD HH24:MI:SS') AS "last_anl"
     , reltuples AS "n_tups_all"
     , n_tup_upd as "n_tups_upd"
     , a1.n_mod_since_analyze AS "n_mod_since_anl"
     , size_bt
from (SELECT pg_class.relname
                    , pg_namespace.nspname
                    , pg_size_pretty(pg_total_relation_size(pg_class.oid))                         "total_size"
                    , pg_size_pretty(pg_relation_size(pg_class.oid))                               "main_size"
                    , CASE
                          WHEN COALESCE(last_vacuum, '1/1/1000') >
                               COALESCE(last_autovacuum, '1/1/1000') THEN
                              pg_stat_all_tables.last_vacuum
                          ELSE last_autovacuum
        END                                                                                     AS last_vacuumed
                    , CASE
                          WHEN COALESCE(last_analyze, '1/1/1000') >
                               COALESCE(last_autoanalyze, '1/1/1000') THEN
                              pg_stat_all_tables.last_analyze
                          ELSE last_autoanalyze
        END                                                                                     AS last_analyzed
                    , (pg_stat_all_tables.autovacuum_count + pg_stat_all_tables.vacuum_count)   AS "cnt_vcm"
                    , (pg_stat_all_tables.autoanalyze_count + pg_stat_all_tables.analyze_count) AS "cnt_anl"
                    , pg_stat_all_tables.n_mod_since_analyze
                    , pg_relation_size(pg_class.oid) AS "size_bt"
                    , pg_class.reloptions
                    , pg_class.reltuples
                    , pg_stat_all_tables.n_tup_upd
                    , pg_stat_all_tables.n_dead_tup
                    , pg_stat_all_tables.n_tup_ins
               FROM pg_class
                        JOIN pg_namespace
                             ON pg_class.relnamespace = pg_namespace.oid
                        JOIN pg_stat_all_tables
                             ON (
                                         pg_class.relname = pg_stat_all_tables.relname
                                     AND pg_namespace.nspname = pg_stat_all_tables.schemaname
                                 )
               WHERE pg_namespace.nspname NOT IN ('pg_toast','pg_catalog','information_schema')
) a1
    where a1.n_tup_upd > 0
        and a1.reltuples > 0
        and (round(a1.n_tup_upd*100/reltuples) > 50
        or round(a1.n_mod_since_analyze*100/reltuples) > 50)
        and size_bt > 1024*1024
               ORDER BY size_bt DESC;


\qecho '<p></p>'
\qecho 'Команды на изменения fillfactor у таблиц с fillfactor = 100 и '
\qecho 'Кол-во UPDATE с момента сбора статистики или Кол-во  модифицированных с момента последнего анализа > 50% строк таблицы См одноименный с отчетом файл с расширением sql'
\qecho '<p></p>'


\qecho '<p></p>'
\qecho 'Индексы в БД, которым рекомендуется изменить fillfactor со 100 на 90. См одноименный с отчетом файл с расширением sql '
\qecho '<p></p>'

