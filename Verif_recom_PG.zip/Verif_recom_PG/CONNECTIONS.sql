\qecho '<p></p>'
\qecho '<P><A class=awr name=61></A>'
\qecho '<H3 class=awr>Информация по соединениям</H3>'

\qecho '<A class=awr_ital>Скрипт CONNECTIONS.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны состояние на момент создания отчета'
\qecho '</UL>'
\qecho '<p></p>'

\qecho <details>
\qecho <summary>Раскрыть</summary>

select name                                                                                                   "parameter",
       setting                                                                                                "setting",
       CASE WHEN to_number(setting, '9999999') > 100 AND to_number(setting, '99999') <= 500 THEN 1 ELSE 0 END "check",
       CASE
           WHEN to_number(setting, '9999999') > 100 AND to_number(setting, '99999') <= 500 THEN '+ '
           ELSE ''
           END                                                                                                "Comment",
       CASE
           WHEN to_number(setting, '99999') <= 100
               THEN
               ''
           ELSE
                   'Как первое приближение <CPUs> *5 + 20.' ||
                   ' Если нужно более 500 рассмотрите возможность использования пуллера коннектов Odyssey'
           END                                                                                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_connections'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Не задан интервал прерывания сессий для idle_in_transaction '
           ELSE 'Задан интервал прерывания сессий для idle_in_transaction'
           END                                  "Comment",
          'Завершать любые сеансы, простаивающие (то есть ожидающие запросов от клиентов) дольше заданного времени в открытой транзакции. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. При значении, равном нулю (по умолчанию), этот контроль длительности отключается'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'idle_in_transaction_session_timeout'

union


select name                                                          "parameter",
       setting                                                       "setting",
       CASE WHEN to_number(setting, '99G999') >= 3 THEN 1 ELSE 0 END "check",
       CASE
           WHEN to_number(setting, '99G999') >= 3 THEN '+ '
           ELSE ''
           END                                                       "Comment",
       CASE
           WHEN to_number(setting, '99G999') = 3
               THEN
               ''
           ELSE
               '10 , если 8 ядер и больше, иначе 4'
           END                                                       "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'superuser_reserved_connections'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Не задан интервал прерывания для сессий вне открытой транзакции'
           ELSE 'Задан интервал прерывания для сессий вне открытой транзакции'
           END                                  "Comment",
          'Завершать любые сеансы, простаивающие (то есть ожидающие запросов от клиентов) дольше заданного времени вне открытой транзакции. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. При значении, равном нулю (по умолчанию), этот контроль длительности отключается.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'idle_session_timeout'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт период отсутствия сетевой активности, по истечении которого операционная система должна отправить клиенту TCP-сигнал сохранения соединения. Если это значение задаётся без единиц измерения, оно считается заданным в секундах. При значении 0 (по умолчанию) действует величина, принятая по умолчанию в операционной системе.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'tcp_keepalives_idle'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт интервал, по истечении которого следует повторять TCP-сигнал сохранения соединения, если от клиента не получено подтверждение предыдущего сигнала. Если это значение задаётся без единиц измерения, оно считается заданным в секундах. При значении 0 (по умолчанию) действует величина, принятая по умолчанию в операционной системе.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'tcp_keepalives_interval'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт число TCP-сигналов сохранения соединения, которые могут быть потеряны до того, как соединение сервера с клиентом будет признано прерванным. При значении 0 (по умолчанию) действует величина, принятая по умолчанию в операционной системе. '
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'tcp_keepalives_count'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт интервал, в течение которого переданные данные могут оставаться неподтверждёнными, прежде чем будет принято решение о принудительном закрытии TCP-соединения. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. При значении 0 (по умолчанию) действует величина, принятая по умолчанию в операционной системе.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'tcp_user_timeout'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт интервал между необязательными проверками соединения сервера с клиентом в процессе выполнения запроса. Такая проверка, заключающаяся в опросе состояния сокета, позволяет раньше прерывать длительные запросы, если ядро сообщает, что соединение закрыто. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. Значение по умолчанию — 0, то есть проверка соединения отключена. Если соединение не проверяется, сервер обнаружит разрыв соединения только при следующем обращении к сокету, когда будет передавать, ожидать или читать данные.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'client_connection_check_interval'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт интервал между необязательными проверками соединения сервера с клиентом в процессе выполнения запроса. Такая проверка, заключающаяся в опросе состояния сокета, позволяет раньше прерывать длительные запросы, если ядро сообщает, что соединение закрыто. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. Значение по умолчанию — 0, то есть проверка соединения отключена. Если соединение не проверяется, сервер обнаружит разрыв соединения только при следующем обращении к сокету, когда будет передавать, ожидать или читать данные.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'client_connection_check_interval'


order by "check", "parameter";

\qecho </details>


\qecho '<p></p>'
\qecho 'Количество соединений по статусам на момент выполнениия скрипта'
\qecho '<p></p>'

WITH connections AS (SELECT COUNT(*)                                                       AS total_conn,
                            SUM(CASE WHEN state = 'active' THEN 1 ELSE 0 END)              AS active,
                            SUM(CASE WHEN state = 'idle' THEN 1 ELSE 0 END)                AS idle,
                            SUM(CASE WHEN state = 'idle in transaction' THEN 1 ELSE 0 END) AS idle_in_transaction
                     FROM pg_stat_activity),
     max_connections AS (SELECT setting AS max_connections
                         FROM pg_settings
                         WHERE name = 'max_connections'),
     superuser_reserved_connections AS (SELECT setting AS superuser_reserved_conn
                                        FROM pg_settings
                                        WHERE name = 'superuser_reserved_connections')
SELECT to_char(now(), 'YYYY.MM.DD HH24:MI:SS')                               AS snapshot_time,
       C.total_conn,
       C.active,
       C.idle_in_transaction,
       C.idle,
       MC.max_connections,
       SR.superuser_reserved_conn,
       ROUND((100 * C.total_conn::NUMERIC / MC.max_connections::NUMERIC), 2) AS "conn_utilization_%"
FROM connections AS C
         CROSS JOIN max_connections AS MC
         CROSS JOIN superuser_reserved_connections AS SR;


\qecho '<p></p>'
\qecho 'Количество пользователей подключенных к каждой БД'
\qecho '<p></p>'

SELECT datname,
       usename,
       state,
       count(*) AS "connections"
/* VR_PG */
FROM pg_stat_activity
group by datname, usename, state
order by datname, usename, state;

\qecho '<p></p>'
\qecho 'Количество соединений по адресу клиента'
\qecho '<p></p>'

SELECT client_addr,  state, count(*)
FROM pg_stat_activity
GROUP BY client_addr, state
ORDER BY client_addr, state;

\qecho '<p></p>'

SELECT client_addr,  state, datname, usename, count(*)
FROM pg_stat_activity
GROUP BY client_addr, state, datname, usename
         ORDER BY client_addr, state, datname,usename;

\qecho '<p></p>'
\qecho 'Количество соединений по ожиданиям на момент выполнения скрипта'
\qecho '<p></p>'

SELECT sa.wait_event_type
     , sa.wait_event
     , count(*) AS cnt_conn
/* VR_PG */
FROM pg_stat_activity sa
group by sa.wait_event_type, sa.wait_event
order by sa.wait_event_type, sa.wait_event;

\qecho '<p></p>'
\qecho 'Параллельные процессы на момент выполнениия скрипта'
\qecho '<p></p>'

select *
from pg_stat_activity sa
where sa.backend_type = 'parallel worker'
   OR leader_pid is not null;

\qecho '<p></p>'
\qecho 'Количество соединений по запросам на момент выполнениия скрипта'
\qecho '<p></p>'

SELECT regexp_replace(trim(sa.query), '\s+', ' ', 'g') AS "Query_text"
--      TRIM(sa.query) AS query
     , count(*)                                           cnt_conn
FROM pg_stat_activity sa
WHERE position('VR_PG' IN sa.query) = 0
   OR sa.query IS NOT NULL
   OR sa.query <> ''
group by sa.query
order by 2 desc
LIMIT 10;

\qecho '<p></p>'
\qecho 'Сеансы, в которых выполнялись DDL  на момент создания отчета'
\qecho '<p></p>'

SELECT datid,
       datname,
       pid,
       leader_pid,
       usesysid,
       usename,
       application_name,
       client_addr,
       client_hostname,
       client_port,
       backend_start,
       xact_start,
       query_start,
       state_change,
       wait_event_type,
       wait_event,
       state,
       backend_xid,
       backend_xmin,
       query_id
       --query,
       ,regexp_replace(trim(query), '\s+', ' ', 'g') AS "Query_text"
       ,backend_type
       --  sa.*
       -- TRIM(sa.query) AS query , count(*) cnt_conn
FROM pg_stat_activity sa
WHERE position('VR_PG' IN sa.query) = 0
  and (
            position('ALTER ' in upper(TRIM(sa.query))) > 0
        OR position('CREATE TABLE ' in upper(TRIM(sa.query))) > 0
        OR position('CREATE INDEX ' in upper(TRIM(sa.query))) > 0
        OR position('TRUNCATE ' in upper(TRIM(sa.query))) > 0
        OR position('REINDEX ' in upper(TRIM(sa.query))) > 0
        OR position('VACUUM ' in upper(TRIM(sa.query))) > 0
    )
  and state ='active'
order by sa.pid;


\qecho '<p></p>'
\qecho 'Статистика по статусам сеансов'
\qecho '<p></p>'

SELECT datname, sessions, sessions_abandoned, sessions_fatal, sessions_killed
FROM pg_stat_database
WHERE sessions > 0;

\qecho '<p></p>'
\qecho 'Cоединения в состоянии active более 1-ной минуты'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 на момент создания отчета'
\qecho '</UL>'
\qecho '<p></p>'

SELECT sa.state_change, (current_timestamp - sa.state_change) as "Time_in_Idle",  sa.*
    FROM pg_stat_activity sa
    WHERE pid <> pg_backend_pid()
      AND state = 'active'
       AND  current_timestamp - state_change > INTERVAL '1' MINUTE
    order by state_change
    limit 15;

\qecho '<p></p>'
\qecho 'Cоединения в состоянии idle более 1-го часа'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 на момент создания отчета'
\qecho '</UL>'
\qecho '<p></p>'

SELECT sa.state_change, (current_timestamp - sa.state_change) as "Time_in_Idle",  sa.*
    FROM pg_stat_activity sa
    WHERE pid <> pg_backend_pid()
      AND state = 'idle'
      AND  current_timestamp - state_change > INTERVAL '60' MINUTE
    order by state_change
    limit 15;

\qecho <P><A class=awr href="#61">Back to Информация по соединениям</A> <BR><A class=awr href="#top">Back to Top</A>


/*
select count(*) as connections, usename from pg_stat_activity group by usename order by count(*) desc;

Общее количество открытых соединений:

select count(*) from pg_stat_activity;
Количество соединений открытых пользователями:

select count(*) as connections, usename from pg_stat_activity group by usename order by count(*) desc;
*/

