\qecho '<p></p>'
\qecho '<P><A class=awr name=111></A>'
\qecho '<H2 class=awr>Таблицы. Партиции. Последовательности.</H2>'

\qecho '<A class=awr_ital>Скрипт TABLES.sql</A>'
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=112></A>'
\qecho '<H3 class=awr>Unlogged Tables</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания размера'
\qecho '</UL>'
\qecho '<p></p>'

select count(*) as "CNT of Unlogged Tables"
FROM pg_class
WHERE relpersistence = 'u' AND relkind = 'r';

select c.relname                                     as table_name
     , c.relpersistence
     , pg_size_pretty(pg_total_relation_size(C.oid)) AS "ttl_size_pr"
     , pg_total_relation_size(C.oid)                 AS "ttl_size_bt"
FROM pg_class c
WHERE relpersistence = 'u'
  AND c.relkind = 'r'
order by pg_total_relation_size(C.oid) desc
limit 15;


\qecho '<p></p>'
\qecho '<P><A class=awr name=112></A>'
\qecho '<H3 class=awr>Обычные таблицы по размеру, кандидаты на секцонирование.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны у который строк более 1 млн'
\qecho '<LI class=awr>или суммарный размер более 5 Гб'
\qecho '</UL>'
\qecho '<p></p>'

SELECT nspname                                       as                           "table_schema"
     , relname                                       AS                           "table_name"
     , C.relkind                                     AS                           "kind"
     , C.relispartition                              AS                           "ispartition"
     , to_char(C.reltuples, '999 999 999 999')       AS                           "tuples"
     , to_char(c.relpages, '999 999 999 999')        AS                           "pages"
     , round((C.reltuples / c.relpages)::numeric, 2) as                           "tuples_on_page"
     , pg_size_pretty(pg_total_relation_size(C.oid)) AS                           "ttl_size"
     -- pg_total_relation_size(C.oid)                 AS           "ttl_size_bt",
     , pg_size_pretty(COALESCE(pg_total_relation_size(reltoastrelid), 0))         "TOAST_size"

     , pg_size_pretty(pg_indexes_size(C.oid) +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'main') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init') +
                      COALESCE(pg_total_relation_size(reltoastrelid), 0))         "control"
     , pg_size_pretty(pg_indexes_size(C.oid))        AS                           "indexes_size"
     ,
     --pg_indexes_size(C.oid)                        AS           "indexes_size_bt",
    pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                     quote_ident(relname))::regclass, 'main'))    "main"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm'))  "fsm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm'))   "vm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init')) "init"
     -- reltoastrelid,
FROM pg_class C
         LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
WHERE nspname NOT IN ('pg_catalog', 'information_schema')
  AND C.relkind = 'r'
  AND C.relispartition = FALSE
  AND c.relpages > 0
  AND nspname !~ '^pg_toast'
  AND (C.reltuples > 1000000 OR pg_total_relation_size(C.oid) > (5 * 1024 * 1024 * 1024::BIGINT))
ORDER BY pg_total_relation_size(C.oid) DESC
LIMIT 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=113></A>'
\qecho '<H3 class=awr>Секционированные таблицы по размеру</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания размера'
\qecho '</UL>'
\qecho '<p></p>'

WITH RECURSIVE
    tables AS (SELECT c.relnamespace,
                      c.oid AS parent,
                      c.oid AS relid,
                      1     AS level
                       ,
                      C.reltuples
                       ,
                      c.relpages

               FROM pg_catalog.pg_class c
                        LEFT JOIN pg_catalog.pg_inherits AS i ON c.oid = i.inhrelid
                    -- p = partitioned table, r = normal table
               WHERE c.relkind IN ('p', 'r')
                 -- not having a parent table -> we only get the partition heads
                 AND i.inhrelid IS NULL
               UNION ALL
               SELECT p.relnamespace,
                      p.parent    AS parent,
                      c.oid       AS relid,
                      p.level + 1 AS level
                       ,
                      p.reltuples
                       ,
                      p.relpages
               FROM tables AS p
                        LEFT JOIN pg_catalog.pg_inherits AS i ON p.relid = i.inhparent
                        LEFT JOIN pg_catalog.pg_class AS c ON c.oid = i.inhrelid AND c.relispartition
               WHERE c.oid IS NOT NULL),
    tabls_p_by_size as
        (SELECT relnamespace,
                parent ::REGCLASS                                  AS table_name,
                pg_size_pretty(sum(pg_total_relation_size(relid))) AS pretty_total_size,
                sum(pg_total_relation_size(relid))                 AS total_size_bt,
                sum(reltuples)                                     AS tuples,
                sum(relpages)                                      AS relpages,
                array_agg(relid :: REGCLASS)                       AS all_partitions
         FROM tables
         GROUP BY relnamespace, parent
         ORDER BY sum(pg_total_relation_size(relid)) DESC)

select ns.nspname                              as "table_schema"
     , tp.table_name                           AS "table_name"
     , tp.pretty_total_size
     , tp.total_size_bt
     , to_char(tp.tuples, '999 999 999 999')   as "tuples"
     , to_char(tp.relpages, '999 999 999 999') AS "pages"
     --, round((tp.tuples/COALESCE(tp.relpages,1)::numeric, 2) as "tuples_on_page"
     , tp.all_partitions
from tabls_p_by_size tp
         join pg_namespace ns
              on tp.relnamespace = ns.oid
order by tp.total_size_bt desc
limit 15;

\qecho '<p></p>'
\qecho '<P><A class=awr name=113></A>'
\qecho '<H3 class=awr>Секции по размеру</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания размера'
\qecho '</UL>'
\qecho '<p></p>'

SELECT relname                                       AS                           "relname"
     , nspname
     -- ,C.relkind AS "kind"
     , CASE
           WHEN C.relkind = 'r' THEN 'секция таблицы обычной'
           WHEN C.relkind = 'p' THEN 'таблица секционированная'
           WHEN C.relkind = 'i' THEN 'секция индекса обычного'
           WHEN C.relkind = 'S' THEN 'последовательность'
           WHEN C.relkind = 't' THEN 'секция таблицы TOAST'
           WHEN C.relkind = 'v' THEN 'представление'
           WHEN C.relkind = 'm' THEN 'представление материализованное'
           WHEN C.relkind = 'c' THEN 'составной тип'
           WHEN C.relkind = 'f' THEN 'секция таблицы сторонней'
           WHEN C.relkind = 'I' THEN 'индекс секционированный'

           ELSE 'не определено'
    END                                              as                           relkind
     -- ,C.relispartition AS "ispartition"
     --,C.relpartbound
     , to_char(C.reltuples, '999 999 999 999')       AS                           "tuples"
     , to_char(c.relpages, '999 999 999 999')        AS                           "pages"
     , round((C.reltuples / c.relpages)::numeric, 2) as                           "tuples_on_page"
     , pg_size_pretty(pg_total_relation_size(C.oid)) AS                           "ttl_size"
     -- pg_total_relation_size(C.oid)                 AS           "ttl_size_bt",
     , pg_size_pretty(COALESCE(pg_total_relation_size(reltoastrelid), 0))         "TOAST_size"

     , pg_size_pretty(pg_indexes_size(C.oid) +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'main') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init') +
                      COALESCE(pg_total_relation_size(reltoastrelid), 0))         "control"
     , pg_size_pretty(pg_indexes_size(C.oid))        AS                           "indexes_size"
     ,
     --pg_indexes_size(C.oid)                        AS           "indexes_size_bt",
    pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                     quote_ident(relname))::regclass, 'main'))    "main"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm'))  "fsm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm'))   "vm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init')) "init"
     -- reltoastrelid,
FROM pg_class C
         LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
WHERE 1 = 1
  and nspname NOT IN ('pg_catalog', 'information_schema')
  --AND nspname !~ '^pg_toast'
  AND C.relkind = 'r'
  AND C.relispartition = TRUE
  --  AND C.relname  LIKE 'HistoricNC_p2024_08_01_CO%'
  AND C.reltuples > 10000

  -- AND (C.reltuples > 1000000 OR pg_total_relation_size(C.oid) > (5*1024*1024*1024::BIGINT))
ORDER BY pg_total_relation_size(C.oid) DESC
LIMIT 15;

\qecho '<p></p>'
\qecho '<P><A class=awr name=113></A>'
\qecho '<H3 class=awr>Таблицы по размеру TOAST</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания размера TOAST'
\qecho '</UL>'

\qecho '<A class=awr_ital> When a column is written to the toast table, an OID is used to identify the chunk to be toasted. When a toast table grows very large, and contains chunk_ids that are nearing the value of 2^32, it can lead to performance degredation when writing to toast. This is because PostgreSQL must check if an OID is available for assignment by scanning the table </A>'
\qecho '<A class=awr_ital> A large Toast table can be a good indication that your toast can face OID wraparound </A>'
\qecho '<A class=awr_ital> over time the insert statement will be slower as the Database will be searching for an unused OID and it will have to read from the disk , you will see the insert statements is waiting on IPC:BufferiO or IO:DataFileRead  </A>'
\qecho '<A class=awr_ital> you can use below SQL to check the toast table  </A>'
\qecho '<A class=awr_ital> select COUNT(DISTINCT chunk_id),2^31 - COUNT(DISTINCT chunk_id) as remaining_OID ,ROUND(100*((2^31 - COUNT(DISTINCT chunk_id)))/2^31::float) AS remaining_OID_PCT ,ROUND(100*(COUNT(DISTINCT chunk_id)/2^31::float)) as percent_towards_Toast_oid_wraparound from pg_toast.pg_toast_{number};</A>'
\qecho '<A class=awr_ital> when the toast hits the OID wraparound, you will see the following wait event LWLock:OidGen and the insert statements will fail and you will see below error in the log file </A>'
\qecho <br>
\qecho '<A class=awr_ital> :LOG:  still searching for an unused OID in relation "pg_toast_{number}" </A>'
\qecho '<A class=awr_ital> :DETAIL:  OID candidates have been checked 1000000 times, but no unused OID has been found yet. </A>'
\qecho '<p></p>'

/*
select COUNT(DISTINCT chunk_id),
       2 ^ 31 - COUNT(DISTINCT chunk_id)                                  as remaining_OID,
       ROUND(100 * ((2 ^ 31 - COUNT(DISTINCT chunk_id))) / 2 ^ 31::float) AS remaining_OID_PCT,
       ROUND(100 * (COUNT(DISTINCT chunk_id) / 2 ^ 31::float))            as percent_towards_Toast_oid_wraparound
from pg_toast.pg_toast_64361;
*/

select t.relname                                            table_name,
       r.relname                                            toast_name,
       r.oid                                             as toast_oid,
       pg_relation_size(t.reltoastrelid)                 as toast_size_bytes,
       pg_size_pretty(pg_relation_size(t.reltoastrelid)) as toast_size
FROM pg_class r
         INNER JOIN pg_class t ON r.oid = t.reltoastrelid
order by toast_size_bytes desc
limit 15;

\qecho '<p></p>'
\qecho '<P><A class=awr name=112></A>'
\qecho '<H3 class=awr>Обычные таблицы по количеству строк на страницу в порядке возрастания "tuples_on_page".</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны у который строк более 1 млн'
\qecho '<LI class=awr>или суммарный размер более 5 Гб'
\qecho '</UL>'
\qecho '<p></p>'

SELECT nspname                                       as                           "table_schema"
     , relname                                       AS                           "table_name"
     , C.relkind                                     AS                           "kind"
     , C.relispartition                              AS                           "ispartition"
     , to_char(C.reltuples, '999 999 999 999')       AS                           "tuples"
     , to_char(c.relpages, '999 999 999 999')        AS                           "pages"
     , round((C.reltuples / c.relpages)::numeric, 2) as                           "tuples_on_page"
     , pg_size_pretty(pg_total_relation_size(C.oid)) AS                           "ttl_size"
     -- pg_total_relation_size(C.oid)                 AS           "ttl_size_bt",
     , pg_size_pretty(COALESCE(pg_total_relation_size(reltoastrelid), 0))         "TOAST_size"

     , pg_size_pretty(pg_indexes_size(C.oid) +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'main') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init') +
                      COALESCE(pg_total_relation_size(reltoastrelid), 0))         "control"
     , pg_size_pretty(pg_indexes_size(C.oid))        AS                           "indexes_size"
     ,
     --pg_indexes_size(C.oid)                        AS           "indexes_size_bt",
    pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                     quote_ident(relname))::regclass, 'main'))    "main"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm'))  "fsm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm'))   "vm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init')) "init"
     -- reltoastrelid,
FROM pg_class C
         LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
WHERE nspname NOT IN ('pg_catalog', 'information_schema')
  AND C.relkind = 'r'
  AND C.relispartition = FALSE
  AND nspname !~ '^pg_toast'
  AND (C.reltuples > 1000000 OR pg_total_relation_size(C.oid) > (5 * 1024 * 1024 * 1024::BIGINT))
ORDER BY "tuples_on_page"
LIMIT 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=113></A>'
\qecho '<H3 class=awr>Секции по количеству строк  на страницу</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке возрастания "tuples_on_page"'
\qecho '</UL>'
\qecho '<p></p>'

SELECT relname                                       AS                           "relname"
     , nspname
     -- ,C.relkind AS "kind"
     , CASE
           WHEN C.relkind = 'r' THEN 'секция таблицы обычной'
           WHEN C.relkind = 'p' THEN 'таблица секционированная'
           WHEN C.relkind = 'i' THEN 'секция индекса обычного'
           WHEN C.relkind = 'S' THEN 'последовательность'
           WHEN C.relkind = 't' THEN 'секция таблицы TOAST'
           WHEN C.relkind = 'v' THEN 'представление'
           WHEN C.relkind = 'm' THEN 'представление материализованное'
           WHEN C.relkind = 'c' THEN 'составной тип'
           WHEN C.relkind = 'f' THEN 'секция таблицы сторонней'
           WHEN C.relkind = 'I' THEN 'индекс секционированный'

           ELSE 'не определено'
    END                                              as                           relkind
     -- ,C.relispartition AS "ispartition"
     --,C.relpartbound
     , to_char(C.reltuples, '999 999 999 999')       AS                           "tuples"
     , to_char(c.relpages, '999 999 999 999')        AS                           "pages"
     , round((C.reltuples / c.relpages)::numeric, 2) as                           "tuples_on_page"
     , pg_size_pretty(pg_total_relation_size(C.oid)) AS                           "ttl_size"
     -- pg_total_relation_size(C.oid)                 AS           "ttl_size_bt",
     , pg_size_pretty(COALESCE(pg_total_relation_size(reltoastrelid), 0))         "TOAST_size"

     , pg_size_pretty(pg_indexes_size(C.oid) +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'main') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init') +
                      COALESCE(pg_total_relation_size(reltoastrelid), 0))         "control"
     , pg_size_pretty(pg_indexes_size(C.oid))        AS                           "indexes_size"
     ,
     --pg_indexes_size(C.oid)                        AS           "indexes_size_bt",
    pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                     quote_ident(relname))::regclass, 'main'))    "main"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm'))  "fsm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm'))   "vm"
     , pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init')) "init"
     -- reltoastrelid,
FROM pg_class C
         LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
WHERE 1 = 1
  and nspname NOT IN ('pg_catalog', 'information_schema')
  --AND nspname !~ '^pg_toast'
  AND C.relkind = 'r'
  AND C.relispartition = TRUE
  -- AND C.relname  LIKE 'extract_app_1%'
  AND C.reltuples > 100000

  -- AND (C.reltuples > 1000000 OR pg_total_relation_size(C.oid) > (5*1024*1024*1024::BIGINT))
ORDER BY "tuples_on_page"
LIMIT 15;


\qecho '<p></p>'
\qecho '<P><A class=awr name=113></A>'
\qecho '<H3 class=awr>Таблицы с большим количеством полей</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания количества полей'
\qecho '</UL>'
\qecho '<p></p>'

SELECT CO.table_catalog as db_name, CO.table_schema, CO.table_name, COUNT(*) as cnt_fields
FROM INFORMATION_SCHEMA.COLUMNS CO
         join pg_class C on c.relname = co.table_name
         LEFT JOIN pg_catalog.pg_inherits AS i ON c.oid = i.inhrelid
WHERE 1 = 1
  and c.relkind IN ('p', 'r')
  -- not having a parent table -> we only get the partition heads
  AND i.inhrelid IS NULL
GROUP BY CO.table_catalog, CO.table_schema, CO.table_name
ORDER BY 4 DESC
limit 15;



\qecho '<p></p>'
\qecho '<P><A class=awr name=114></A>'
\qecho '<H3 class=awr>Материализованные представления (materialized view)</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания размера'
\qecho '</UL>'
\qecho '<p></p>'


SELECT relname                                       AS                           "relname",
       nspname
        ,
       C.relkind                                     AS                           "kind"
        ,
       C.relispartition                              AS                           "ispartition"
        ,
       to_char(C.reltuples, '999 999 999 999')       AS                           "reltuples"
        ,
       pg_size_pretty(pg_total_relation_size(C.oid)) AS                           "ttl_size"
       -- pg_total_relation_size(C.oid)                 AS           "ttl_size_bt",
        ,
       pg_size_pretty(COALESCE(pg_total_relation_size(reltoastrelid), 0))         "TOAST_size"
        ,
       pg_size_pretty(pg_indexes_size(C.oid) +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'main') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm') +
                      pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init') +
                      COALESCE(pg_total_relation_size(reltoastrelid), 0))         "control",

       pg_size_pretty(pg_indexes_size(C.oid))        AS                           "indexes_size",
       --pg_indexes_size(C.oid)                        AS           "indexes_size_bt",
       pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'main')) "main",
       pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'fsm'))  "fsm",
       pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'vm'))   "vm",
       pg_size_pretty(pg_relation_size((quote_ident(nspname) || '.' ||
                                        quote_ident(relname))::regclass, 'init')) "init"
       -- reltoastrelid,
FROM pg_class C
         LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
WHERE nspname NOT IN ('pg_catalog', 'information_schema')
  AND C.relkind = 'm'
  AND nspname !~ '^pg_toast'
--  AND (C.reltuples > 1000000 OR pg_total_relation_size(C.oid) > (5*1024*1024*1024::BIGINT))
ORDER BY pg_total_relation_size(C.oid) DESC
LIMIT 10;

/*
select * from pg_partitioned_table
partition системной таблицы
select * from system. parts;
SELECT inhparent::pg_catalog.regclass,
  pg_catalog.pg_get_expr(c.relpartbound, c.oid),
  inhdetachpending
FROM pg_catalog.pg_class c JOIN pg_catalog.pg_inherits i ON c.oid = inhrelid
WHERE c.oid = '226340';
*/

\qecho '<p></p>'
\qecho '<P><A class=awr name=116></A>'
\qecho '<H3 class=awr>Таблицы с большим количеством полных чтений</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания Суммы прочитанных строк '
\qecho '<LI class=awr>Планы запросов с последовательными чтения к таблице можно посмотреть в отчете по БД postgres'
\qecho '<LI class=awr>в разделе Планы выполнения запросов поиск по контексту,например, Seq Scan on r_banner_status'

\qecho '</UL>'
\qecho '<p></p>'

SELECT seq_tup_read                                   as "Сумма строк"
        ,
       seq_scan                                          "Полных чтений"
        ,
       seq_tup_read / seq_scan                        as " Строк на проход"
        ,
       n_live_tup
       , seq_scan / (seq_scan + idx_scan)             as "доля последовательных обращений"
        ,
       relname                                           "Таблица",

       -- pg_size_pretty(pg_relation_size(relname::regclass)) AS "Размер",
       pg_size_pretty(pg_table_size(relid::regclass)) AS "Размер",


       idx_scan,
       idx_tup_fetch
       --idx_tup_fetch / idx_scan                            as avg_rows_indx
FROM pg_stat_all_tables
WHERE 1 = 1
  -- and schemaname = 'public'
  --and pg_relation_size(relname::regclass) > 1024 * 1024
  and seq_scan > 0
ORDER BY seq_tup_read DESC
LIMIT 10;

/*
WITH a_list_tabl as
(
SELECT row_number() over (order by seq_tup_read DESC nulls last) as rownum
       ,seq_tup_read                                        as "Сумма строк"
       , seq_scan                                               "Полных чтений"
--        ,seq_tup_read / seq_scan                             as " Строк на проход"
        ,relname
FROM pg_stat_all_tables
WHERE  -- schemaname = 'public'
    -- and pg_relation_size(relname::regclass) > 1024 * 1024
     seq_scan >0
    -- and seq_tup_read / seq_scan >1000
ORDER BY seq_tup_read DESC
LIMIT 10)

select relname AS vt_relname_1 from a_list_tabl where rownum =1 ;

\gset
\qecho ':vt_relname_1' :vt_relname_1

select db.datname as db
     , rl.rolname as role
     , p.queryid
     , p.planid
     , p.plan
     -- ,''  AS "Query_text"
from pg_store_plans p
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
where 1 = 1
  and p.planid in (select distinct p1.planid from pg_store_plans p1)
  and p.plan like '%Seq Scan on r_banner_status%'   --'%Seq Scan%'
order by db.datname, rl.rolname, p.queryid, p.plan
;


/*select current_setting('server_version_num')::integer < 130000::integer as ver_less_13;
\gset
\qecho ':vt_ch_ver' :ver_less_13*/

\if :ver_less_13
   -- версия меньше 13
   SELECT SS.queryid,
       SS.calls,
       ROUND(SS.total_time / 1000)            AS "total_time_s",
       ROUND(SS.total_time / SS.calls / 1000) AS "time_on_call_s",
       SS.query
FROM pg_stat_statements SS
WHERE SS.query LIKE '%:vt_relname_1%'
  AND SS.calls > 0
  AND ROUND(SS.total_time / 1000) > 1
ORDER BY SS.total_time DESC;

\else
   SELECT ':vt_relname_1' AS "Таблица с полными чтенями"
       ,SS.queryid
       ,SS.calls
       ,ROUND(SS.total_exec_time / 1000)            AS "total_time_s"
       ,ROUND(SS.total_exec_time / SS.calls / 1000) AS "time_on_call_s"
       ,SS.query
FROM pg_stat_statements SS
WHERE lower(SS.query) LIKE lower('%:vt_relname_1%')
  AND SS.calls > 0
  -- AND ROUND(SS.total_exec_time / 1000) > 1
ORDER BY SS.total_exec_time DESC;

\endif


WITH a_list_tabl as
(
SELECT row_number() over (order by seq_tup_read DESC nulls last) as rownum
       ,seq_tup_read                                        as "Сумма строк"
       , seq_scan                                               "Полных чтений"
        ,seq_tup_read / seq_scan                             as " Строк на проход"
        ,relname
FROM pg_stat_all_tables
WHERE  schemaname = 'public'
    -- and pg_relation_size(relname::regclass) > 1024 * 1024
    and seq_scan >0
    and seq_tup_read / seq_scan >1000
ORDER BY seq_tup_read DESC
LIMIT 10)
select relname AS vt_relname_2 from a_list_tabl where rownum =2 ;
\gset
-- \qecho ':vt_relname_2' :vt_relname_2

\if :ver_less_13
   -- версия меньше 13
   SELECT SS.queryid,
       SS.calls,
       ROUND(SS.total_time / 1000)            AS "total_time_s",
       ROUND(SS.total_time / SS.calls / 1000) AS "time_on_call_s",
       SS.query
FROM pg_stat_statements SS
WHERE SS.query LIKE '%:vt_relname_2%'
  AND SS.calls > 0
  AND ROUND(SS.total_time / 1000) > 1
ORDER BY SS.total_time DESC;

\else
   SELECT ':vt_relname_2' AS "Таблица с полными чтенями"
       ,SS.queryid
       ,SS.calls
       ,ROUND(SS.total_exec_time / 1000)            AS "total_time_s"
       ,ROUND(SS.total_exec_time / SS.calls / 1000) AS "time_on_call_s"
       ,SS.query
FROM pg_stat_statements SS
WHERE lower(SS.query) LIKE lower('%:vt_relname_2%')
  AND SS.calls > 0
  -- AND ROUND(SS.total_exec_time / 1000) > 1
ORDER BY SS.total_exec_time DESC;

\endif

WITH a_list_tabl as
(
SELECT row_number() over (order by seq_tup_read DESC nulls last) as rownum
       ,seq_tup_read                                        as "Сумма строк"
       , seq_scan                                               "Полных чтений"
        ,seq_tup_read / seq_scan                             as " Строк на проход"
        ,relname
FROM pg_stat_all_tables
WHERE  schemaname = 'public'
    -- and pg_relation_size(relname::regclass) > 1024 * 1024
    and seq_scan >0
    and seq_tup_read / seq_scan >1000
ORDER BY seq_tup_read DESC
LIMIT 10)
select relname AS vt_relname_3 from a_list_tabl where rownum =3 ;
\gset
-- \qecho ':vt_relname_3' :vt_relname_3

\if :ver_less_13
   -- версия меньше 13
   SELECT SS.queryid,
       SS.calls,
       ROUND(SS.total_time / 1000)            AS "total_time_s",
       ROUND(SS.total_time / SS.calls / 1000) AS "time_on_call_s",
       SS.query
FROM pg_stat_statements SS
WHERE SS.query LIKE '%:vt_relname_3%'
  AND SS.calls > 0
  AND ROUND(SS.total_time / 1000) > 1
ORDER BY SS.total_time DESC;

\else
   SELECT ':vt_relname_3' AS "Таблица с полными чтенями"
       ,SS.queryid
       ,SS.calls
       ,ROUND(SS.total_exec_time / 1000)            AS "total_time_s"
       ,ROUND(SS.total_exec_time / SS.calls / 1000) AS "time_on_call_s"
       ,SS.query
FROM pg_stat_statements SS
WHERE lower(SS.query) LIKE lower('%:vt_relname_3%')
  AND SS.calls > 0
  -- AND ROUND(SS.total_exec_time / 1000) > 1
ORDER BY SS.total_exec_time DESC;

\endif
*/

\qecho '<p></p>'
\qecho '<P><A class=awr name=117></A>'
\qecho '<H3 class=awr>Таблицы с большим количеством блоков, прочитанных с диска</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания heap_blks_read'
\qecho '</UL>'
\qecho '<p></p>'

select *
from pg_statio_all_tables
where heap_blks_read > 0
order by heap_blks_read desc
limit 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=117></A>'
\qecho '<H3 class=awr>Таблицы с большим количество блоков всех индексов, принадлежащих этой таблице, прочитанных с диска</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания idx_blks_read '
\qecho '</UL>'
\qecho '<p></p>'

select *
from pg_statio_all_tables
where idx_blks_read > 0
order by idx_blks_read desc
limit 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=118></A>'
\qecho '<H3 class=awr>Таблицы с большим количеством блоков TOAST-таблицы, прочитанных с диска.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания toast_blks_read'
\qecho '</UL>'
\qecho '<p></p>'

select *
from pg_statio_all_tables
where toast_blks_read > 0
order by toast_blks_read desc
limit 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=119></A>'
\qecho '<H3 class=awr>Таблицы с большим количеством блоков индексов TOAST-таблицы, прочитанных с диска.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания tidx_blks_read'
\qecho '</UL>'
\qecho '<p></p>'

select *
from pg_statio_all_tables
where tidx_blks_read > 0
order by tidx_blks_read desc
limit 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=120></A>'
\qecho '<H3 class=awr>Последовательности с большим количеством блоков, прочитанных с диска.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания blks_read'
\qecho '</UL>'
\qecho '<p></p>'

select *
from pg_statio_all_sequences
where blks_read > 0
order by blks_read desc
limit 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=120></A>'
\qecho '<H3 class=awr>Используемые последовательности</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке убывания last_value- start_value'
\qecho '</UL>'
\qecho '<p></p>'

select sq.*, (sq.max_value - sq.last_value) as remainder
from pg_sequences sq
where sq.last_value > 0
order by (sq.last_value - sq.start_value) desc
limit 10;

\qecho '<p></p>'
\qecho '<P><A class=awr name=120></A>'
\qecho '<H3 class=awr>Неиспользуемые последовательности</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 10 в порядке sequencename'
\qecho '</UL>'
\qecho '<p></p>'

select sq.*, (sq.max_value - sq.last_value) as remainder
from pg_sequences sq
where sq.last_value is null
order by sq.sequencename
limit 10;

\qecho </details>

\qecho '<p></p>'
\qecho <P><A class=awr href="#111">Back to Таблицы. Партиции. Последовательности.</A> <BR><A class=awr href="#top">Back to Top</A>

/*

SELECT * FROM dblink('dbname=postgres options=-csearch_path=',
                     'select shared_blks_read, rows, query from pg_stat_statements')
  AS t1(shared_blks_read bigint, rows bigint,  query text) WHERE shared_blks_read > 10;

SELECT * FROM dblink('dbname=pega options=-csearch_path=',
                     'SELECT seq_tup_read from pg_stat_all_tables')
  AS t1(seq_tup_read bigint) WHERE seq_tup_read > 10;



-- select count(*) from act_ru_ext_task

SELECT * FROM dblink('dbname=postgres options=-csearch_path=',
                     'select shared_blks_read, rows, query from pg_stat_statements')
  AS t1(shared_blks_read bigint, rows bigint,  query text) WHERE shared_blks_read > 10;

 */

