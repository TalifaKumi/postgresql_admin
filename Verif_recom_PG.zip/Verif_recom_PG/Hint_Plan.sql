\qecho '<p></p>'
\qecho '<P><A class=awr name=172></A>'
\qecho '<H3 class=awr>Текущие настройки расширения pg_hint_plan</H3>'
\qecho '<p></p>'

SELECT *
from pg_catalog.pg_settings
WHERE NAME LIKE '%pg_hint_plan%'
ORDER BY 1;

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Подсказки в таблице pg_hint_plan</H3>'
\qecho '<p></p>'

SELECT count(*) as "Всего задано подсказок в таблице"
FROM hint_plan.hints;

SELECT *
FROM hint_plan.hints
limit 20;

\qecho <P><A class=awr href="#171">Back to Планы выполнения запросов</A> <BR><A class=awr href="#top">Back to Top</A>

/*
SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

Aggregate  (cost=2.49..2.50 rows=1 width=8) (actual time=0.043..0.043 rows=1 loops=1)
  ->  Index Only Scan using pg_class_relname_nsp_index on pg_class t  (cost=0.28..2.49 rows=1 width=0) (actual time=0.039..0.040 rows=1 loops=1)
        Index Cond: (relname = 'pg_type'::name)
        Heap Fetches: 1
Planning Time: 0.059 ms
Execution Time: 0.135 ms


SELECT /*+ SeqScan(t) */ count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

Aggregate  (cost=32.00..32.01 rows=1 width=8) (actual time=0.079..0.079 rows=1 loops=1)
  ->  Seq Scan on pg_class t  (cost=0.00..32.00 rows=1 width=0) (actual time=0.008..0.076 rows=1 loops=1)
        Filter: (relname = 'pg_type'::name)
        Rows Removed by Filter: 639
Planning Time: 0.077 ms
Execution Time: 0.166 ms



/*+ SeqScan(t) */ SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

 UPDATE hint_plan.hints
    SET norm_query_string = 'SELECT count(*) FROM pg_catalog.pg_class t where t.relname = ?;'
  WHERE id = 2;
COMMIT;

 DELETE FROM hint_plan.hints WHERE id = 1;

INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;',
         '',
         'SeqScan(t)');
COMMIT;

SELECT count(*)
                  FROM pg_catalog.pg_class t
                  LIMIT 501
-- 1103
SELECT count(*)
                  FROM pg_catalog.pg_class t
where t.relname like '%log%'

SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT count(*) FROM pg_catalog.pg_class t where t.relname = ''pg_type'';',
         '',
         'SeqScan(t)');
COMMIT;



EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;

INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;',
         '',
         'SeqScan(t)');
COMMIT;



INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;',
         '',
         'SeqScan(t) Parallel(t 4 hard)');

 UPDATE hint_plan.hints
    SET hints = 'SeqScan(t)'
  WHERE id = 2;

 DELETE FROM hint_plan.hints
  WHERE id = 2;


 INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT * FROM t1 WHERE t1.id = ?;',
         '',
         'SeqScan(t1)');
COMMIT;

-- INSERT 0 1
 UPDATE hint_plan.hints
    SET hints = 'IndexScan(t1)'
  WHERE id = 1;
 UPDATE 1
 DELETE FROM hint_plan.hints
  WHERE id = 1;
 DELETE 1


DELETE FROM hint_plan.hints WHERE ID=1;


SET pg_hint_plan.enable_hint_table TO on;

 SELECT *
from pg_catalog.pg_settings
WHERE  NAME LIKE  '%pgaudit%'
ORDER BY  1;

 */

\qecho <P><A class=awr href="#172">Back to >Текущие настройки расширения pg_hint_plan</A> <BR><A class=awr href="#top">Back to Top</A>
