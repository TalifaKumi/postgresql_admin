\qecho '<H2 class=awr>WAL</H2>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Скрипт WAL.sql'
\qecho '</UL>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H3 class=awr>Настройки инстанса по WAL.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны только те настройки, которые проверялись'
\qecho '<LI class=awr>check = 0 Обязательно изменить!'
\qecho '<LI class=awr>check = 1 Соответствует рекомендациям.!'
\qecho '<LI class=awr>check = 2 Следует обратить внимание.'
\qecho '</UL>'
\qecho '<p></p>'

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '99G999') >= 300 AND to_number(setting, '99G999') <= 600  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '99G999') >= 300 AND to_number(setting, '99G999') <= 600 THEN '+ Задано значение из рекомендованного диапозона '
           ELSE '-  Задано значение НЕ из рекомендованного диапозона'
           END                                  "Comment",
          'Рекомендованное значение от 300 до 600 секунд'  "Рекомендации"
        , context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'checkpoint_timeout'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '99G999') = 0.9  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '99G999') = 0.9 THEN '+ Задано рекомендуемое значение '
           ELSE ''
           END                                  "Comment",
       CASE WHEN to_number(setting, '99G999') >= 0
               THEN
               ''
           ELSE
               'Рекомендованное значение 0.9 для большей равномерности. Но не более 1'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'checkpoint_completion_target'

union

select name                                     "parameter"
       ,setting || ' ' || COALESCE(unit,'')  as "setting"
       /*,CASE
           WHEN unit = 'MB' THEN to_number(setting, '999G999G999') * 1024 * 1024
           WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
           ELSE to_number(setting, '999G999G999G999') END "size_bt"
        */
       ,CASE WHEN CASE
           WHEN unit = 'MB' THEN to_number(setting, '999G999G999') * 1024 * 1024
           WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
           ELSE to_number(setting, '999G999G999G999') END <= 2* 1024 * 1024  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '99G999') > 2* 1024 * 1024 THEN '+ '
           ELSE ''
           END                                  "Comment",
       CASE WHEN CASE
           WHEN unit = 'MB' THEN to_number(setting, '999G999G999') * 1024 * 1024
           WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
           ELSE to_number(setting, '999G999G999G999') END < 2* 1024 * 1024
               THEN
               ''
           ELSE
               'Рассмотрите возможность увеличения'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_wal_size'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ файлы WAL используются повторно (для этого они переименовываются), что избавляет от необходимости создавать новые файлы'
           ELSE 'Режим повторного использования файлов отключен'
           END                                  "Comment",
       CASE setting
           WHEN '1'
               THEN
               ''
           ELSE
               ' В файловых системах COW может быть быстрее создать новые файлы, поэтому данный параметр позволяет отключить это поведение.'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'wal_recycle'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '99G999') >= 100  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '99G999') >= 100 THEN '+ '
           ELSE ''
           END                                  "Comment",
       CASE WHEN to_number(setting, '99G999') >= 100
               THEN
               ''
           ELSE
               'Рассмотрите возможность увеличения, если количество СтоповФП значительно'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'bgwriter_lru_maxpages'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999999') >= 2  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '999999') >= 2 THEN '+ '
           ELSE ''
           END                                  "Comment",
       CASE WHEN to_number(setting, '999999') >= 2
               THEN
               ''
           ELSE
               'Рассмотрите возможность увеличения, если количество СтоповФП значительно'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'bgwriter_lru_multiplier'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '99G999') >= 120  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '99G999') >= 120 THEN '+ '
           ELSE ''
           END                                  "Comment",
       CASE WHEN to_number(setting, '99G999') >= 0
               THEN
               ''
           ELSE
               'Рекомендованное значение checkpoint_timeout/2 но не менее 120 сек По умолчанию 30 сек'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'checkpoint_warning'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'off' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN ' Включен вывод в журнал подробной информации о каждой выполненной контрольной точке'
           ELSE 'НЕ включен вывод в журнал подробной информации о каждой выполненной контрольной точке'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Включать для получения подробной информации о каждой выполненной контрольной точке ALTER SYSTEM SET log_checkpoints = on; SELECT pg_reload_conf();'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'log_checkpoints'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'pglz' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'off' THEN 'Значение по умолчанию — off. Сжатие WAL не включено'
           WHEN 'on' THEN 'Значение on, PG сжимает образ полной страницы, записываемый в WAL, когда включён режим full_page_writes или при создании базовой копии'
           WHEN 'pglz' THEN ' Включен Сжатие WAL по методу pglz '
           ELSE 'НЕ определено'
           END                                  "Comment",
           'Включает сжатие WAL указанным методом. Если этот параметр имеет значение on, сервер PostgreSQL сжимает образ полной страницы, записываемый в WAL, когда включён режим full_page_writes. Значение по умолчанию — off.'
                                             "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'wal_compression'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'off' THEN 'Отключать не рекомендуется !'
           WHEN 'on' THEN 'Значение on по умолчанию'
           ELSE 'НЕ определено !'
           END                                  "Comment",
           'Когда включён, PG записывает в WAL всё содержимое каждой страницы при первом изменении этой страницы после контрольной точки.По умолчанию on'
                                             "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'full_page_writes'

union




select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '99G999') >= 120  THEN 1 ELSE 2 END "check",
       CASE WHEN to_number(setting, '99G999') >= 120 THEN '+ '
           ELSE ''
           END                                  "Comment",
       CASE WHEN to_number(setting, '99G999') <= 30
               THEN
               ''
           ELSE
               'max_wal_senders должно быть значение как минимум равное max_replication_slots плюс число возможных физических реплик, работающих одновременно.'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_wal_senders'


;

\qecho '<p></p>'
\qecho '<P><A class=awr name=210></A>'
\qecho '<H3 class=awr>Статистика по WAL</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>КТ - контрольная точка( CP - checkpoint)'
\qecho '<LI class=awr>ФП - фоновый процесс'
\qecho '<LI class=awr>СП - серверный процесс(backend)'
\qecho '</UL>'
\qecho '<p></p>'

-- https://habr.com/ru/companies/postgrespro/articles/460423/

SELECT sw.checkpoints_timed AS "КТ по рассписанию"
       ,sw.checkpoints_req AS "КТ требов"
       ,ROUND(sw.checkpoints_req*100/(sw.checkpoints_req +sw.checkpoints_timed)) AS "%КТ треб"
       ,ROUND(sw.checkpoint_write_time/1000) AS "CP_write_time_sec"
       ,ROUND(sw.checkpoint_sync_time/1000) AS "CP_sync_time_sec"
       ,ROUND(sw.buffers_clean*100/sw.buffers_checkpoint) AS "%Фоновых"
       ,ROUND(sw.buffers_backend*100/sw.buffers_checkpoint) AS "%backend"
       ,sw.maxwritten_clean AS "СтоповФП"
       ,to_char(sw.stats_reset,'YY-MM-DD HH24:MI:SS') AS "Стат с даты"
 FROM pg_stat_bgwriter sw;
\qecho '<p></p>'