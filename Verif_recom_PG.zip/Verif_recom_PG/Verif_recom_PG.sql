-- Варианты запуска скриптов

-- Вариант 1. Запуск подготовки отчетов в итерационном режиме
-- (название проекта и путь для отчета задается в консоли)

-- Перейти в директорию со скриптами
-- \cd d:/PostgreSQL/SQL/Verif_recom_PG

-- Запустить головной  файл
-- \i Verif_recom_PG.sql

-- Вариант 2. Запустить подготовку отчетов, с параметрами, заданными в файле

-- Перейти в директорию со скриптами
-- \cd d:/PostgreSQL/SQL/Verif_recom_PG

-- Запустить файл с установками + головной файл
-- \i Start_With_Sets_Verif_recom_PG.sql

-- \qecho 'vt_project:' :vt_project

-- Запуск pg_collector
--\cd d:/PostgreSQL/SQL/PG_COLLECTOR/pg-collector-pg-collector-for-postgresql-16
--\cd d:/PostgreSQL/SQL/PG_COLLECTOR/pg-collector-pg-collector-for-postgresql-15

--\i pg_collector.sql
--\q

-- Запуск dba-master
-- \i d:/PostgreSQL/SQL/postgres_dba-master/start.psql

-- Комментарий - метка запросов скриптов по проверке рекомендаций
/* VR_PG */

-- Ctrl   Slash  : for single line comments (   --...  )
-- Ctrl   /**/Shift   Slash  : for block comments (  /*...*/  )

-- Сброс данных предыдущего профилирования
-- SELECT pl_profiler_reset_local();
-- select pl_profiler_reset_shared();

-- Включить профилирование сессии
-- select pl_profiler_set_enabled_local(false);
-- select pl_profiler_set_enabled_global(true);

set work_mem = '4GB';
set maintenance_work_mem ='4GB';

-- Проверить версии функций, обновить версии и создать функции, если их нет
\i VER_FUNCTIONS.sql

-- Creating temporary table for SAVING THE SCRIPTS DIRECTORY
DO LANGUAGE plpgsql
$$
    BEGIN
        IF public.ver_if_tmp_table_exists('tmp_table_scripts_dir') THEN
            TRUNCATE TABLE tmp_table_scripts_dir;
        ELSE
            CREATE TEMP TABLE IF NOT EXISTS tmp_table_scripts_dir
            (
                value TEXT
            );
        END IF;
    END
$$;

-- Сохранить полный путь к текущей директории в файл
\! echo %cd% > tmp_scripts_dir.txt;

-- select * from tmp_table_scripts_dir;

\copy tmp_table_scripts_dir (value) FROM 'tmp_scripts_dir.txt' WITH (FORMAT csv);

select replace(value,' ;','') as vt_scripts_dir from tmp_table_scripts_dir;
\gset
--\qecho 'vt_scripts_dir:' :vt_scripts_dir

-- Копировние настроек инстанса из внешнего файла csv в таблицу public.ver_imported_pg_settings
\i Copy_settings_from_csv_file.sql

select current_database() = 'postgres'  AS current_db_postgres;
\gset

\if :current_db_postgres
\qecho '<H2 class=awr>postgres</H2>'
\else
\i ver_create_conn_db2postgres.sql
\endif

-- Задать имя проекта и настройки отчета
\i SET_SETTINGS_REPORT.sql

\i VERS_HOST_INST_DBS.sql

-- \i Over_Installed_Extensions.sql

\i EXTENTIONS.sql

-- Основные настройки инстанса.
\i Basic_Setting.sql

-- Настройки догирования в журнал
\i LOG_SETTINGS.sql

-- Информация по соединениям.
\i CONNECTIONS.sql

\i TRANSACTIONS.sql
\i LOCKS.sql

\i SHARED_MEMORY.sql

-- Временные файлы(Temporary files)
\if :current_db_postgres
\i TMP_Files.sql
\endif

--

\if :current_db_postgres
\i Queries_TOP_10.sql
\endif

\if :set_pg_store_plans
\i Plans.sql
\else
\qecho '<H2 class=awr>Расширение pg_store_plans не установлено</H2>'
\endif

-- Эти пункты только для БД postgres
\if :current_db_postgres

\if :set_pg_hint_plan
\i Hint_Plan.sql
\else
\qecho '<P><A class=awr name=181></A>'
\qecho '<H2 class=awr>Расширение pg_hint_plan не установлено</H2>'
\qecho '<p></p>'
\endif

\if :set_pg_wait_sampling

\i WAITING_EVENTS.sql
\else
\qecho '<P><A class=awr name=181></A>'
\qecho '<H2 class=awr>Расширение pg_wait_sampling не установлено</H2>'
\qecho '<p></p>'
\endif

\if :set_system_stats

\i SYSTEM_STATS_GENERAL.sql
\i SYSTEM_STATS.sql
\else
\qecho '<P><A class=awr name=191></A>'
\qecho '<H2 class=awr>Расширение set_system_stats не установлено</H2>'
\qecho '<p></p>'
\endif

\else

-- Для остальных БД попытка получить через dblink
\if :set_dblink

/*
SELECT dblink_get_connections();
SELECT dblink_connect('con_ver_postgres', 'dbname=postgres options=-csearch_path=');

SELECT *
          FROM dblink('con_ver_postgres',
                      'select userid, dbid, queryid, planid, plan, calls, total_time, min_time, max_time, mean_time, stddev_time, rows
                          ,shared_blks_hit, shared_blks_read, shared_blks_dirtied, shared_blks_written, local_blks_hit
             ,local_blks_read, local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written, blk_read_time
             ,blk_write_time, temp_blk_read_time, temp_blk_write_time, first_call, last_call
      from public.pg_store_plans')
    AS t1(userid oid, dbid oid, queryid bigint, planid bigint, plan text, calls bigint, total_time double precision
             ,min_time double precision , max_time double precision, mean_time double precision, stddev_time double precision
             ,rows bigint
             ,shared_blks_hit bigint, shared_blks_read bigint, shared_blks_dirtied bigint, shared_blks_written bigint, local_blks_hit bigint
             ,local_blks_read bigint, local_blks_dirtied bigint, local_blks_written bigint , temp_blks_read bigint, temp_blks_written bigint
             ,blk_read_time double precision
             ,blk_write_time double precision, temp_blk_read_time double precision, temp_blk_write_time double precision
            ,first_call timestamp with time zone, last_call timestamp with time zone
           );


SELECT dblink_disconnect('con_ver_postgres');
*/

\else
\qecho '<p></p>'
\qecho '<H2 class=awr>Расширение не установлено</H2>'
\qecho '<p></p>'

\endif
-- по dblink установлено

\endif
-- Окончание по :current_db_postgres


\i WAL.sql

-- VACUUM и ANALYZE
\i Vacuum_Analyze.sql

\i FILLFACTOR.sql

\i BLOAT.sql
-- Определение свободного места в таблице с использованием pgstattuple_approx
-- \i BLOAT_TABLE_pgstattuple_approx.sql
-- Определение свободного места в таблице с исполльзованием pgstattuple_approx
-- \i BLOAT_TABLE_pgstattuple.sql

\i Planner_Optimizer.sql

-- Таблицы
\if :current_db_postgres
\else
\i TABLES.sql
\i INDEXES.sql
\endif

\qecho '<P>'
\qecho '<P>End of Report </P></BODY></HTML>'

\o
\qecho 'File Created: ':vt_out_file


-- Подготовка скриптов по рекомендациям
\i Prepare_SQL_SCRIPTS.sql
\o
\qecho 'File Created:':vt_out_file_txt

-- Создание отчета pg_profile по двум последним снимкам
\if :current_db_postgres
\i Get_PG_PROFILE_report.sql
\o

\else
\i Get_PG_PROFILE_report_DBLINK.sql
\o
\qecho 'File Created:':vt_out_file_profile

\endif
\o

-- Копирование настроек инстанса в csv файл
\i Copy_settings_to_csv_file.sql

-- Сжать все файлы отчетов в один  файл-архив zip
\i Compress_Files.sql

--RESET work_mem;
--set work_mem = '56MB';
--reset maintenance_work_mem;

-- Собрать данные профилирования
-- select pl_profiler_collect_data();

-- Отключить профилирование
-- select pl_profiler_set_enabled_global(false);










