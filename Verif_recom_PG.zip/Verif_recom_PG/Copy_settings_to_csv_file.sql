-- Копирование настроек инстанса в csv файл
-- Скрипт \i Copy_settings_to_csv_file.sql

\o
-- Формирование полного названия файла формата csv для сохрания текущих настроек инстанса
 \set vt_out_csv_file_pg_setting :vt_single_quotation_mark:vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_pg_settings:vt_tail_csv:vt_single_quotation_mark

--\set vt_out_csv_file_pg_setting '''d:/temp/test.csv'''
-- \qecho ':vt_out_csv_file_pg_setting' :vt_out_csv_file_pg_setting

\set vt_copy_settings_to_csv_file 'tmp_copy_settings_to_csv_file.sql'
-- \qecho ':vt_copy_settings_to_csv_file'  :vt_copy_settings_to_csv_file

-- \qecho ':vt_project_mark' :vt_project_mark
\set vt_project_3_mark :vt_single_quotation_mark:vt_single_quotation_mark:vt_project_mark:vt_single_quotation_mark:vt_single_quotation_mark
-- \qecho ':vt_project_2_mark' :vt_project_3_mark

\o :vt_copy_settings_to_csv_file
\pset tuples_only on
\pset border 0
-- SELECT '\COPY (select * from pg_catalog.pg_settings) TO '|| :vt_out_csv_file_pg_setting ||' CSV HEADER;';

SELECT '\COPY (select * from pg_catalog.pg_settings union select ''0_Project'' as name, '|| :vt_project_3_mark ||' as setting, null as unit, null as category, null as short_desc, null as extra_desc, null as context, null as vartype, null as source, null as min_val, null as max_val, null as enumvals, null as boot_val, null as reset_val, null as sourcefile, null as sourceline, null as pending_restart order by name) TO '|| :vt_out_csv_file_pg_setting ||' CSV HEADER;';

\pset tuples_only off
\o
\pset format csv
\i :vt_copy_settings_to_csv_file
\o

\qecho 'File Created:':vt_out_csv_file_pg_setting


-- COPY ( select * from pg_stat_activity ) TO '/tmp/pg_stat_activity.csv' (format csv, delimiter ';', ENCODING 'UTF8',header TRUE, FORCE_QUOTE *);



