\qecho '<P><A class=awr name=101></A>'
\qecho '<H2 class=awr>VACUUM, ANALYZE, ЗАМОРОЗКА</H2>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Скрипт Vacuum_Analyze.sql'
\qecho '</UL>'

\qecho '<UL>'
\qecho '<LI class=awr><A class=awr href="#1011">Настройки инстанса по VACUUM и ANALYZE</A>'
\qecho '<LI class=awr><A class=awr href="#612">Активные процессы VACUUM на момент запуска отчета</A>'
\qecho '<LI class=awr><A class=awr href="#613">VACUUM по таблицам в порядке убывания размера</A>'
\qecho '<LI class=awr><A class=awr href="#614">Таблицы, кандидаты на изменение порога запуска сбора статистики autovacuum_analyze_scale_factor</A>'
\qecho '</LI></UL>'

\qecho '<p></p>'

\qecho '<P><A class=awr name=1011></A>'
\qecho '<H3 class=awr>Настройки инстанса по VACUUM и ANALYZE</H3>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только те настройки, которые проверялись'
\qecho '<LI class=awr>check = 0 Обязательно изменить!'
\qecho '<LI class=awr>check = 1 Соответствует рекомендациям.!'
\qecho '<LI class=awr>check = 2 Следует обратить внимание.'
\qecho '</UL>'
\qecho '<p></p>'

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Автовакуум включен'
           ELSE '- Автовакуум отключен '
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Требуется включить автовакуум'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum'

union
select name                                                          "parameter",
       setting                                                       "setting",
       CASE WHEN to_number(setting, '99G999') >= 3 THEN 1 ELSE 0 END "check",
       CASE
           WHEN to_number(setting, '99G999') >= 3 THEN '+ '
           ELSE ''
           END                                                       "Comment",
       CASE
           WHEN to_number(setting, '99G999') = 3
               THEN
               ''
           ELSE
               'Задаёт максимальное число процессов автоочистки , которые могут выполняться одновременно. По умолчанию 3 Приблизительная формула Количество активных БД на иснстансе, но не более 15% CPU'
           END                                                       "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_max_workers'

union

select name                                                                                                             "parameter",
       setting || ' ' || COALESCE(unit, '') || '=' || pg_size_pretty(CASE
                                                                         WHEN unit = 'kB'
                                                                             THEN to_number(setting, '999G999G999') * 1024
                                                                         ELSE to_number(setting, '999G999G999') END) as "setting"
       --CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999') END "size_bt",
        ,
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
                    ELSE to_number(setting, '999G999G999') END <= 64 * 1024 * 1024 THEN 0
           ELSE 2 END                                                                                                   "check",
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
                    ELSE to_number(setting, '999G999G999') END <= 64 * 1024 * 1024
               THEN '- Задано меньше\равно по умолчанию 64 Мб'
           ELSE ''
           END                                                                                                          "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Задаёт максимальный объём памяти для операций обслуживания БД, в частности VACUUM, CREATE INDEX и ALTER TABLE ADD FOREIGN KEY. По умолчанию 64 Мб'
           END                                                                                                          "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'maintenance_work_mem'

union

select name                                                                                                   "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = 'kB'
                                                               THEN to_number(setting, '999G999G999') * 1024
                                                           ELSE to_number(setting, '999G999G999G999') END) as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
                    ELSE to_number(setting, '999G999G999G999') END > 1024 * 1024 * 1024 THEN 0
           ELSE 2 END                                                                                         "check",
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
                    ELSE to_number(setting, '999G999G999G999') END > 1024 * 1024 * 1024
               THEN '- Не может быть более 1 Гб'
           ELSE ''
           END                                                                                                "Comment",
       'Задаёт максимальный объём памяти, который будет использовать каждый рабочий процесс автоочистки.Для сбора идентификаторов мёртвых кортежей автоочистка может использовать максимум 1GB памяти'
                                                                                                              "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_work_mem'

union

select name                                     "parameter",
       setting || ' ' || unit                   "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
        ,
       CASE setting WHEN '-1' THEN 0 ELSE 2 END "check",
       CASE setting
           WHEN '-1' THEN 'Отключен вывод в журнал информации об автоочистке'
           ELSE 'Включен вывод в журнал информации об автоочистке'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Задаёт время выполнения действия автоочистки, при превышении которого информация об этом действии записывается в журнал. При нулевом значении в журнале фиксируются все действия автоочистки. Значение -1 отключает журналирование действий автоочистки.По умолчанию 10min'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'log_autovacuum_min_duration'

union

select name                                       "parameter",
       setting                                    "setting",
       CASE setting WHEN 'true' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'true' THEN 'Включена процедура отсечения пустых страниц в конце таблицы в процессе очистки'
           ELSE ' Отключена процедура отсечения пустых страниц в конце таблицы в процессе очистки'
           END                                    "Comment",
       CASE setting
           WHEN '000'
               THEN
               ''
           ELSE
               'Включает или отключает процедуру отсечения пустых страниц в конце таблицы в процессе очистки. Значение по умолчанию — true (вкл.)'
           END                                    "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'vacuum_truncate'

union

select name                                                                                                   "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = '8kB'
                                                               THEN to_number(setting, '999G999G999') * 8 * 1024
                                                           ELSE to_number(setting, '999G999G999G999') END) as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = '8kB' THEN to_number(setting, '999G999G999') * 8 * 1024
                    ELSE to_number(setting, '999G999G999G999') END < 512 * 1024 THEN 0
           ELSE 2 END                                                                                         "check",
       CASE
           WHEN CASE
                    WHEN unit = '8kB' THEN to_number(setting, '999G999G999') * 8 * 1024
                    ELSE to_number(setting, '999G999G999G999') END < 512 * 1024
               THEN '- Задан менее 512 Кб по умолчанию'
           ELSE ''
           END                                                                                                "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Задаёт минимальный объём данных индекса, подлежащий сканированию, при котором может применяться параллельное сканирование. При параллельном сканировании по индексу обычно не затрагивается весь индекс; здесь учитывается число страниц, которое по мнению планировщика будет затронуто при сканировании. Этот параметр также учитывается, когда нужно определить, может ли некоторый индекс обрабатываться при параллельной очистке. Если это значение задаётся без единиц измерения, оно считается заданным в блоках По умолчанию 512kB'
           END                                                                                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'min_parallel_index_scan_size'

union

select name                      "parameter",
       setting || ' ' || unit as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END < 60 THEN 0
           ELSE 2 END            "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END < 60
               THEN '- Задан менее 60 сек по умолчанию'
           ELSE ''
           END                   "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Задаёт минимальную задержку между двумя запусками автоочистки для отдельной базы данных. Демон автоочистки проверяет базу данных через заданный интервал времени и выдаёт команды VACUUM и ANALYZE, когда это требуется для таблиц этой базы. Если это значение задаётся без единиц измерения, оно считается заданным в секундах. По умолчанию задержка равна одной минуте (1min)'
           END                   "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_naptime'

union

select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END < 50 THEN 0
           ELSE 2 END                          "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END < 50
               THEN '- Задан менее 50 кортежей по умолчанию'
           ELSE ''
           END                                 "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Задаёт минимальное число изменённых или удалённых кортежей, при котором будет выполняться VACUUM для отдельно взятой таблицы. Значение по умолчанию — 50 кортежей'
           END                                 "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_vacuum_threshold'

union

select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = -1 THEN 0
           ELSE 2 END                          "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = -1
               THEN ''
           ELSE ''
           END                                 "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Задаёт число добавленных кортежей, при достижении которого будет выполняться VACUUM для отдельно взятой таблицы. Значение по умолчанию — 1000 кортежей. При значении -1 процедура автоочистки не будет производить операции VACUUM с таблицами в зависимости от числа добавленных строк'
           END                                 "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_vacuum_insert_threshold'

union

select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
        ,
       CASE
           WHEN to_number(setting, '999G999G999') = 0.01 THEN 1
           ELSE 2
           END                                 "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = -1
               THEN '- Отключен запуск VACUUM по таблицами в зависимости от числа добавленных строк'
           ELSE ''
           END                                 "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Процент от размера таблицы, который будет добавляться к autovacuum_vacuum_threshold при выборе порога срабатывания команды VACUUM. Значение по умолчанию — 0.2 (20% от размера таблицы). Рекомендуемое значение 0.01'
           END                                 "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_vacuum_scale_factor'

union

select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
       --,to_number(setting, 'G999D999S')::float "size"
        ,
       CASE
           WHEN to_number(setting, 'G999D999S')::float = 0.02 THEN 1
           ELSE 2 END                          "check",
       CASE
           WHEN to_number(setting, 'G999D999S')::float = 0.1
               THEN 'Задан по умолчанию 0.1 Для больших таблиц рекомендуется уменьшить'
           WHEN to_number(setting, 'G999D999S')::float = 0.02
               THEN 'Задано рекомендуемое значение 0.02 '
           ELSE 'Задайте рекомендуемое значение'
           END                                 "Comment",

       'Процент от размера таблицы, который будет добавляться к autovacuum_analyze_threshold при выборе порога срабатывания команды ANALYZE. Значение по умолчанию — 0.1 (10% от размера таблицы). Рекомендуемое значение 0.02'
                                               "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_analyze_scale_factor'

union

select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END <= 200 THEN 0
           ELSE 2 END                          "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END <= 200
               THEN ' Значение по умолчанию 200'
           ELSE ''
           END                                 "Comment",
       'Задаёт предел стоимости, который будет учитываться при автоматических операциях VACUUM. Значение по умолчанию — 200. Приблизительная формула 200*autovacuum_max_workers'
                                               "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_vacuum_cost_limit'
union

select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END <= 200 THEN 0
           ELSE 2 END                          "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END <= 200
               THEN ' Значение по умолчанию 200'
           ELSE ''
           END                                 "Comment",
       'Общая стоимость, при накоплении которой процесс очистки будет засыпать. По умолчанию этот параметр равен 200.'
                                               "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'vacuum_cost_limit'
union


select name                                    "parameter",
       setting || ' ' || COALESCE(unit, '') as "setting"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = 200000000 THEN 1
           ELSE 2 END                          "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = 200000000
               THEN ' Задано 200 000 000  по умолчанию'
           ELSE ''
           END                                 "Comment",
       'Задаёт максимальный возраст (в транзакциях) для поля pg_class.relfrozenxid некоторой таблицы, при достижении которого будет запущена операция VACUUM для предотвращения зацикливания идентификаторов транзакций в этой таблице. Заметьте, что система запустит процессы автоочистки для предотвращения зацикливания, даже если для всех других целей автоочистка отключена.по умолчанию 200 миллионов транзакций'
                                               "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovcm_freeze_max_age'

union

select name                      "parameter",
       setting || ' ' || unit as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = 2 THEN 1
           ELSE 2 END            "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = 2
               THEN ' Задано значение по умолчанию 2 '
           ELSE ''
           END                   "Comment",
       'Задаёт задержку при превышении предела стоимости, которая будет применяться при автоматических операциях VACUUM. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. При значении -1 применяется обычная задержка vacuum_cost_delay. Значение по умолчанию — 2 миллисекунды'
                                 "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'autovacuum_vacuum_cost_delay'

union

select name           "parameter",
       setting as     "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = 2 THEN 1
           ELSE 2 END "check",
       CASE
           WHEN CASE
                    WHEN unit = 's' THEN to_number(setting, '999G999G999')
                    ELSE to_number(setting, '999G999G999G999') END = 2
               THEN ' Задано значение по умолчанию 2 '
           ELSE ''
           END        "Comment",
       'Примерная стоимость очистки буфера, который нужно прочитать с диска. Это подразумевает блокировку пула буферов, поиск в хеш-таблице, чтение требуемого блока с диска и сканирование его содержимого. По умолчанию этот параметр равен 2.'
                      "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'vacuum_cost_page_miss'

union
select name                                                                          "parameter",
       setting                                                                       "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 150000000 THEN 1 ELSE 0 END "check",
       CASE
           WHEN to_number(setting, '999G999G999G999') = 150000000
               THEN 'Задано значение по умолчанию  150 миллионов транзакций'
           ELSE 'Задано значение НЕ по умолчанию  150 миллионов транзакций'
           END                                                                       "Comment",
       'Задаёт максимальный возраст для поля pg_class.relfrozenxid таблицы, при достижении которого VACUUM будет производить агрессивное сканирование. Значение по умолчанию — 150 миллионов транзакций'
                                                                                     "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'vacuum_freeze_table_age'

order by "check", "parameter";

\qecho </details>

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Горизонт заморозки обычных трансакций и мультитрансакций по БД в порядке убывания horizon(tx_age)</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>datfrozenxid -  идентификатор транзакции, создавшей самую позднюю из незамороженных версий строк в БД'
\qecho '<LI class=awr>datminmxid -  идентификаторы мультитранзакций, предшествующие данному, в этой базе данных заменены другим идентификатором транзакции'
\qecho '</UL>'
\qecho '<p></p>'

SELECT LOCALTIMESTAMP(0)
     , datname
     , to_char(to_number(datfrozenxid::text, '999999999999'), '999 999 999 999') as "datfrozenxid"
     , to_char(txid_current(), '999 999 999 999')                                as "    txid_current"
     , to_char(to_number(age(datfrozenxid)::text, '999999999999'),
               '999 999 999 999')                                                AS "          tx_age"
     , to_char(to_number(current_setting('autovacuum_freeze_max_age')::text, '999999999999'),
               '999 999 999 999')                                                as "avcm_freeze_max_age"
     , to_char(to_number(current_setting('autovacuum_freeze_max_age'), '999999999999') - age(datfrozenxid),
               '999 999 999 999')                                                as "tx_before_avto_freeze"
     , to_char(to_number(mxid_age(datminmxid)::text, '999999999999'),
               '999 999 999 999')                                                AS "    mxid_age"
     , to_char(to_number(current_setting('autovacuum_multixact_freeze_max_age')::text, '999999999999'),
               '999 999 999 999')                                                as "autovacuum_multixact_freeze_max_age"
     , to_char(to_number(current_setting('autovacuum_multixact_freeze_max_age'), '999999999999') - mxid_age(datminmxid),
               '999 999 999 999')                                                as "mx_before_avto_freeze"

FROM pg_database
ORDER BY age(datfrozenxid) DESC;

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Текущее состояние контрольных точек</H3>'
--\qecho '<UL>'
--\qecho '<LI class=awr>datfrozenxid -  идентификатор транзакции, создавшей самую позднюю из незамороженных версий строк в БД'
--\qecho '<LI class=awr>datminmxid -  идентификаторы мультитранзакций, предшествующие данному, в этой базе данных заменены другим идентификатором транзакции'
--\qecho '</UL>'
\qecho '<p></p>'

select *
       --next_xid, next_multixact_id, oldest_xid, oldest_xid_dbid, oldest_multi_xid, oldest_multi_dbid
from pg_control_checkpoint();

-- select * from pg_get_multixact_members('119953531');

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Горизонт заморозки трансакций и мультитрансакций первые 15 таблиц, секций, матпредставлений в порядке убывания tx_age</H4>'
\qecho '<UL>'
\qecho '<LI class=awr>relfrozenxid -  идентификатор транзакции, создавшей самую позднюю из незамороженных версий строк таблицы'
\qecho '<LI class=awr>Команды на проведение VACUUM(FREEZE, VERBOSE, ANALYZE) индивидуально по таблицам, количество мертвых строк у которых более заданного см отчет с расширение sql'
\qecho '<LI class=awr>Рекомендуется проводить упреждающую замомозку по отношениям, которые близки к порогу Подробно см:'
\qecho <a class=awr_href href="https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1785393616">Команды, функция и автоматизация проведения заморозки по отношениям</a>
\qecho '</UL>'
\qecho '<p></p>'

SELECT LOCALTIMESTAMP(0)
     -- c.relowner, relnamespace,
     , pg_namespace.nspname
     , relname
     , to_char(to_number(relfrozenxid::text, '999999999999'), '999 999 999 999') as "    relfrozenxid"
     , to_char(txid_current(), '999 999 999 999')                                as "    txid_current"
     , to_char(to_number(age(relfrozenxid)::text, '999999999999'),
               '999 999 999 999')                                                AS "          tx_age"
     , to_char(to_number(current_setting('autovacuum_freeze_max_age')::text, '999999999999'),
               '999 999 999 999')                                                as "avcm_freeze_max_age"
     , to_char(to_number(current_setting('autovacuum_freeze_max_age'), '999999999999') - age(relfrozenxid),
               '999 999 999 999')                                                as "tx_before_avto_freeze"
     , to_char(to_number(c.relminmxid::text, '999999999999'),
               '999 999 999 999')                                                as "    relminmxid"
     , to_char(to_number(mxid_age(c.relminmxid)::text, '999999999999'),
               '999 999 999 999')                                                AS "    mxid_age"
     , to_char(to_number(current_setting('autovacuum_multixact_freeze_max_age')::text, '999999999999'),
               '999 999 999 999')                                                as av_mxid_freeze
     , to_char(to_number(current_setting('autovacuum_multixact_freeze_max_age'), '999999999999') - mxid_age(relminmxid),
               '999 999 999 999')                                                as "mx_before_avto_freeze"
     , pg_stat_get_autovacuum_count(c.oid) +
       pg_stat_get_vacuum_count(c.oid)                                           AS all_vcm_cnt
     , to_char(now() - coalesce(
        pg_stat_get_last_autovacuum_time(c.oid),
        pg_stat_get_last_vacuum_time(c.oid)
    ),
               'DD HH24:MI:SS:MS')                                               AS since_last_vacuum
     , pg_size_pretty(pg_total_relation_size(c.oid))                             as rel_size
FROM pg_class c
         JOIN pg_namespace
              ON c.relnamespace = pg_namespace.oid
WHERE c.relkind in ('r', 't', 'm')
--  AND c.relname ~'pgbench'
ORDER BY age(relfrozenxid) DESC
limit 15;


\qecho '<p></p>'
-- \qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Горизонт заморозки первые 15 таблиц c all_vcm_cnt >0 в порядке убывания horizon</H4>'
\qecho '<UL>'
\qecho '<LI class=awr>relfrozenxid -  идентификатор транзакции, создавшей самую позднюю из незамороженных версий строк  таблицы'
\qecho '</UL>'
\qecho '<p></p>'

SELECT LOCALTIMESTAMP(0)
     -- c.relowner, relnamespace,
     , pg_namespace.nspname
     , relname
     , to_char(to_number(relfrozenxid::text, '999999999999'), '999 999 999 999') as "    relfrozenxid"
     , to_char(txid_current(), '999 999 999 999')                                as "     txid_current"
     , to_char(to_number(age(relfrozenxid)::text, '999999999999'),
               '999 999 999 999')                                                AS "       tx_age"
     , to_char(to_number(current_setting('autovacuum_freeze_max_age')::text, '999999999999'),
               '999 999 999 999')                                                as "avcm_freeze_max_age"
     , to_char(to_number(current_setting('autovacuum_freeze_max_age'), '999999999999') - age(relfrozenxid),
               '999 999 999 999')                                                as "tx_before_avto_freeze"
     , to_char(to_number(c.relminmxid::text, '999999999999'),
               '999 999 999 999')                                                as "    relminmxid"
     , to_char(to_number(mxid_age(c.relminmxid)::text, '999999999999'),
               '999 999 999 999')                                                AS "   mxid_age"
     , to_char(to_number(current_setting('autovacuum_multixact_freeze_max_age')::text, '999999999999'),
               '999 999 999 999')                                                as av_mxid_freeze
     , to_char(to_number(current_setting('autovacuum_multixact_freeze_max_age'), '999999999999') - mxid_age(relminmxid),
               '999 999 999 999')                                                as "mx_before_avto_freeze"
     , pg_stat_get_autovacuum_count(c.oid) +
       pg_stat_get_vacuum_count(c.oid)                                           AS all_vacuum_count
     , to_char(now() - coalesce(
        pg_stat_get_last_autovacuum_time(c.oid),
        pg_stat_get_last_vacuum_time(c.oid)
    ),
               'DD HH24:MI:SS:MS')                                               AS since_last_vacuum
     , pg_size_pretty(pg_total_relation_size(c.oid))                             as rel_size
FROM pg_class c
         JOIN pg_namespace
              ON c.relnamespace = pg_namespace.oid
WHERE c.relkind in ('r', 't', 'm')
  AND pg_stat_get_autovacuum_count(c.oid) + pg_stat_get_vacuum_count(c.oid) > 0
--  AND c.relname ~'pgbench'
ORDER BY age(relfrozenxid) DESC
limit 15;

-- Количество процессов ограничено сверху значением параметра max_parallel_maintenance_workers
;
\qecho '<p></p>'
\qecho 'Активные процессы VACUUM на момент запуска отчета'
\qecho '<p></p>'
-- select * from  pg_stat_progress_vacuum;

-- List active vacuums and their progress
SELECT LOCALTIMESTAMP(0)
     , p.pid
     , date_trunc('second', now() - a.xact_start)                                         AS dur
     , to_char(localtimestamp - a.xact_start, 'DD HH24:MI:SS:MS')                         AS "xact_dur"
     , coalesce(wait_event_type || '.' || wait_event, 'f')                                AS wait
     , CASE WHEN a.query ~ 'to prevent wraparound' THEN 'freeze' ELSE 'regular' END       AS mode
     , (SELECT datname FROM pg_database WHERE oid = p.datid)                              AS dat
     , p.relid::regclass                                                                  AS tab
     , p.phase
     , round((p.heap_blks_total * current_setting('block_size')::int) / 1024.0 / 1024)    AS tab_mb
     , round(pg_total_relation_size(relid) / 1024.0 / 1024)                               AS ttl_mb
     , round((p.heap_blks_scanned * current_setting('block_size')::int) / 1024.0 / 1024)  AS scan_mb
     , round((p.heap_blks_vacuumed * current_setting('block_size')::int) / 1024.0 / 1024) AS vac_mb
     , (100 * p.heap_blks_scanned / nullif(p.heap_blks_total, 0))                         AS scan_pct
     , (100 * p.heap_blks_vacuumed / nullif(p.heap_blks_total, 0))                        AS vac_pct
     , p.index_vacuum_count                                                               AS ind_vac_cnt
     , round(p.num_dead_tuples * 100.0 / nullif(p.max_dead_tuples, 0), 1)                 AS dead_pct
FROM pg_stat_progress_vacuum p
         JOIN pg_stat_activity a using (pid)
ORDER BY dur DESC;

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=210></A>'
\qecho '<H4 class=awr>Количество таблиц, которые как мимимум раз были обработаны autovacuum и autoanalyze  в указанные сутки</H4>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны за последние 15 суток'
\qecho '</UL>'
\qecho '<p></p>'

with avc_tbl as
         (select to_char(last_autovacuum, 'YYYY-MM-DD') as date
               , count(*)                               as tables_cnt_autovacuum
               , sum(vacuum_count)                      as "vacuum_cnt"
               , sum(autovacuum_count)                  as "autovacuum_cnt"
          from pg_stat_all_tables
          group by to_char(last_autovacuum, 'YYYY-MM-DD')
          order by 1 desc
          limit 15),

     autoanalyze_tbl as
         (select to_char(last_autoanalyze, 'YYYY-MM-DD') as date
               , count(*)                                as tables_cnt_autoanalyze
               , sum(autoanalyze_count)                  as "autoanalyze_cnt"
               , sum(analyze_count)                      as "analyze_cnt"
          from pg_stat_all_tables
          group by to_char(last_autoanalyze, 'YYYY-MM-DD')
          order by 1 desc
          limit 15),

     distinct_date as
         (select date
          from avc_tbl
          union
          distinct
          select date
          from autoanalyze_tbl
          order by 1 desc)

-- https://sky.pro/wiki/sql/izvlechenie-dnya-nedeli-iz-daty-v-postgre-sql-ponedelnik-0/
select dd.date
     --,MOD(EXTRACT(DOW FROM dd.date::date)::int + 6, 7) + 1 AS day_of_week
     , TO_CHAR(dd.date::date, 'Day') AS day_text
     , avc.tables_cnt_autovacuum
     , avc.autovacuum_cnt
     , avc.vacuum_cnt
     , anl.tables_cnt_autoanalyze
     , anl.autoanalyze_cnt
     , anl.analyze_cnt
from distinct_date dd
         left join avc_tbl avc on dd.date = avc.date
         left join autoanalyze_tbl anl on dd.date = anl.date;


\qecho '<p></p>'
\qecho '<P><A class=awr name=613></A>'
\qecho '<H4 class=awr>VACUUM  по таблицам в порядке убывания размера</H3>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 таблиц по размеру более 1 Gb'
\qecho '<LI class=awr>Команды на проведение VACUUM и ANALYZE индивидуально по таблицам, количество мертвых строк у которых более заданного см отчет с расширение sql'
\qecho '</UL>'
\qecho '<p></p>'


-- https://pgpedia.info/s/storage-parameters.html#:~:text=Storage%20parameters%20(also%20known%20as,or%20define%20custom%20autovacuum%20settings.

-- Show last vacuumed and last_analyze by table size descending.
\qecho '<p></p>'
select stats_reset::timestamp(0) AS "Cumulative statistics reset date"
from pg_stat_database
WHERE datname = current_database();
\qecho '<p></p>'

select a1.relname
     , a1.nspname
     , a1.main_size
     , a1.total_size
     , to_char(a1.last_vacuumed, 'YY-MM-DD HH24:MI:SS')                    AS "last_vcm"
     --,to_char(a1.last_analyzed,'YY-MM-DD HH24:MI:SS') AS "last_anl"
     , a1.cnt_vcm
     --, a1.cnt_anl
     , to_char((LOCALTIMESTAMP - a1.last_vacuumed), 'YY-MM-DD HH24:MI:SS') AS "d_last_vcm"
     --, to_char((LOCALTIMESTAMP - a1.last_analyzed),'YY-MM-DD HH24:MI:SS') AS "d_last_anl"
     --, unnest(reloptions)
     , n_dead_tup > round(current_setting('autovacuum_vacuum_threshold')::integer +
                          current_setting('autovacuum_vacuum_scale_factor')::float *
                          reltuples)                                       as "need_vcm"
     , trim(to_char(n_dead_tup, '999 999 999 999'))                        as "n_dead_tups"
     , trim(to_char(round(current_setting('autovacuum_vacuum_threshold')::integer +
                          current_setting('autovacuum_vacuum_scale_factor')::float * reltuples),
                    '999 999 999 999'))                                    AS "    LevelVcm"
     , trim(to_char(reltuples, '999 999 999 999'))                         as "         tuples_all"
     , trim(to_char(n_live_tup, '999 999 999 999'))                        as "    n_live_tups"
     , trim(to_char(n_tup_ins, '999 999 999 999'))                         as "    n_tups_ins"
     , trim(to_char(n_tup_upd, '999 999 999 999'))                         as "    n_tups_upd"
     , trim(to_char(a1.n_mod_since_analyze, '999 999 999 999'))            AS "n_mod_since_anl"
     -- , to_char(a1.n_ins_since_vacuum ,'999 999 999 999') AS "n_ins_since_vcm"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum=(\\d+).*'))[1]),
                current_setting('autovacuum'))::text                       AS "AutVcm"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum_vacuum_threshold=(\\d+).*'))[1]),
                current_setting('autovacuum_vacuum_threshold'))::real      AS "VcmTH"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum_vacuum_scale_factor=(\\d+).*'))[1]),
                current_setting('autovacuum_vacuum_scale_factor'))::real   AS "VcmSF"
     , trim(to_char(a1.size_bt, '999 999 999 999'))                        as "size_bts"

from (SELECT pg_class.relname
           , pg_namespace.nspname
           , pg_size_pretty(pg_total_relation_size(pg_class.oid))                         "total_size"
           , pg_size_pretty(pg_relation_size(pg_class.oid))                               "main_size"
           , CASE
                 WHEN COALESCE(last_vacuum, '1/1/1000') >
                      COALESCE(last_autovacuum, '1/1/1000') THEN
                     pg_stat_all_tables.last_vacuum
                 ELSE last_autovacuum
        END                                                                            AS last_vacuumed
           , CASE
                 WHEN COALESCE(last_analyze, '1/1/1000') >
                      COALESCE(last_autoanalyze, '1/1/1000') THEN
                     pg_stat_all_tables.last_analyze
                 ELSE last_autoanalyze
        END                                                                            AS last_analyzed
           , (pg_stat_all_tables.autovacuum_count + pg_stat_all_tables.vacuum_count)   AS "cnt_vcm"
           , (pg_stat_all_tables.autoanalyze_count + pg_stat_all_tables.analyze_count) AS "cnt_anl"
           , pg_stat_all_tables.n_mod_since_analyze
           , pg_relation_size(pg_class.oid)                                            AS "size_bt"
           , pg_class.reloptions
           , pg_class.reltuples
           , pg_stat_all_tables.n_live_tup
           , pg_stat_all_tables.n_dead_tup
           , pg_stat_all_tables.n_tup_ins
           , pg_stat_all_tables.n_tup_upd
      FROM pg_class
               JOIN pg_namespace
                    ON pg_class.relnamespace = pg_namespace.oid
               JOIN pg_stat_all_tables
                    ON (
                                pg_class.relname = pg_stat_all_tables.relname
                            AND pg_namespace.nspname = pg_stat_all_tables.schemaname
                        )
      WHERE pg_namespace.nspname NOT IN ('pg_toast', 'pg_catalog', 'information_schema')) a1
where size_bt > 1024 * 1024 * 1024
ORDER BY size_bt DESC
LIMIT 20;


\qecho '<p></p>'
\qecho '<P><A class=awr name=614></A>'
\qecho '<H4 class=awr>Таблицы, кандидаты на изменение порога запуска сбора статистики autovacuum_analyze_scale_factor</H4>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 таблиц, в которых изменено более 10 000 строк с момента последнего анализа'
-- \qecho '<LI class=awr>Команды на проведение VACUUM и ANALYZE индивидуально по таблицам, количество мертвых строк у которых более заданного см отчет с расширение sql'
\qecho '</UL>'
\qecho '<p></p>'


--select sd.stats_reset from pg_stat_database sd where sd.datname = current_database ();


-- SELECT oid FROM pg_database WHERE datname = current_database() AS vn_oid_curr_db;
-- \gset

select stats_reset::timestamp(0) AS "Cumulative statistics reset date"
from pg_stat_database
WHERE datname = current_database();

select a1.relname
     , a1.nspname
     , a1.main_size
     , a1.total_size
     , to_char(a1.last_analyzed, 'YY-MM-DD HH24:MI:SS')                                       AS "last_anl"
     , to_char((LOCALTIMESTAMP - a1.last_analyzed), 'YY-MM-DD HH24:MI:SS')                    AS "d_last_anl"
     , a1.cnt_anl
     --, sd.stats_reset::timestamp(0)   AS "stats_reset"
     , to_char(((LOCALTIMESTAMP - sd.stats_reset) / (a1.cnt_anl + 1)), 'YY-MM-DD HH24:MI:SS') as "AvgInterAnl"
     --, a1.size_bt
     --, reloptions
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum=(\\d+).*'))[1]),
                current_setting('autovacuum'))::text                                          AS "AutVac"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum_analyze_threshold=(\\d+).*'))[1]),
                current_setting('autovacuum_analyze_threshold'))::real                        AS "AnlzThreshold"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum_analyze_scale_factor=(\\d+).*'))[1]),
                current_setting('autovacuum_analyze_scale_factor'))::real                     AS "scale_factor"

     , reltuples                                                                              AS "Строк"
     , a1.n_mod_since_analyze                                                                 AS "n_mod_since_anl"
     , round(current_setting('autovacuum_analyze_threshold')::integer +
             current_setting('autovacuum_analyze_scale_factor')::float * reltuples)           AS "ПорогAnl"
     , a1.n_dead_tup --AS "Ненужных"
     , a1.n_tup_ins  --AS "Вставленных"
from (SELECT pg_class.relname
           , pg_namespace.nspname
           , pg_size_pretty(pg_total_relation_size(pg_class.oid))                         "total_size"
           , pg_size_pretty(pg_relation_size(pg_class.oid))                               "main_size"
           , CASE
                 WHEN COALESCE(last_vacuum, '1/1/1000') >
                      COALESCE(last_autovacuum, '1/1/1000') THEN
                     pg_stat_all_tables.last_vacuum
                 ELSE last_autovacuum
        END                                                                            AS last_vacuumed
           , CASE
                 WHEN COALESCE(last_analyze, '1/1/1000') >
                      COALESCE(last_autoanalyze, '1/1/1000') THEN
                     pg_stat_all_tables.last_analyze
                 ELSE last_autoanalyze
        END                                                                            AS last_analyzed
           , (pg_stat_all_tables.autovacuum_count + pg_stat_all_tables.vacuum_count)   AS "cnt_vcm"
           , (pg_stat_all_tables.autoanalyze_count + pg_stat_all_tables.analyze_count) AS "cnt_anl"
           , pg_stat_all_tables.n_mod_since_analyze
           , pg_relation_size(pg_class.oid)                                            AS "size_bt"
           , pg_class.reloptions
           , pg_class.reltuples
           , pg_stat_all_tables.n_dead_tup
           , pg_stat_all_tables.n_tup_ins
      FROM pg_class
               JOIN pg_namespace
                    ON pg_class.relnamespace = pg_namespace.oid
               JOIN pg_stat_all_tables
                    ON (
                                pg_class.relname = pg_stat_all_tables.relname
                            AND pg_namespace.nspname = pg_stat_all_tables.schemaname
                        )
      WHERE pg_namespace.nspname NOT IN ('pg_toast', 'pg_catalog', 'information_schema')) a1
         CROSS JOIN pg_stat_database sd
where a1.n_mod_since_analyze + a1.n_dead_tup + a1.n_tup_ins > 10000
  and sd.datname = current_database()
ORDER BY a1.n_mod_since_analyze + a1.n_dead_tup + a1.n_tup_ins DESC
limit 20;

\qecho '<p></p>'
\qecho '<P><A class=awr name=614></A>'
\qecho '<H4 class=awr>Таблицы,  в которые выполняются только вставки и не выполняются удаления и обновления.Кандидаты на SET autovacuum_freeze_min_age = 0;</H4>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 таблиц по количеству вставок'
\qecho '<LI class=awr>Команды на установку порога замороки SET autovacuum_freeze_min_age = 0 индивидуально по таблицам см отчет с расширение sql'
\qecho '</UL>'
\qecho '<p></p>'

select a1.relname
     , a1.nspname
     , trim(to_char(n_tup_ins, '999 999 999 999'))                         as "    n_tups_ins"
     , trim(to_char(n_dead_tup, '999 999 999 999'))                        as "n_dead_tups"
     , trim(to_char(n_tup_upd, '999 999 999 999'))                         as "    n_tups_upd"
     , trim(to_char(a1.n_mod_since_analyze, '999 999 999 999'))            AS "n_mod_since_anl"

     , a1.main_size
     , a1.total_size
     , to_char(a1.last_vacuumed, 'YY-MM-DD HH24:MI:SS')                    AS "last_vcm"
     --,to_char(a1.last_analyzed,'YY-MM-DD HH24:MI:SS') AS "last_anl"
     , a1.cnt_vcm
     --, a1.cnt_anl
     , to_char((LOCALTIMESTAMP - a1.last_vacuumed), 'YY-MM-DD HH24:MI:SS') AS "d_last_vcm"
     --, to_char((LOCALTIMESTAMP - a1.last_analyzed),'YY-MM-DD HH24:MI:SS') AS "d_last_anl"
     --, unnest(reloptions)
     , n_dead_tup > round(current_setting('autovacuum_vacuum_threshold')::integer +
                          current_setting('autovacuum_vacuum_scale_factor')::float *
                          reltuples)                                       as "need_vcm"
     , trim(to_char(round(current_setting('autovacuum_vacuum_threshold')::integer +
                          current_setting('autovacuum_vacuum_scale_factor')::float * reltuples),
                    '999 999 999 999'))                                    AS "    LevelVcm"
     , trim(to_char(reltuples, '999 999 999 999'))                         as "tuples_all"
     , trim(to_char(n_live_tup, '999 999 999 999'))                        as "   n_live_tups"
     -- , to_char(a1.n_ins_since_vacuum ,'999 999 999 999') AS "n_ins_since_vcm"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum=(\\d+).*'))[1]),
                current_setting('autovacuum'))::text                       AS "AutVcm"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum_vacuum_threshold=(\\d+).*'))[1]),
                current_setting('autovacuum_vacuum_threshold'))::real      AS "VcmTH"
     , coalesce((SELECT (regexp_matches(reloptions::text, E'.*autovacuum_vacuum_scale_factor=(\\d+).*'))[1]),
                current_setting('autovacuum_vacuum_scale_factor'))::real   AS "VcmSF"
     , trim(to_char(a1.size_bt, '999 999 999 999'))                        as "size_bts"

from (SELECT pg_class.relname
           , pg_namespace.nspname
           , pg_size_pretty(pg_total_relation_size(pg_class.oid))                         "total_size"
           , pg_size_pretty(pg_relation_size(pg_class.oid))                               "main_size"
           , CASE
                 WHEN COALESCE(last_vacuum, '1/1/1000') >
                      COALESCE(last_autovacuum, '1/1/1000') THEN
                     pg_stat_all_tables.last_vacuum
                 ELSE last_autovacuum
        END                                                                            AS last_vacuumed
           , CASE
                 WHEN COALESCE(last_analyze, '1/1/1000') >
                      COALESCE(last_autoanalyze, '1/1/1000') THEN
                     pg_stat_all_tables.last_analyze
                 ELSE last_autoanalyze
        END                                                                            AS last_analyzed
           , (pg_stat_all_tables.autovacuum_count + pg_stat_all_tables.vacuum_count)   AS "cnt_vcm"
           , (pg_stat_all_tables.autoanalyze_count + pg_stat_all_tables.analyze_count) AS "cnt_anl"
           , pg_stat_all_tables.n_mod_since_analyze
           , pg_relation_size(pg_class.oid)                                            AS "size_bt"
           , pg_class.reloptions
           , pg_class.reltuples
           , pg_stat_all_tables.n_live_tup
           , pg_stat_all_tables.n_dead_tup
           , pg_stat_all_tables.n_tup_ins
           , pg_stat_all_tables.n_tup_upd
      FROM pg_class
               JOIN pg_namespace
                    ON pg_class.relnamespace = pg_namespace.oid
               JOIN pg_stat_all_tables
                    ON (
                                pg_class.relname = pg_stat_all_tables.relname
                            AND pg_namespace.nspname = pg_stat_all_tables.schemaname
                        )
         --   WHERE pg_namespace.nspname NOT IN ('pg_toast','pg_catalog','information_schema')
     ) a1
where n_dead_tup = 0
  and n_tup_ins > 0
  and n_tup_upd = 0
  and n_mod_since_analyze = 0
  --size_bt > 1024*1024*1024
ORDER BY n_tup_ins DESC
LIMIT 20;

\qecho '<p></p>'
\qecho '<P><A class=awr name=614></A>'
\qecho '<H4 class=awr>Таблицы без autovacuum и vacuum;</H4>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 таблиц по количеству строк'
\qecho '</UL>'
\qecho '<p></p>'

select count(*) as "Количество таблиц без autovacuum и vacuum"
from pg_stat_all_tables
where autovacuum_count = 0
  and vacuum_count = 0;

select schemaname,
       relname,
       n_live_tup,
       last_vacuum,
       last_autovacuum,
       autovacuum_count,
       autoanalyze_count,
       last_analyze,
       last_autoanalyze,
       n_mod_since_analyze,
       n_ins_since_vacuum
from pg_stat_all_tables
where autovacuum_count = 0
  and vacuum_count = 0
order by n_live_tup desc
LIMIT 20;

\qecho '<p></p>'
\qecho '<P><A class=awr name=614></A>'
\qecho '<H4 class=awr>Таблицы без autoanalyze и analyze</H4>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 таблиц по количеству строк'
\qecho '</UL>'
\qecho '<p></p>'

select count(*) "Количество таблиц без autoanalyze и analyze"
from pg_stat_all_tables
where autoanalyze_count = 0
  and analyze_count = 0;

select schemaname,
       relname,
       n_live_tup,
       last_vacuum,
       last_autovacuum,
       autovacuum_count,
       autoanalyze_count,
       last_analyze,
       last_autoanalyze,
       n_mod_since_analyze,
       n_ins_since_vacuum
from pg_stat_all_tables
where autoanalyze_count = 0
  and analyze_count = 0
order by n_live_tup desc
LIMIT 15;

\qecho '<p></p>'
\qecho '<P><A class=awr name=614></A>'
\qecho '<H4 class=awr>Количество таблиц со специфическими параметрами, заданными на уровне таблиц</H4>'
\qecho '<p></p>'

select reloptions, count(*)
from pg_class
where reloptions is not null
group by reloptions
order by 2 desc;

\qecho '<p></p>'
\qecho '<P><A class=awr name=614></A>'
\qecho '<H4 class=awr>Таблицы со специфическими параметрами, заданными на уровне таблиц</H4>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 таблиц по количеству строк по каждому виду reloptions'
\qecho '</UL>'
\qecho '<p></p>'

select relname, reloptions, reltuples
from pg_class
where reloptions in
      (select reloptions
       from (select reloptions, count(*)
             from pg_class
             where reloptions <> '{autovacuum_enabled=true}'
               and reloptions is not null
             group by reloptions
             order by 2 desc
             limit 1) a1)
order by reltuples desc
limit 20;

with a1 as
         (select reloptions,
                 ROW_NUMBER() OVER (
                     ORDER BY cnt desc ) as row_num
          from (select reloptions, count(*) cnt
                from pg_class
                where reloptions <> '{autovacuum_enabled=true}'
                  and reloptions is not null
                group by reloptions
                order by 2 desc
                limit 10) s1)

select relname, reloptions, reltuples
from pg_class
where reloptions in (select reloptions
                     from a1
                     where row_num = 2)
order by reltuples desc
limit 20;

with a1 as
         (select reloptions,
                 ROW_NUMBER() OVER (
                     ORDER BY cnt desc ) as row_num
          from (select reloptions, count(*) cnt
                from pg_class
                where reloptions <> '{autovacuum_enabled=true}'
                  and reloptions is not null
                group by reloptions
                order by 2 desc
                limit 10) s1)

select relname, reloptions, reltuples
from pg_class
where reloptions in (select reloptions
                     from a1
                     where row_num = 3)
order by reltuples desc
limit 20;

with a1 as
         (select reloptions,
                 ROW_NUMBER() OVER (
                     ORDER BY cnt desc ) as row_num
          from (select reloptions, count(*) cnt
                from pg_class
                where reloptions <> '{autovacuum_enabled=true}'
                  and reloptions is not null
                group by reloptions
                order by 2 desc
                limit 10) s1)

select relname, reloptions, reltuples
from pg_class
where reloptions in (select reloptions
                     from a1
                     where row_num = 4)
order by reltuples desc
limit 20;

with a1 as
         (select reloptions,
                 ROW_NUMBER() OVER (
                     ORDER BY cnt desc ) as row_num
          from (select reloptions, count(*) cnt
                from pg_class
                where reloptions <> '{autovacuum_enabled=true}'
                  and reloptions is not null
                group by reloptions
                order by 2 desc
                limit 10) s1)

select relname, reloptions, reltuples
from pg_class
where reloptions in (select reloptions
                     from a1
                     where row_num = 5)
order by reltuples desc
limit 20;


\qecho <P><A class=awr href="#101">Back to VACUUM, ANALYZE, ЗАМОРОЗКА</A> <BR><A class=awr href="#top">Back to Top</A>




