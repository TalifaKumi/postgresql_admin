
DROP FUNCTION public.ver_create_conn_db2postgres;
DROP FUNCTION public.ver_if_conn_name_exists;
DROP FUNCTION public.ver_if_table_exists;
DROP FUNCTION public.ver_if_func_exists;













