-- Пример запуска

-- Перейти в директорию со скриптами
-- \cd d:/PostgreSQL/SQL/Verif_recom_PG
-- Запустить головной  файл
-- \i Report_Separate_Section_PG.sql

-- Для получения отчета по отдельному разделу\разделам
-- Нужно оставить вызовы скриптов обязательных разделов и требуемых
-- Остальные вызовы скриптов - закомментировать

-- Ctrl   Slash  : for single line comments (   --...  )
--  Ctrl   Shift   Slash  : for block comments (  /*...*/  )

-- Задать имя проекта и настройки отчета - Обязательно
\i SET_SETTINGS_REPORT.sql

-- Обязательно
\i VERS_HOST_INST_DBS.sql

\i EXTENTIONS.sql

-- Основные настройки инстанса.
-- \i Basic_Setting.sql

-- Настройки догирования в журнал
-- \i LOG_SETTINGS.sql

-- Информация по соединениям.
-- \i CONNECTIONS.sql

-- \i SHARED_MEMORY.sql

-- Временные файлы(Temporary files)
-- \i TMP_Files.sql

--
-- \i TRANSACTIONS.sql
-- \i LOCKS.sql

-- \i Queries_TOP_10.sql
-- \i Plans.sql

-- Эти пункты только для БД postgres
\if :current_db_postgres

\if :set_pg_store_plans

\i Plans.sql
\else
\qecho '<P><A class=awr name=171></A>'
\qecho '<H2 class=awr>Расширение pg_store_plans не установлено</H2>'
\qecho '<p></p>'
\endif

\if :set_pg_wait_sampling

\i WAITING_EVENTS.sql
\else
\qecho '<P><A class=awr name=181></A>'
\qecho '<H2 class=awr>Расширение pg_wait_sampling не установлено</H2>'
\qecho '<p></p>'
\endif

\if :set_system_stats

\i SYSTEM_STATS_GENERAL.sql
\i SYSTEM_STATS.sql
\else
\qecho '<P><A class=awr name=191></A>'
\qecho '<H2 class=awr>Расширение set_system_stats не установлено</H2>'
\qecho '<p></p>'
\endif

\endif
-- Окончание по :current_db_postgres

-- \i WAL.sql

-- VACUUM и ANALYZE
-- \i Vacuum_Analyze.sql

-- \i Planner_Optimizer.sql

-- \i FILLFACTOR.sql

--\i BLOAT.sql
-- Определение свободного места в таблице с исполльзованием pgstattuple_approx
--\i BLOAT_TABLE_pgstattuple_approx.sql
-- Определение свободного места в таблице с исполльзованием pgstattuple_approx
--\i BLOAT_TABLE_pgstattuple.sql

-- Таблицы
\i TABLES.sql
--\i Indx_with_NULL.sql

-- \i UnUsed_Indx.sql

-- \i Candidate_Partial_Indx.sql

-- \i duplicate_indexes_fuzzy.sql

\qecho '<P>'
\qecho '<P>End of Report </P></BODY></HTML>'

-- Подготовка скриптов по рекомендациям
-- \i Prepare_SQL_SCRIPTS.sql

\if :current_db_postgres
-- \i Get_PG_PROFILE_report.sql

\else
\qecho '<p></p>'
\qecho 'Отчет pg_profile по двум последним снимка формируется  одновременно с verify отчетом при подключении к БД postgres'
\qecho '<p></p>'
\endif

\o