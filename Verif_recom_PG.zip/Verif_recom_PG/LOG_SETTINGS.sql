-- Настройки догирования в журнал

\qecho '<P><A class=awr name=51></A>'
\qecho '<H2 class=awr>Настройки логирования в журнал</H2>'

\qecho '<A class=awr_ital>Скрипт LOG_SETTINGS.sql</A>'
\qecho '<p></p>'

\qecho <p><a class=awr_ital> Подробнее о настройках логирования см: </a>
\qecho <a class=awr_href href="https://https://postgrespro.ru/docs/postgresql/16/runtime-config-logging/">Регистрация ошибок и протоколирование работы сервера!</a></p>

\qecho <p><a class=awr_ital> Для анализа журналла с целью выявления потенциальных проблем с базой данных используйте расширение : </a>
\qecho <a class=awr_href href="https://confluence.moscow.alfaintra.net/display/UP4ALL/pgBadger+fast+PostgreSQL+Log+Analyzer">pgBadger fast PostgreSQL Log Analyzer</a></p>

\qecho <p></p>
SELECT  pg_current_logfile()  AS  "Текущий файл журнала";
\qecho <p></p>

\qecho <details>
\qecho   <summary>Раскрыть</summary>

WITH log_setting AS(
SELECT name , setting, short_desc, context
               FROM pg_settings
               WHERE name LIKE ('%log%')
               union
               SELECT name, setting, short_desc, context
               FROM pg_settings
               WHERE name IN ('log_statement', 'log_min_error_statement', 'log_destination', 'logging_collector',
                              'log_directory', 'log_filename', 'log_rotation_age', 'log_rotation_size',
                              'log_truncate_on_rotation', 'syslog_ident', 'syslog_sequence_numbers',
                              'syslog_split_messages', 'log_min_messages', 'log_min_error_statement',
                              'log_min_duration_statement', 'log_statement_sample_rate', 'log_transaction_sample_rate',
                              'log_startup_progress_interval', 'application_name', 'debug_print_parse',
                              'debug_print_rewritten', 'debug_print_plan', 'debug_pretty_print',
                              'log_autovacuum_min_duration', 'log_checkpoints', 'log_connections', 'log_disconnections',
                              'log_duration', 'log_line_prefix', 'log_parameter_max_length',
                              'log_parameter_max_length_on_error')
                EXCEPT
                SELECT name, setting, short_desc, context
                FROM pg_settings
                WHERE name IN ('max_logical_replication_workers','syslog_facility','syslog_ident','syslog_sequence_numbers', 'syslog_split_messages','wal_log_hints')
               ),
reccom AS (
SELECT  'application_name'  AS name, ''  AS "Rec_Value", 'Обычно устанавливается приложением при подключении к серверу' AS "Comment"
union
SELECT  'auto_explain.log_analyze'  AS name, 'on'  AS "Rec_Value", 'При включении параметра auto_explain.log_analyze в протокол будет записываться вывод команды EXPLAIN ANALYZE, а не простой EXPLAIN. По умолчанию этот параметр отключён' AS "Comment"
union
SELECT  'auto_explain.log_buffers'  AS name, 'on'  AS "Rec_Value", 'Определяет, будет ли при протоколировании плана выполнения выводиться статистика об использовании буферов; Действует, только если включён параметр auto_explain.log_analyze' AS "Comment"
union
SELECT  'auto_explain.log_format'  AS name, 'text'  AS "Rec_Value", 'Выбирает формат вывода для EXPLAIN. Он может принимать значение text, xml, json и yaml' AS "Comment"
union
SELECT  'auto_explain.log_level'  AS name, 'log'  AS "Rec_Value", 'выбирает уровень, с которым auto_explain будет выводить в протокол планы запросов. Допустимые значения: DEBUG5, DEBUG4, DEBUG3, DEBUG2, DEBUG1, INFO, NOTICE, WARNING и LOG. По умолчанию подразумевается LOG' AS "Comment"
union
SELECT  'auto_explain.log_min_duration'  AS name, '2000'  AS "Rec_Value", 'задаёт время выполнения оператора, в миллисекундах, при превышении которого план оператора будет протоколироваться. При значении = 0, протоколируются все планы, а при -1 (по умолчанию) протоколирование планов отключается. В качестве первого приближения можно брать Max Execution times из отчета pgProfile' AS "Comment"
union
SELECT  'auto_explain.log_nested_statements'  AS name, 'off'  AS "Rec_Value", 'При включении параметра протоколированию могут подлежать и вложенные операторы (операторы, выполняемые внутри функции). Когда он отключён, протоколируются планы запросов только верхнего уровня' AS "Comment"
union
SELECT  'auto_explain.log_settings'  AS name, 'on'  AS "Rec_Value", 'определяет, будут ли вместе с планами выполнения выводиться изменённые параметры конфигурации. При его включении выводятся только те параметры, которые влияют на планирование запросов и имеют значения, отличающиеся от встроенных' AS "Comment"
union
SELECT  'auto_explain.log_timing'  AS name, 'off'  AS "Rec_Value", 'Определяет, будет ли при протоколировании плана выполнения выводиться длительность на уровне узлов. Издержки от постоянного чтения системных часов могут значительно замедлить запросы в некоторых системах' AS "Comment"
union
SELECT  'auto_explain.log_triggers'  AS name, 'off'  AS "Rec_Value", 'В протокол будет записываться статистика выполнения триггеров. Этот параметр действует, только если включён параметр auto_explain.log_analyze' AS "Comment"
union
SELECT  'auto_explain.log_verbose'  AS name, 'off'  AS "Rec_Value", 'Определяет, будут ли при протоколировании плана выполнения выводиться подробные сведения; он равнозначен указанию VERBOSE команды EXPLAIN' AS "Comment"
union
SELECT  'auto_explain.log_wal'  AS name, 'on'  AS "Rec_Value", 'Определяет, будет ли при протоколировании плана выполнения выводиться статистика об использовании WAL' AS "Comment"
union
SELECT 'debug_pretty_print' AS name, 'on' AS "Rec_Value", 'Включает выравнивание сообщений, выводимых debug_print_parse, debug_print_rewritten или debug_print_plan' AS "Comment"
union
SELECT 'debug_print_parse' AS name, 'off' AS "Rec_Value", 'Включает вывод дерева запроса' AS "Comment"
union
SELECT 'debug_print_plan' AS name, 'off' AS "Rec_Value", 'Включает вывод плана выполнения запроса' AS "Comment"
union
SELECT 'debug_print_rewritten' AS name, 'off' AS "Rec_Value", 'Включает вывод дерева запроса после применения правил' AS "Comment"
union
SELECT 'log_autovacuum_min_duration' AS name, '500' AS "Rec_Value", 'Задаёт время выполнения действия автоочистки, при превышении которого информация об этом действии записывается в журнал. При нулевом значении в журнале фиксируются все действия автоочистки. Значение -1 отключает журналирование действий автоочистки. ' AS "Comment"
union
SELECT 'log_checkpoints' AS name, 'on' AS "Rec_Value", 'Включает протоколирование выполнения контрольных точек и точек перезапуска сервера' AS "Comment"
union
SELECT 'log_connections' AS name, 'on' AS "Rec_Value", 'Включает протоколирование всех попыток подключения к серверу, в том числе успешного завершения как аутентификации (если она требуется), так и авторизации клиентов' AS "Comment"
union
SELECT 'log_destination' AS name, 'stderr' AS "Rec_Value", 'указывается один или несколько методов протоколирования, разделённых запятыми. По умолчанию используется stderr.' AS "Comment"
union
SELECT 'log_directory' AS name, 'pg_log' AS "Rec_Value", 'При включённом logging_collector, определяет каталог, в котором создаются журнальные файлы. Можно задавать как абсолютный путь, так и относительный от каталога данных кластера.По умолчанию — log' AS "Comment"
union
SELECT 'log_disconnections' AS name, 'on' AS "Rec_Value", 'Включает протоколирование завершения сеансаЮ. Плюс длительность сеанса ' AS "Comment"
union
SELECT 'log_duration' AS name, 'on' AS "Rec_Value", 'Записывает продолжительность каждой завершённой команды. По умолчанию выключен.' AS "Comment"
union
SELECT 'log_error_verbosity' AS name, 'default' AS "Rec_Value", 'Управляет количеством детальной информации, записываемой в журнал сервера для каждого сообщения. Допустимые значения: TERSE, DEFAULT и VERBOSE' AS "Comment"
union
SELECT 'log_executor_stats' AS name, 'off' AS "Rec_Value", 'Вывод статистики по производительности стадии впыолнения соответствующего модуля' AS "Comment"
union
SELECT 'log_file_mode' AS name, '0600' AS "Rec_Value", 'В системах Unix задаёт права доступа к журнальным файлам, при включённом logging_collector.По умолчанию 0600' AS "Comment"
union
SELECT 'log_filename' AS name, 'postgresql-%a.log' AS "Rec_Value", 'Задаёт имена журнальных файлов.Значение по умолчанию postgresql-%Y-%m-%d_%H%M%S.log.' AS "Comment"
union
SELECT 'logging_collector' AS name, 'on' AS "Rec_Value", 'Включает сборщик сообщений (logging collector). Это фоновый процесс, который собирает отправленные в stderr сообщения и перенаправляет их в журнальные файлы' AS "Comment"
union
SELECT 'log_hostname' AS name, 'off' AS "Rec_Value", 'При включении этого параметра, дополнительно будет фиксироваться и имя сервера. Обратите внимание, что в зависимости от применяемого способа разрешения имён, это может отрицательно сказаться на производительности.' AS "Comment"
union
SELECT 'log_line_prefix' AS name, '%t [%p]: [%l-1] ' AS "Rec_Value", 'Строка, в стиле функции printf, которая выводится в начале каждой строки журнала сообщений. С символов % начинаются управляющие последовательности, которые заменяются статусной информацией. По умолчанию параметр имеет значение ''%m [%p] '', в журнал выводится время и идентификатор процесса (PID)' AS "Comment"
union
SELECT 'log_lock_waits' AS name, 'on' AS "Rec_Value", 'Определяет, нужно ли фиксировать в журнале события, когда сеанс ожидает получения блокировки дольше, чем указано в deadlock_timeout.' AS "Comment"
union
SELECT  'log_min_duration_statement' AS name, '50000' AS "Rec_Value",'Записывает в журнал продолжительность выполнения всех команд, время работы которых не меньше указанного в ms.' AS "Comment"
union
SELECT  'log_min_error_statement' AS name, 'error' AS "Rec_Value",'Управляет тем, какие SQL-операторы, завершившиеся ошибкой, записываются в журнал сервера. SQL-оператор будет записан в журнал, если он завершится ошибкой с указанным уровнем важности или выше. Допустимые значения: DEBUG5, DEBUG4, DEBUG3, DEBUG2, DEBUG1, INFO, NOTICE, WARNING, ERROR, LOG, FATAL и PANIC. По умолчанию используется ERROR. Это означает, что в журнал сервера будут записаны все операторы, завершившиеся сообщением с уровнем важности ERROR, LOG, FATAL и PANIC. Чтобы фактически отключить запись операторов с ошибками, установите для этого параметра значение PANIC' AS "Comment"
union
SELECT  'log_min_messages' AS name, 'warning' AS "Rec_Value",'Управляет минимальным уровнем сообщений, записываемых в журнал сервера. Допустимые значения DEBUG5, DEBUG4, DEBUG3, DEBUG2, DEBUG1, INFO, NOTICE, WARNING, ERROR, LOG, FATAL и PANIC. Каждый из перечисленных уровней включает все идущие после него. Чем дальше в этом списке уровень сообщения, тем меньше сообщений будет записано в журнал сервера. По умолчанию используется WARNING.' AS "Comment"
union
SELECT 'log_parser_stats' AS name, 'off' AS "Rec_Value", 'Включает вывод статистики по разбору оператора' AS "Comment"
union
SELECT 'log_planner_stats' AS name, 'off' AS "Rec_Value", 'Включает вывод статистики по подготовке плана выполнения оператора' AS "Comment"
union
SELECT 'log_replication_commands' AS name, 'off' AS "Rec_Value", 'Включает запись в журнал сервера всех команд репликации. Значение по умолчанию — off' AS "Comment"
union
SELECT 'log_rotation_age' AS name, '1440' AS "Rec_Value", 'этот параметр определяет максимальное время жизни отдельного журнального файла, по истечении которого создаётся новый файл. Если это значение задаётся без единиц измерения, оно считается заданным в минутах. Значение по умолчанию — 24 часа. При нулевом значении смена файлов по времени не производится' AS "Comment"
union
SELECT 'log_rotation_size' AS name, '0' AS "Rec_Value", 'параметр определяет максимальный размер отдельного журнального файла. При достижении этого размера создаётся новый файл. Если это значение задаётся без единиц измерения, оно считается заданным в килобайтах. Значение по умолчанию — 10 мегабайт. При нулевом значении смена файлов по размеру не производится' AS "Comment"
union
SELECT 'log_statement_stats' AS name, 'on' AS "Rec_Value", 'Включает вывод общей статистики по операторам' AS "Comment"
union
SELECT  'log_statement'  AS name, 'all' AS "Rec_Value", 'Управляет тем, какие SQL-команды записывать в журнал.  none (отключено), ddl, mod и all (все команды)' AS "Comment"
union
SELECT 'log_temp_files' AS name, '0' AS "Rec_Value", 'Управляет регистрацией в журнале имён и размеров временных файлов. Когда этот параметр включён, при удалении временного файла информация о нём может записываться в журнал с указанием размера файла в байтах. При нулевом значении записывается информация обо всех файлах, а при положительном — о файлах, размер которых не меньше заданной величины. Если это значение задаётся без единиц измерения, оно считается заданным в килобайтах. Значение по умолчанию равно -1, то есть запись такой информации отключена.' AS "Comment"
union
SELECT 'log_timezone' AS name, 'W-SU' AS "Rec_Value", 'Устанавливает часовой пояс для штампов времени при записи в журнал сервера. В отличие от TimeZone, это значение одинаково для всех баз данных кластера, поэтому для всех сеансов используются согласованные значения штампов времени. Встроенное значение по умолчанию GMT' AS "Comment"
union
SELECT 'log_transaction_sample_rate' AS name, '0' AS "Rec_Value", 'Задаёт долю транзакций, команды из которых будут записываться в журнал дополнительно (помимо команд, записываемых по другим причинам). Этот параметр действует на все транзакции, независимо от длительности команд. Выборка осуществляется вероятностным образом, например, со значением 0.1 можно считать, что каждая транзакция может попасть в журнал с шансом один к десяти.' AS "Comment"
union
SELECT 'log_truncate_on_rotation' AS name, 'on' AS "Rec_Value", 'Если параметр logging_collector включён, PostgreSQL будет перезаписывать существующие журнальные файлы, а не дописывать в них. Однако перезапись при переключении на новый файл возможна только в результате ротации по времени, но не при старте сервера или ротации по размеру файла. При выключенном параметре всегда продолжается запись в существующий файл. Например, включение этого параметра в комбинации с log_filename равным postgresql-%H.log, приведёт к генерации 24-х часовых журнальных файлов, которые циклически перезаписываются' AS "Comment"
)
SELECT log_setting.name as "Имя параметра конфигурации", log_setting.setting as "Значение" , reccom."Rec_Value" AS "Рекомендованное", reccom."Comment"
, log_setting.short_desc, log_setting.context
FROM log_setting LEFT JOIN reccom ON log_setting.name = reccom.name
ORDER BY 1
;

\qecho </details>