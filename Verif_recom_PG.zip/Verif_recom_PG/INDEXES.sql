\qecho '<p></p>'
\qecho '<P><A class=awr name=121></A>'
\qecho '<H2 class=awr>Индексы</H2>'

\qecho '<A class=awr_ital>Скрипт INDEXES.sql</A>'
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=1211></A>'
\qecho '<H5 class=awr>Invalid индексы в порядке убывания размера</H5>'
\qecho '<p></p>'

select count (*) as count_of_invalid_indxes from pg_index WHERE pg_index.indisvalid = false ;

with table_info as
         (SELECT pg_index.indrelid, pg_class.oid, pg_class.relname as table_name
          from pg_class,
               pg_index
          where pg_index.indrelid = pg_class.oid)

SELECT distinct pg_index.indexrelid  as INDX_ID,
                pg_class.relname     as index_name,
                table_info.table_name,
                pg_namespace.nspname as schema_name,
                pg_class.relowner    as owner_id,
                pg_index.indisvalid  as indx_is_valid
                , pg_size_pretty(pg_relation_size(pg_index.indexrelid)) as size_ind_pr
                , pg_relation_size(pg_index.indexrelid) as size_ind_bt
FROM pg_class,
     pg_index,
     pg_namespace,
     table_info
WHERE pg_index.indisvalid = false
  AND pg_index.indexrelid = pg_class.oid
  and pg_class.relnamespace = pg_namespace.oid
  and pg_index.indrelid = table_info.oid
  order by pg_relation_size(pg_index.indexrelid) desc
limit 15;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1211></A>'
\qecho '<H5 class=awr>Индексы большого размера</H5>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания size_ind'
\qecho '</UL>'
\qecho '<p></p>'
SELECT
    pg_size_pretty(pg_relation_size(ai.indexrelid)) as size_ind,
    ai.relname,
    indexrelname,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM
    pg_stat_all_indexes ai JOIN pg_index i ON i.indexrelid = ai.indexrelid
    JOIN pg_class C on c.relname = ai.relname
                           --AND C.relispartition = FALSE

WHERE
    -- Primary key cannot be partial
    NOT i.indisprimary
    --and ai.schemaname = 'public'
    AND ai.indexrelname NOT LIKE 'pg_toast_%'
      -- Larger than 10MB
    --AND pg_relation_size(ai.indexrelid)>10 * 1024 ^ 2
ORDER BY
    pg_relation_size(ai.indexrelid) DESC
LIMIT 15;


\qecho '<p></p>'
\qecho '<P><A class=awr name=1211></A>'
\qecho '<H5 class=awr>Индексы с большим количеством блоков, прочитанных с диска.</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 15 в порядке убывания idx_blks_read'
\qecho '</UL>'
\qecho '<p></p>'

select * from pg_statio_all_indexes
where idx_blks_read >0
order by idx_blks_read desc
limit 15;

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Неиспользуемые индексы.</H5>'
\qecho '<A class=awr_ital>Скрипт Indx_UnUsed.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые пятнадцать по размеру индексов'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_UnUsed.sql

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы, кандидаты на пересоздание как частичные</H5>'
\qecho '<A class=awr_ital>Скрипт Indx_Candidate_Partial.sql</A>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые пятнадцать по размеру индексов'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_Candidate_Partial.sql

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы, с большим количеством NULL-записей</H5>'
\qecho '<A class=awr_ital>Скрипт Indx_with_NULL.sql</A>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые пятнадцать по размеру индексов'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_with_NULL.sql

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы с одинаковым набором первых полей</H5>'
\qecho '<A class=awr_ital>Скрипт indx_duplicate_first_fields.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только для основных таблиц первые пятнадцать по размерам'
\qecho '</UL>'
\qecho '<p></p>'


\i indx_duplicate_first_fields.sql
-- Вариант по всем тааблицам и секциям
-- \i duplicate_indexes_fuzzy.sql

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы с одинаковым набором первых полей</H5>'
\qecho '<A class=awr_ital>Скрипт indx_duplicate_first_fields.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только для основных таблиц первые пятнадцать по размерам'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_NO_fin_timestamp.sql


\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы с boolean</H5>'
\qecho '<A class=awr_ital>Скрипт Indx_with_boolean.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только первые пятнадцать по размерам'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_with_boolean.sql

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы btree с arrays</H5>'
\qecho '<A class=awr_ital>Скрипт Indx_with_arrays.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только первые пятнадцать по размерам'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_with_arrays.sql

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=113></A>'
\qecho '<H5 class=awr>Индексы с избыточными полями</H5>'
\qecho '<A class=awr_ital>Скрипт Indx_redundant.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только первые пятнадцать по размерам'
\qecho '</UL>'
\qecho '<p></p>'

\i Indx_redundant.sql

\qecho <P><A class=awr href="#121">Back to Индексы</A> <BR><A class=awr href="#top">Back to Top</A>




