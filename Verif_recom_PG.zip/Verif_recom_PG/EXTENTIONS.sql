\qecho '<P><A class=awr name=31></A>'
\qecho '<H3 class=awr>Расширения, Дополнительные модули</H3>'
-- \qecho ' <b style="color:red"><Большинство расширений должны быть установлены в БД postgres !</b><br>'
-- \qecho ' <b style="color:red">Проверять наличие расширений нужно подключившись к БД postgres !</b>'
\qecho '<A class=awr_ital>Скрипт EXTENTIONS.sql</A>'
\qecho '<p></p>'


\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Загруженные библиотеки</H3>'
\qecho '<p></p>'

select
    lc_set.name, lc_set.setting, lc_set.short_desc, lc_set.context from pg_catalog.pg_settings lc_set
where lc_set.name = 'shared_preload_libraries';

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Дополнительные модули, рекомендованные к установке</H3>'
\qecho '<p></p>'

SELECT *
FROM (VALUES ('auto_explain', 'Обязательное', 'INSTANCE',
              'https://www.postgresql.org/docs/16/auto-explain.html')) AS Q (module, must, install_in, link);

\if :current_db_postgres
\i Over_Installed_Extensions.sql
\endif

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Расширения, установленные на данной конкретной БД </H3>'
\qecho :vt_current_db
\qecho '<p></p>'

SELECT ex.extname "Установленное extension",
       extversion "Версия"
       ,to_number(extversion, 'FM99.99')
       ,current_database() as "Текущая БД"
FROM pg_extension ex;
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Настройки установленных на инстансе расширений</H3>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

SELECT *
from pg_catalog.pg_settings
WHERE NAME LIKE '%dblink%'
   OR NAME LIKE '%pg_stat_statements%'
   OR NAME LIKE '%profile%'
   OR NAME LIKE '%pg_stat_kcache%'
   OR NAME LIKE '%pg_cron%'

   OR NAME LIKE  '%pg_store_plans%'
   OR NAME LIKE  '%pg_hint_plan%'
   OR NAME LIKE  '%sr_plan%'

   OR NAME LIKE  '%pgaudit%'
   OR NAME LIKE  '%pgauditlogtofile%'
   OR NAME LIKE  '%pg_repack%'
   OR NAME LIKE  '%pg_buffercache%'
   OR NAME LIKE  '%pg_wait_sampling%'
   OR NAME LIKE  '%system_stats%'
   OR NAME LIKE  '%pgpro_stats%'
ORDER BY  1;

-- SELECT * from pg_catalog.pg_settings WHERE NAME LIKE '%pgpro_stats%';


\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Проверка обязательных и рекомендуемых к установке расширений</H3>'
\qecho '<p></p>'

-- Для БД postgres
\if :current_db_postgres

WITH compulsory_ex AS
    (
    SELECT *
FROM (VALUES ('pg_stat_statements','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1028337151')
             ,('pg_profile','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1154220271')
             ,('pg_alfasys','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/display/OSSG/pg_alfasys')
             ,('pg_stat_kcache','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/display/UP4ALL/pg_stat_kcache+extension')
             ,('pg_cron','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/display/OSSG/pg_cron')
             --,('pgaudit','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/display/UP4ALL/pgaudit')
             --,('pgauditlogtofile','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/display/UP4ALL/pgaudit')
             ,('pg_hint_plan','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1667029162')
             ,('pg_store_plans','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1677693390')
             ,('pg_wait_sampling','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/display/UP4ALL/pg_wait_sampling')
             ,('system_stats','Обязательное','только БД postgres','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1769205819')

             ,('dblink','Обязательное','каждую конкретную БД','')

             ,('pgstattuple','По необходимости','каждую конкретную БД','https://confluence.moscow.alfaintra.net/display/UP4ALL/pgstattuple')
             ,('pg_buffercache','По необходимости','каждую конкретную БД','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1080039114')
             ,('pg_repack','По необходимости','каждую конкретную БД','https://confluence.moscow.alfaintra.net/display/UP4ALL/pg_repack+--+Reorganize+tables+in+PostgreSQL+with+minimal+locks')

             ,('pg_prewarm','Рекоммендуемое','DB','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1335027295')
             ,('pgsentinel','Рекоммендуемое','DB','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1195450381')
             ,('pgBadger','Рекоммендуемое','Отдельный хост','https://confluence.moscow.alfaintra.net/display/UP4ALL/pgBadger+fast+PostgreSQL+Log+Analyzer')

      ) AS Q (extname,must, install_in, link)
),
control_ex AS
    (
           select ex.extname
          , extversion
          ,2.0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ system_stats установлено'
                ELSE '- pg_cron НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 2
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'system_stats'

          union

          select ex.extname
          , extversion
          ,1.6 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_cron установлено'
                ELSE '- pg_cron НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_cron'

          union

          select ex.extname
          , extversion
          ,1.1 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_wait_sampling установлено'
                ELSE '- pg_wait_sampling НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_wait_sampling'

          union

          select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_stat_kcache установлено'
                ELSE '- pg_stat_kcache НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_stat_kcache'


     union

          select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pgaudit установлено'
                ELSE '- pgaudit НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgaudit'

          union

          select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pgauditlogtofile установлено'
                ELSE '- pgauditlogtofile НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgauditlogtofile'

     union

            select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_prewarm установлено'
                ELSE '- pg_prewarm НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_prewarm'

     union

      select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_buffercache установлено'
                ELSE '- pg_buffercache НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию. Требуется установка в каждую конкретную проблемную БД '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_buffercache'

     union

     select ex.extname
          , extversion
          ,1.2 as last_ver
          , 2 as check
          ,  ''                                                                   "Comment"
          , 'Используйте расширение для получения отчетов'                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgBadger'

     union
        select ex.extname
          , extversion
          ,1.2 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.0) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_alfasys установлено'
                ELSE '- pg_alfasys НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_alfasys'
     union
    select ex.extname
          , extversion
          ,1.2 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.2) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ dblink установлено'
                ELSE '- dblink НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.2
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'dblink'
     union

    select ex.extname
          , extversion
          ,1.0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') > 1.0) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 1.0 THEN '+ pgsentinel установлено'
                ELSE '- pgsentinel НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.0
                    THEN
                    'Установите последнюю версию. Требуется установка в каждую конкретную проблемную БД'
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgsentinel'

     union

         select ex.extname
          , extversion
          ,1.5 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.5) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 1.0 THEN '+ pgstattuple установлено'
                ELSE '- pgstattuple НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.5
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgstattuple'

     union
     select ex.extname
          , extversion
          , 1.6 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.6::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_stat_statements установлено'
                ELSE '- pg_stat_statements НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.10
                    THEN
                    'Установите последнюю подходящую версию'
                ELSE
                    'Устанавливается в конкретную базу(postgres), сбор статистики осуществляется глобально для всех запросов независимо от того, в каких базах они работают'
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname = 'pg_stat_statements'

     union

     select ex.extname
          , extversion
          , 4.8 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 4.8::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_profile установлено'
                ELSE '- pg_profile НЕ установлено'
         END                                                                               "Comment"
          , 'Установите последнюю версию расширения подходящую для текущей версии инстанса 16 supported since version 4.3 15 supported since version 4.1
14 supported since version 0.3.4
13 supported since version 0.1.3
12 supported since version 0.1.0'
              "Recom"
     from pg_extension ex
     where ex.extname = 'pg_profile'

     union

     select ex.extname
          , extversion
          , 1.5 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.5::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_repack установлено'
                ELSE '- pg_profile НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.5
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname ='pg_repack'

     union

     select ex.extname
          , extversion
          , 1.5 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.5::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_hint_plan установлено'
                ELSE '- pg_hint_plan НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.5
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname ='pg_hint_plan'

          union

     select ex.extname
          , extversion
          , 1.5 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.8::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_store_plans установлено'
                ELSE '- pg_store_plans НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.8
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname ='pg_store_plans'

)

select "extention", "must", "install_in", extversion as "Версия"
                  , CASE
                        WHEN last_ver IS NULL
                            THEN last_ver
                        ELSE last_ver
                    END "Последняя"
                  , CASE
                        WHEN "check" IS NULL
                            THEN
                            '0'
                        ELSE "check"
                    END as check
      ,
     CASE
                        WHEN "Comment" IS NULL
                            THEN '- не установлено !'
                        ELSE "Comment"
                    END "Comment"
     ,
     CASE
                        WHEN "Recom" IS NULL
                            THEN 'Установите последнюю версию'
                        ELSE "Recom"
                    END "Рекомендации"
     , "link"
    from
   (
    SELECT compulsory_ex.extname as "extention", compulsory_ex.must as "must", install_in as "install_in", control_ex.*, compulsory_ex.link as "link"
    FROM compulsory_ex LEFT OUTER JOIN control_ex ON compulsory_ex.extname = control_ex.extname
   ) a
    order by "must" asc, "check" asc, "extention" asc
;

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=1613></A>'
\qecho '<H3 class=awr>Просмотреть все задания, запланированные в настоящее время с помощью pg_cron</H3>'
--\qecho '<UL>'
--\qecho '<LI class=awr>в порядке убывания суммарного времени выполнения, секунды'
--\qecho '</UL>'
\qecho '<p></p>'


SELECT * FROM cron.job;

-- Для всех остальных БД, кроме postgres
\else

WITH compulsory_ex AS
    (
    SELECT *
FROM (VALUES  ('dblink','По необходимости','каждую конкретную БД','')
             ,('pgstattuple','По необходимости','каждую конкретную БД','https://confluence.moscow.alfaintra.net/display/UP4ALL/pgstattuple')
             ,('pg_buffercache','По необходимости','каждую конкретную БД','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1080039114')
             ,('pg_repack','По необходимости','каждую конкретную БД','https://confluence.moscow.alfaintra.net/display/UP4ALL/pg_repack+--+Reorganize+tables+in+PostgreSQL+with+minimal+locks')

             ,('pg_prewarm','Рекоммендуемое','DB','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1335027295')
             ,('pgsentinel','Рекоммендуемое','DB','https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1195450381')
             ,('pgBadger','Рекоммендуемое','Отдельный хост','https://confluence.moscow.alfaintra.net/display/UP4ALL/pgBadger+fast+PostgreSQL+Log+Analyzer')

      ) AS Q (extname,must, install_in, link)
),
control_ex AS
    (      select ex.extname
          , extversion
          ,1.1 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_wait_sampling установлено'
                ELSE '- pg_wait_sampling НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_wait_sampling'

          union

          select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_stat_kcache установлено'
                ELSE '- pg_stat_kcache НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_stat_kcache'


     union

          select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pgaudit установлено'
                ELSE '- pgaudit НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgaudit'

          union

          select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pgauditlogtofile установлено'
                ELSE '- pgauditlogtofile НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgauditlogtofile'

     union

            select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_prewarm установлено'
                ELSE '- pg_prewarm НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_prewarm'

     union

      select ex.extname
          , extversion
          ,0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_buffercache установлено'
                ELSE '- pg_buffercache НЕ установлено '
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 0
                    THEN
                    'Установите последнюю версию. Требуется установка в каждую конкретную проблемную БД '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_buffercache'

     union

     select ex.extname
          , extversion
          ,1.2 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.0) THEN 1::numeric ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pgBadger установлено'
                ELSE '- pgBadger НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgBadger'

     union
        select ex.extname
          , extversion
          ,1.2 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.0) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_alfasys установлено'
                ELSE '- pg_alfasys НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.0
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pg_alfasys'
     union
    select ex.extname
          , extversion
          ,1.2 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.2) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ dblink установлено'
                ELSE '- dblink НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.2
                    THEN
                    'Установите последнюю версию '
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'dblink'
     union

    select ex.extname
          , extversion
          ,1.0 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') > 1.0) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 1.0 THEN '+ pgsentinel установлено'
                ELSE '- pgsentinel НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.0
                    THEN
                    'Установите последнюю версию. Требуется установка в каждую конкретную проблемную БД'
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgsentinel'

     union

         select ex.extname
          , extversion
          ,1.5 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.5) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 1.0 THEN '+ pgstattuple установлено'
                ELSE '- pgstattuple НЕ установлено'
            END                                                                        "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.5
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
            END                                                                        "Recom"
     from pg_extension ex
     where ex.extname = 'pgstattuple'

     union
     select ex.extname
          , extversion
          , 1.6 as last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.6::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_stat_statements установлено'
                ELSE '- pg_stat_statements НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.10
                    THEN
                    'Установите последнюю подходящую версию'
                ELSE
                    'Устанавливается в конкретную базу(postgres), сбор статистики осуществляется глобально для всех запросов независимо от того, в каких базах они работают'
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname = 'pg_stat_statements'

     union

     select ex.extname
          , extversion
          , 4.8 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 4.1::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_profile установлено'
                ELSE '- pg_profile НЕ установлено'
         END                                                                               "Comment"
          , 'Установите последнюю версию расширения подходящую для текущей версии инстанса 16 supported since version 4.3 15 supported since version 4.1
14 supported since version 0.3.4
13 supported since version 0.1.3
12 supported since version 0.1.0'
              "Recom"
     from pg_extension ex
     where ex.extname = 'pg_profile'

     union

     select ex.extname
          , extversion
          , 1.5 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.5::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_repack установлено'
                ELSE '- pg_profile НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.5
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname ='pg_repack'

     union

     select ex.extname
          , extversion
          , 1.5 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.5::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_hint_plan установлено'
                ELSE '- pg_hint_plan НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.5
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname ='pg_hint_plan'

          union

     select ex.extname
          , extversion
          , 1.5 last_ver
          , CASE WHEN (to_number(extversion, 'FM99.99') >= 1.8::numeric) THEN 1::numeric  ELSE 2::numeric  END as check
          , CASE
                WHEN to_number(extversion, 'FM99.99') > 0 THEN '+ pg_store_plans установлено'
                ELSE '- pg_store_plans НЕ установлено'
         END                                                                               "Comment"
          , CASE
                WHEN to_number(extversion, 'FM99.99') < 1.8
                    THEN
                    'Установите последнюю версию'
                ELSE
                    ''
         END                                                                               "Recom"
     from pg_extension ex
     where ex.extname ='pg_store_plans'

)

select "extention", "must", "install_in", extversion as "Версия"
                  , CASE
                        WHEN last_ver IS NULL
                            THEN last_ver
                        ELSE last_ver
                    END "Последняя"
                  , CASE
                        WHEN "check" IS NULL
                            THEN
                            '0'
                        ELSE "check"
                    END as check
      ,
     CASE
                        WHEN "Comment" IS NULL
                            THEN '- не установлено !'
                        ELSE "Comment"
                    END "Comment"
     ,
     CASE
                        WHEN "Recom" IS NULL
                            THEN 'Установите последнюю версию'
                        ELSE "Recom"
                    END "Рекомендации"
     , "link"
    from
   (
    SELECT compulsory_ex.extname as "extention", compulsory_ex.must as "must", install_in as "install_in", control_ex.*, compulsory_ex.link as "link"
    FROM compulsory_ex LEFT OUTER JOIN control_ex ON compulsory_ex.extname = control_ex.extname
   ) a
    order by "must" asc, "check" asc, "extention" asc
;
\endif

-- select * from pg_extension

\if :current_db_postgres

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Последние по времени снимки pg_profile</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Последние по времени 9 снимков'
\qecho '<LI class=awr>Команда для получения отчета, пример SELECT profile.get_report(1,5,11);'
\qecho '<LI class=awr>Отчет pg_profile между двумя последними снимками будет создан в директории с основным отчетом'
\qecho '</UL>'
\qecho '<p></p>'

SELECT CASE WHEN (public.ver_get_profile_primary_server_id()) >= t.server_id THEN 'Primary' ELSE 'Replica' END as "role of instance",
    t.server_id, s.server_name, t.sample_id, t.sample_time
FROM profile.samples t
         join profile.servers s on t.server_id = s.server_id
ORDER BY sample_time DESC
LIMIT 9;

\else
\qecho '<p></p>'
-- \qecho 'Отчет pg_profile по двум последним снимка формируется  одновременно с verify отчетом при подключении к БД postgres'
-- \qecho '<p></p>'
\endif

\qecho '<p></p>'

\qecho <P><A class=awr href="#31">Back to Расширения, Дополнительные модули</A> <BR><A class=awr href="#top">Back to Top</A>
