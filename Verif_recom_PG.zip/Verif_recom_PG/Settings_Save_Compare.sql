\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H4 class=awr>Сравнениие настроек текущего инстанса и настроек из файла example_settings_01.csv </H4>'

\qecho '<UL>'
\qecho '<LI class=awr>Показаны только те настройки:'
\qecho '<LI class=awr>которые есть в обоих сравниваемых списках, но имеют разные значения '
\qecho '<LI class=awr>которые отсутсвую в одном из списков'
\qecho '</UL>'
\qecho '<p></p>'

select * from (select cs.name
                    , cs.setting
                    , im.setting as                                       imported_setting
                    , im.name    as                                       imported_name
                    , CASE WHEN cs.setting = im.setting THEN 1 ELSE 0 END "check"
                    , cs.unit
                    , cs.vartype
                    , cs.source
               from pg_catalog.pg_settings cs
                        FULL OUTER JOIN public.ver_imported_pg_settings im on cs.name = im.name) a1
where a1."check" =0
union
select '0_Project' as name
                    , :vt_project_mark as setting
                    , null as                                       imported_setting
                    , null    as                                       imported_name
                    , 0 as "check"
                    , null unit
                    , null vartype
                    , null source
order by name;