\qecho '<p></p>'
\qecho '<A class=awr_ital>Скрипт BLOAT_TABLE_pgstattuple.sql</A>'
\qecho '<p></p>'

\qecho '<p></p>'
-- \qecho '<P><A class=awr name=112></A>'
\qecho '<H3 class=awr>Оценка bloat для таблиц с исползование функции pgstattuple</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны таблицы по заданной маске '
-- \qecho '<LI class=awr> упорядочены по схеме, названию  таблицы'
\qecho '</UL>'
\qecho '<p></p>'

\prompt 'This utility will read tables with given mask using pgstattuple extension and return top 20 bloated tables.\nWARNING: without table mask query will read all available tables which could cause I/O spikes.\nPlease enter mask for table name (check all tables if nothing is specified): ' tablename
--pgstattuple extension required
--WARNING: without table name/mask query will read all available tables which could cause I/O spikes

select table_name,
pg_size_pretty(relation_size + toast_relation_size) as total_size,
pg_size_pretty(toast_relation_size) as toast_size,
round(((relation_size - (relation_size - free_space)*100/fillfactor)*100/greatest(relation_size, 1))::numeric, 1) table_waste_percent,
pg_size_pretty((relation_size - (relation_size - free_space)*100/fillfactor)::bigint) table_waste,
round(((toast_free_space + relation_size - (relation_size - free_space)*100/fillfactor)*100/greatest(relation_size + toast_relation_size, 1))::numeric, 1) total_waste_percent,
pg_size_pretty((toast_free_space + relation_size - (relation_size - free_space)*100/fillfactor)::bigint) total_waste
from (
    select
    (case when n.nspname = 'public' then format('%I', c.relname) else format('%I.%I', n.nspname, c.relname) end) as table_name,
    (select free_space from pgstattuple(c.oid)) as free_space,
    pg_relation_size(c.oid) as relation_size,
    (case when reltoastrelid = 0 then 0 else (select free_space from pgstattuple(c.reltoastrelid)) end) as toast_free_space,
    coalesce(pg_relation_size(c.reltoastrelid), 0) as toast_relation_size,
    coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]),'100')::real AS fillfactor
    from pg_class c
    left join pg_namespace n on (n.oid = c.relnamespace)
    where nspname not in ('pg_catalog', 'information_schema')
    and nspname !~ '^pg_toast' and nspname !~ '^pg_temp' and relkind in ('r', 'm') and (relpersistence = 'p' or not pg_is_in_recovery())
    --put your table name/mask here
    and relname ='ExtractCU_20240711'
) t
order by (toast_free_space + relation_size - (relation_size - free_space)*100/fillfactor) desc
limit 20;

-- spr,Hadoop,ExtractCU_20240711,36880064512,34 GB,5778 MB,16.43,100,5778 MB,16.43,false
-- spr,Hadoop,ExtractCU_20240711,36880064512,34 GB,5777 MB,16.42,100,5777 MB,16.42,false
-- """Hadoop"".""ExtractCU_20240711"""      ,34 GB,0 bytes,   7.4,   2617 MB,7.4,2617 MB
-- """Hadoop"".""ExtractCU_20240711"""      ,34 GB,0 bytes,   7.4,   2617 MB,7.4,2617 MB
--analyse "Hadoop"."ExtractCU_20240711";
--spr.public> analyse "Hadoop"."ExtractCU_20240711"
--[2024-08-30 17:31:37] completed in 6 s 136 ms

vacuum (FULL, VERBOSE, ANALYZE) "Hadoop"."ExtractCU_20240711";

select 4200329613 - 2744534156
1455795457


select round((a1.tuple_count::bigint / a1.pages::float)::numeric, 2) as "rows_on_pages"
       ,round((a1.tuple_len::bigint / a1.tuple_count::bigint)::numeric, 2) as "avg_len_row"
       ,round((a1.tuple_len::bigint / a1.tuple_count::bigint)::numeric, 2)*a1.pages as "free_space_upper_bound"
       ,pg_size_pretty(round((a1.tuple_len::bigint / a1.tuple_count::bigint)::numeric, 2)*a1.pages) as "free_space_upper_bound_pr"
       ,round((100*a1.free_space::bigint/a1.table_len::bigint)::numeric, 4) as "est_pers_free"
       ,round(((a1.tuple_len::bigint / a1.tuple_count::bigint)*100*a1.pages/a1.table_len::bigint)::numeric, 4) as "est_pers_free_upper_bound"
      , a1.*
from (SELECT table_len,
             tuple_count,
             tuple_len,
             tuple_percent,
             dead_tuple_count,
             dead_tuple_len,
             dead_tuple_percent,
             free_space,
             free_percent
              ,
             (select pg_relpages from pg_relpages('"Hadoop"."ExtractCU_20240711"')) as "pages"
      FROM pgstattuple('"Hadoop"."ExtractCU_20240711"')) a1;




-- SELECT 'ExtractCU_20240711'::regclass::oid;

36880064512,36069122,33674588446,91.31,0,0,0,2744534156,7.44

SELECT to_regclass('"Hadoop"."ExtractCU_20240711"');

select pg_relpages from pg_relpages('"Hadoop"."ExtractCU_20240711"')
-- 4501961

select * from pgstattuple(3814893323)