\! md "d:/temp/OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify"

\! move "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify.html" "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify"

\! move "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43.sql" "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify"

\! move "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_pg_settings.csv" "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify"

\! move "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_pg_profile_local_pg_primary.html" "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify"

\cd d:/temp/OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify

\! tar -a -c -f "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify.zip" *.*

\cd d:/PostgreSQL/SQL/Verif_recom_PG

\! rmdir /s /q "d:\\temp\\OCRM_BAN_LT_postgres_2025_03_18_22_00_43_verify"

