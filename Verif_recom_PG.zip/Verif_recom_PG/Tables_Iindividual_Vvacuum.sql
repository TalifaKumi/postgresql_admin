-- Для запуска скрипта отдельно - расскоментировать блок ниже

/*
-- ! Задать имя проекта латиницей
\set vt_project 'AFT_PROD_CAMUNDA'
-- ! Задать путь к директории для отчетов
\set vt_path 'd:/temp/'
SELECT to_char(LOCALTIMESTAMP, '_YYYY_MM_DD_HH24_MI_SS') AS vt_time;
\gset
\pset footer off
\pset null '(null)'
\timing off
*/

\set vt_tail_sql '.sql'
\pset format aligned
\set vt_out_file_txt :vt_path:vt_project:vt_time:vt_tail_sql
\o :vt_out_file_txt

\qecho 'Команды на изменения fillfactor у таблиц с fillfactor = 100 и '
\qecho 'Кол-во UPDATE с момента сбора статистики или Кол-во  модифицированных с момента последнего анализа > 50% строк таблицы'
-- Пример
-- ALTER TABLE public.act_hi_actinst SET (fillfactor = 50);

select 'ALTER TABLE ' || a1.nspname ||  '.' || a1.relname || ' SET (fillfactor = 50);'  AS "ALTER TABLE SET (fillfactor = 50)"
from (SELECT pg_class.relname
                    , pg_namespace.nspname
                    , pg_size_pretty(pg_total_relation_size(pg_class.oid))                         "total_size"
                    , pg_size_pretty(pg_relation_size(pg_class.oid))                               "main_size"
                    , CASE
                          WHEN COALESCE(last_vacuum, '1/1/1000') >
                               COALESCE(last_autovacuum, '1/1/1000') THEN
                              pg_stat_all_tables.last_vacuum
                          ELSE last_autovacuum
        END                                                                                     AS last_vacuumed
                    , CASE
                          WHEN COALESCE(last_analyze, '1/1/1000') >
                               COALESCE(last_autoanalyze, '1/1/1000') THEN
                              pg_stat_all_tables.last_analyze
                          ELSE last_autoanalyze
        END                                                                                     AS last_analyzed
                    , (pg_stat_all_tables.autovacuum_count + pg_stat_all_tables.vacuum_count)   AS "cnt_vcm"
                    , (pg_stat_all_tables.autoanalyze_count + pg_stat_all_tables.analyze_count) AS "cnt_anl"
                    , pg_stat_all_tables.n_mod_since_analyze
                    , pg_relation_size(pg_class.oid) AS "size_bt"
                    , pg_class.reloptions
                    , pg_class.reltuples
                    , pg_stat_all_tables.n_tup_upd
                    , pg_stat_all_tables.n_dead_tup
                    , pg_stat_all_tables.n_tup_ins
               FROM pg_class
                        JOIN pg_namespace
                             ON pg_class.relnamespace = pg_namespace.oid
                        JOIN pg_stat_all_tables
                             ON (
                                         pg_class.relname = pg_stat_all_tables.relname
                                     AND pg_namespace.nspname = pg_stat_all_tables.schemaname
                                 )
               WHERE pg_namespace.nspname NOT IN ('pg_toast','pg_catalog','information_schema')
) a1
    where a1.n_tup_upd > 0
        and a1.reltuples > 0
        and (round(a1.n_tup_upd*100/reltuples) > 50
        or round(a1.n_mod_since_analyze*100/reltuples) > 50)
        and size_bt > 1024*1024
        and coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]),'100')::real = 100
               ORDER BY size_bt DESC;

\qecho 'Индексы в БД, которым рекомендуется изменить fillfactor на 50 аналогично их таблицам.'

select 'ALTER INDEX ' || schemaname ||  '.' || indexname || ' SET (fillfactor = 50);'  AS "ALTER INDEX SET (fillfactor = 50)"
from (
select pg_indexes.schemaname
           , pg_indexes.indexname
           , pg_indexes.tablename
           -- , pg_class.reloptions
           , coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]),
                      '100')::real as "fillfactor"
           , pg_stat_all_indexes.idx_scan
           , pg_stat_all_indexes.idx_tup_read
           , pg_stat_all_indexes.idx_tup_fetch
      from pg_indexes
               JOIN pg_class
                    ON (
                        pg_class.relname = pg_indexes.tablename
                        --AND pg_class.relowner = pg_indexes.schemaname
                        )
               JOIN pg_stat_all_indexes ON (pg_stat_all_indexes.indexrelname = pg_indexes.indexname
          AND pg_stat_all_indexes.schemaname = pg_indexes.schemaname
          )
      where pg_indexes.tablename IN
            (select a1.relname
             from (SELECT pg_class.relname
                        , pg_namespace.nspname
                        , pg_size_pretty(pg_total_relation_size(pg_class.oid))                         "total_size"
                        , pg_size_pretty(pg_relation_size(pg_class.oid))                               "main_size"
                        , CASE
                              WHEN COALESCE(last_vacuum, '1/1/1000') >
                                   COALESCE(last_autovacuum, '1/1/1000') THEN
                                  pg_stat_all_tables.last_vacuum
                              ELSE last_autovacuum
                     END                                                                            AS last_vacuumed
                        , CASE
                              WHEN COALESCE(last_analyze, '1/1/1000') >
                                   COALESCE(last_autoanalyze, '1/1/1000') THEN
                                  pg_stat_all_tables.last_analyze
                              ELSE last_autoanalyze
                     END                                                                            AS last_analyzed
                        , (pg_stat_all_tables.autovacuum_count + pg_stat_all_tables.vacuum_count)   AS "cnt_vcm"
                        , (pg_stat_all_tables.autoanalyze_count + pg_stat_all_tables.analyze_count) AS "cnt_anl"
                        , pg_stat_all_tables.n_mod_since_analyze
                        , pg_relation_size(pg_class.oid)                                            AS "size_bt"
                        , pg_class.reloptions
                        , pg_class.reltuples
                        , pg_stat_all_tables.n_tup_upd
                        , pg_stat_all_tables.n_dead_tup
                        , pg_stat_all_tables.n_tup_ins
                   FROM pg_class
                            JOIN pg_namespace
                                 ON pg_class.relnamespace = pg_namespace.oid
                            JOIN pg_stat_all_tables
                                 ON (
                                             pg_class.relname = pg_stat_all_tables.relname
                                         AND pg_namespace.nspname = pg_stat_all_tables.schemaname
                                     )
                   WHERE pg_namespace.nspname NOT IN ('pg_toast', 'pg_catalog', 'information_schema')) a1
             where a1.n_tup_upd > 0
               and a1.reltuples > 0
               and (round(a1.n_tup_upd * 100 / reltuples) > 50
                 or round(a1.n_mod_since_analyze * 100 / reltuples) > 50)
               and size_bt > 1024 * 1024
               and coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]), '100')::real = 100
             ORDER BY size_bt DESC)
      ORDER BY pg_indexes.schemaname, pg_indexes.tablename, pg_indexes.indexname
    ) al2
;


\qecho 'Индексы в БД, которым рекомендуется изменить fillfactor со 100 на 90.'

select 'ALTER INDEX ' || schemaname ||  '.' || indexname || ' SET (fillfactor = 90);'  AS "ALTER INDEX SET (fillfactor = 90)"
from (
select pg_indexes.schemaname
           , pg_indexes.indexname
           , pg_indexes.tablename
           , pg_stat_all_tables.n_tup_upd
           , pg_class.reltuples
           , ROUND(pg_stat_all_tables.n_tup_upd*100/pg_class.reltuples):: INTEGER AS"%tup_upd"
           -- , pg_class.reloptions
           , coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]),
                      '100')::real as "fillfactor"
           , pg_stat_all_indexes.idx_scan
           , pg_stat_all_indexes.idx_tup_read
           , pg_stat_all_indexes.idx_tup_fetch
      from pg_indexes
               JOIN pg_class
                    ON (
                        pg_class.relname = pg_indexes.tablename
                        --AND pg_class.relowner = pg_indexes.schemaname
                        )
               JOIN pg_stat_all_indexes ON (pg_stat_all_indexes.indexrelname = pg_indexes.indexname
          AND pg_stat_all_indexes.schemaname = pg_indexes.schemaname)

               JOIN pg_stat_all_tables ON (pg_stat_all_tables.relname = pg_indexes.tablename
          AND pg_stat_all_tables.schemaname = pg_indexes.schemaname)

      where pg_indexes.schemaname NOT IN ('pg_catalog') -- 'pg_toast','pg_catalog','information_schema'
           AND coalesce((SELECT (regexp_matches(reloptions::text, E'.*fillfactor=(\\d+).*'))[1]), '100')::real = 100
           AND pg_stat_all_tables.n_tup_upd > 0
           AND pg_class.reltuples > 0
           AND ROUND(pg_stat_all_tables.n_tup_upd*100/pg_class.reltuples)::INTEGER > 10
           AND ROUND(pg_stat_all_tables.n_tup_upd*100/pg_class.reltuples)::INTEGER < 50

      ) al1;

-- Закрыть вывод в файл
\o




