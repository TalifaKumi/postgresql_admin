\qecho '<P><A class=awr name=151></A>'
\qecho '<H2 class=awr>PLANNER/OPTIMIZER</H2>'
\qecho '<LI class=awr>Скрипт Planner_Optimizer.sql'


--\qecho '<UL>'
--\qecho '<LI class=awr><A class=awr href="#1512">Настройки планировщика на уровне инстанса</A>'
-- \qecho '<LI class=awr><A class=awr href="#612">Активные процессы VACUUM на момент запуска отчета</A>'
-- \qecho '<LI class=awr><A class=awr href="#613">VACUUM по таблицам в порядке убывания размера</A>'
-- \qecho '<LI class=awr><A class=awr href="#614">Таблицы, кандидаты на изменение порога запуска сбора статистики autovacuum_analyze_scale_factor</A>'
--\qecho '</LI></UL>'

\qecho '<p></p>'

\qecho '<P><A class=awr name=1512></A>'
\qecho '<H3 class=awr>Настройки планировщика на уровне инстанса</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны только те настройки, которые проверялись'
\qecho '<LI class=awr>check = 0 Обязательно изменить!'
\qecho '<LI class=awr>check = 1 Соответствует рекомендациям.!'
\qecho '<LI class=awr>check = 2 Следует обратить внимание.'
\qecho '</UL>'
\qecho '<p></p>'

select name                                           "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = '8kB'
                                                               THEN to_number(setting, '999G999G999') *8* 1024
                                                           ELSE to_number(setting, '999G999G999G999') END) as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999G999G999') * 1024
       --    ELSE to_number(setting, '999G999G999G999') END "size_bt"
       ,CASE
           WHEN CASE
                    WHEN unit = '8kB' THEN to_number(setting, '999G999G999') *8* 1024
                    ELSE to_number(setting, '999G999G999G999') END <  512*1024  THEN 0
           ELSE 2 END                                 "check",
       CASE
           WHEN CASE
                    WHEN unit = '8kB' THEN to_number(setting, '999G999G999')*8 * 1024
                    ELSE to_number(setting, '999G999G999G999') END <  512*1024
               THEN '- Задан менее 512 Кб по умолчанию'
           ELSE ''
           END                                        "Comment",
       CASE
           WHEN to_number(setting, '99G999') < 0
               THEN
               ''
           ELSE
               'Задаёт минимальный объём данных индекса, подлежащий сканированию, при котором может применяться параллельное сканирование. При параллельном сканировании по индексу обычно не затрагивается весь индекс; здесь учитывается число страниц, которое по мнению планировщика будет затронуто при сканировании. Этот параметр также учитывается, когда нужно определить, может ли некоторый индекс обрабатываться при параллельной очистке. Если это значение задаётся без единиц измерения, оно считается заданным в блоках По умолчанию 512kB'
           END                                        "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'min_parallel_index_scan_size'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 100 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 100 THEN 'Задано значение по умолчанию  100'
           ELSE 'Задано значение НЕ по умолчанию  100'
           END                                  "Comment",
           'Устанавливает значение ориентира статистики по умолчанию, распространяющееся на столбцы, для которых командой ALTER TABLE SET STATISTICS не заданы отдельные ограничения. Чем больше установленное значение, тем больше времени требуется для выполнения ANALYZE, но тем выше может быть качество оценок планировщика. Значение по умолчанию — 100. Т.е. в каждой таблице будет анализоироваться 100*300 = 30 000 строк'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'default_statistics_target'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 12 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 12 THEN 'Задано значение по умолчанию 12'
           ELSE 'Задано значение НЕ по умолчанию  8'
           END                                  "Comment",
           'Задаёт минимальное число элементов во FROM, при котором для планирования запроса будет привлечён генетический оптимизатор. (Заметьте, что конструкция FULL OUTER JOIN считается одним элементом списка FROM.) Значение по умолчанию — 12. Для более простых запросов часто лучше использовать обычный планировщик, производящий полный перебор, но для запросов со множеством таблиц полный перебор займёт слишком много времени, чаще гораздо больше, чем будет потеряно из-за выбора не самого эффективного плана. Таким образом, ограничение по размеру запроса даёт удобную возможность управлять GEQO.'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'geqo_threshold'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 8 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 8 THEN 'Задано значение по умолчанию  8'
           ELSE 'Задано значение НЕ по умолчанию  8'
           END                                  "Comment",
           'Задаёт максимальное число элементов в списке FROM, до которого планировщик будет объединять вложенные запросы с внешним запросом. При меньших значениях сокращается время планирования, но план запроса может стать менее эффективным. По умолчанию это значение равно восьми.'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'from_collapse_limit'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 8 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 8 THEN 'Задано значение по умолчанию  8'
           ELSE 'Задано значение НЕ по умолчанию  8'
           END                                  "Comment",
           'Задаёт максимальное количество элементов в списке FROM, до достижения которого планировщик будет сносить в него явные конструкции JOIN (за исключением FULL JOIN). По умолчанию эта переменная имеет то же значение, что и from_collapse_limit, и это приемлемо в большинстве случаев. При значении, равном 1, предложения JOIN переставляться не будут, так что явно заданный в запросе порядок соединений определит фактический порядок, в котором будут соединяться отношения.'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'join_collapse_limit'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'auto' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'auto' THEN 'Задано значение по умолчанию'
           WHEN 'force_custom_plan' THEN 'Принудительно использовать специализированные планы'
           WHEN 'force_generic_plan' THEN 'Принудительно использовать общие планы'
           END                                  "Comment",
           'Значение auto (по умолчанию), force_custom_plan (принудительно использовать специализированные планы) и force_generic_plan (принудительно использовать общие планы). Значение этого параметра учитывается при выполнении плана, а не при построении'
                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'plan_cache_mode'
union


select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'partition' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'partition' THEN 'Задано значение по умолчанию'

           END                                  "Comment",
           'Управляет использованием планировщиком ограничений таблицы для оптимизации запросов. Допустимые значения constraint_exclusion: on (задействовать ограничения всех таблиц), off (никогда не задействовать ограничения) и partition (задействовать ограничения только для дочерних таблиц и подзапросов UNION ALL). Значение по умолчанию — partition. Оно часто помогает увеличить производительность, когда применяются традиционные деревья наследования.'
                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'constraint_exclusion'


union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'true' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'true' THEN 'Cканирование по индексу получает больший приоритет перед последовательным сканированием'
           ELSE 'Отключён (по умолчанию), в стоимости запуска учитывается только предварительная работа, выполняемая до начала сканирования.'
           END                                  "Comment",
          'Добавляет среднюю стоимость получения первого кортежа к стоимости запуска планов последовательного сканирования. При включённом параметре сканирование по индексу получает больший приоритет перед последовательным сканированием. Если он отключён (по умолчанию), в стоимости запуска учитывается только предварительная работа, выполняемая до начала сканирования.'
                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'seq_scan_startup_cost_first_row'
union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'off' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN 'Задано значение по умолчанию'
           WHEN 'off' THEN 'Отключена компиляция JIT. Рекомендованное значение'
           END                                  "Comment",
           'Определяет, может ли PG использовать компиляцию JIT, если она поддерживается. По умолчанию включёна (on) Рекомендуется off и включать по мере необходимости сначала для отдельных запросов, сессий'
                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'jit'
union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN 'Задано значение по умолчанию. Рекомендованное значение'
           WHEN 'off' THEN 'Задано значение НЕ по умолчанию. Рекомендованное значение'
           END                                  "Comment",
           'Включает или отключает в планировщике возможность отсекать секции секционированных таблиц из планов запроса. Также влияет на возможность планировщика генерировать планы запросов, позволяющие исполнителю пропускать (игнорировать) секции при выполнении запросов. По умолчанию имеет значение on'
                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'enable_partition_pruning'
union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 100000 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 100000 THEN 'Задано значение по умолчанию 100000'
           ELSE 'Задано значение НЕ по умолчанию 100000'
           END                                  "Comment",
           'Устанавливает предел стоимости запроса, при превышении которого включается JIT-компиляция, если она поддерживается. Применение JIT занимает время при планировании, но может ускорить выполнение запроса в целом. Значение -1 отключает JIT-компиляцию. Значение по умолчанию  100000.'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'jit_above_cost'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 500000 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 500000 THEN 'Задано значение по умолчанию 500000'
           ELSE 'Задано значение НЕ по умолчанию 500000'
           END                                  "Comment",
           'Устанавливает предел стоимости, при превышении которого будет допускаться встраивание функций и операторов в процессе JIT-компиляции. Встраивание занимает время при планировании, но в целом может ускорить выполнение. Присваивать этому параметру значение, меньшее чем jit_above_cost, не имеет смысла. Значение -1 отключает встраивание. Значение по умолчанию 500000.'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'jit_inline_above_cost'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN to_number(setting, '999G999G999G999') = 500000 THEN 1 ELSE 0 END "check",
       CASE WHEN to_number(setting, '999G999G999G999') = 500000 THEN 'Задано значение по умолчанию 500000'
           ELSE 'Задано значение НЕ по умолчанию 500000'
           END                                  "Comment",
           'Устанавливает предел стоимости, при превышении которого в JIT-компилированных программах может применяться дорогостоящая оптимизация. Такая оптимизация увеличивает время планирования, но в целом может ускорить выполнение. Присваивать этому параметру значение, меньшее чем jit_above_cost, не имеет смысла, а при значениях, превышающих jit_inline_above_cost, положительный эффект маловероятен. Значение -1 отключает дорогостоящие оптимизации. Значение по умолчанию  500000'
           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'jit_optimize_above_cost'

order by "check", "parameter";

\qecho <P><A class=awr href="#151">Back to PLANNER/OPTIMIZER</A> <BR><A class=awr href="#top">Back to Top</A>




