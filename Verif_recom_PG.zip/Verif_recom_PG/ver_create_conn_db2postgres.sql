
DO LANGUAGE plpgsql
$$
    DECLARE

    BEGIN

IF public.ver_if_func_exists('public','ver_create_conn_db2postgres','v.1.1') THEN
  -- RAISE NOTICE 'function ver_create_conn_db2postgres already exists';
ELSE

create OR REPLACE function public.ver_create_conn_db2postgres() returns text
/*
  ver_create_conn_db2postgres  v.1.1

  Creating a connection via dblink from the current DB to the postgres DB
  The connection name is formed by the function public.ver_get_conn_name_db2postgres()

  Возращает
  1. 'OK' - если соединение
  2. 'postgres' - текущая БД postgres
  3. 'NO_DBLINK' в текущей БД не установлено расширение DBLINK
  4. ''   - в случае проблем с созданием соединения

  select public.ver_create_conn_db2postgres('ver_con'::varchar);

 */
    SET search_path = puplic
    --language plpgsql
as
$BODY$
DECLARE
    return_conn_status  text;
    lvb_ex_dblink       bool;
    vt_connetction_name text;
    vi_port             integer;
    vt_connstr          text;
BEGIN

    return_conn_status = '';

    IF current_database() <> 'postgres' --Для отличных от postgres
    THEN

        lvb_ex_dblink := (select EXISTS(SELECT 1 FROM pg_extension ex WHERE ex.extname = 'dblink'));

        IF lvb_ex_dblink -- dblink установлено на текущей DB
        THEN

            -- Формируем имя соединения
            select public.ver_get_conn_name_db2postgres() into vt_connetction_name;

            -- Получить значение порта для коннекта
            SELECT inet_server_port() INTO vi_port;

            -- Формируем строку подключения
            if vi_port = 5432 then
                vt_connstr = 'dbname=postgres options=-csearch_path=';
            else
                vt_connstr = 'dbname=postgres options=-csearch_path=  host=/tmp/ port=' || vi_port::text;
            end if;

            -- RAISE NOTICE ', vt_connection_name: %, vt_connstr: %', vt_connetction_name, vt_connstr;

            IF public.ver_if_conn_name_exists(vt_connetction_name)
            THEN
               return_conn_status = 'OK';
            ELSE
               select public.dblink_connect(vt_connetction_name, vt_connstr) into  return_conn_status;
            END IF;

        ELSE
            return_conn_status = 'NO_DBLINK';
        END IF; -- dblink установлено на текущей DB

    ELSE
        return_conn_status = 'postgres';
    END IF;
    --Для отличных от postgres

    RETURN return_conn_status;
END
$BODY$
LANGUAGE 'plpgsql' VOLATILE;

END IF;

-- ver_get_conn_name_db2postgres  START---------------------------------------------------------

IF public.ver_if_func_exists('public','ver_get_conn_name_db2postgres','v.1.0') THEN
   -- RAISE NOTICE 'function ver_if_table_exists already exists';
 ELSE

CREATE or REPLACE FUNCTION public.ver_get_conn_name_db2postgres() returns text
    SET search_path = puplic
as
$BODY$
DECLARE
    return_conn_name    text;
BEGIN

/*
ver_get_conn_name_db2postgres v.1.0

get connection name from current database to postgres
Пример вызова
select public.ver_get_conn_name_db2postgres();
*/

    IF current_database() <> 'postgres' --Для отличных от postgres
    THEN
        return_conn_name = 'ver_con' || '_' || current_database() || '_' || pg_backend_pid() || '_2postgres';
    ELSE
        return_conn_name = null;
    END IF;

    RETURN return_conn_name;
END;

$BODY$
LANGUAGE 'plpgsql' VOLATILE;

END IF;

-- ver_get_conn_name_db2postgres  FINISH---------------------------------------------------------

END
$$;




-- select public.ver_create_conn_db2postgres('ver_con'::varchar);

-- perform public.ver_connect_to_db_postgres('con_ver_postgres'::varchar);


-- select public.dblink_disconnect('ver_con_ocrmdb_to_postgres');
-- DROP FUNCTION ver_create_conn_db2postgres;












