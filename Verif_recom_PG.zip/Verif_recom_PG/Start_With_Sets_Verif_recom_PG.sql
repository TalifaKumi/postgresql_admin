-- Задать имя проекта.
   -- LD - Нагрузочная БД
   -- PROD - промышленная БД

\set vt_project 'OCRM_BANNER_LD'

-- Задать путь к директории, в которой будут формироваться отчеты
-- !!! Директория должна сущестовать и иметь права на создание файлов
\set vt_path_reports 'd:/temp/'

-- Конторольный вывод, если нужен
-- \qecho 'vt_project:' :vt_project
-- \qecho 'vt_path_reports' :vt_path_reports

-- Перейти в директорию со скриптами, если скрипт запущен из другой диретории
-- \cd d:/PostgreSQL/SQL/Verif_recom_PG

-- Запустить головной  файл
\i Verif_recom_PG.sql