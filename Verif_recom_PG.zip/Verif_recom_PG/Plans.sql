\qecho '<P><A class=awr name=171></A>'
\qecho '<H2 class=awr>Планы выполнения запросов</H2>'

\qecho '<A class=awr_ital>Скрипт Plans.sql</A>'
\qecho '<p></p>'

\set h_b 'https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1677693390'
--\qecho :h_b

\qecho '<p></p>'
\qecho '<P><A class=awr name=1711></A>'
\qecho '<H5 class=awr>Текущие настройки расширения pg_store_plans</H5>'
\qecho '<p></p>'

SELECT *
from pg_catalog.pg_settings
WHERE NAME LIKE '%pg_store_plans%'
ORDER BY 1;

\if :current_db_postgres

--DROP TABLE IF EXISTS tmp_store_plans_info;
CREATE TEMPORARY TABLE tmp_store_plans_info AS SELECT * FROM pg_store_plans_info;
--select * from tmp_store_plans_info;


-- DROP TABLE IF EXISTS tmp_store_plans;
CREATE TEMPORARY TABLE tmp_store_plans AS SELECT * from public.pg_store_plans;
-- select * from tmp_store_plans;

\else
-- SELECT dblink_get_connections();
DO
$do$
DECLARE
BEGIN

IF (SELECT POSITION('con_ver_postgres' in (SELECT dblink_get_connections())::text )) < 0
  THEN
SELECT dblink_connect('con_ver_postgres', 'dbname=postgres options=-csearch_path=');
END IF;

END
$do$;

-- DROP TABLE IF EXISTS tmp_store_plans_info;
CREATE TEMPORARY TABLE tmp_store_plans_info AS SELECT * FROM dblink('con_ver_postgres','select dealloc, stats_reset from public.pg_store_plans_info')
AS t1(dealloc bigint, stats_reset timestamp with time zone);

-- select * from tmp_store_plans_info;

-- DROP TABLE IF EXISTS tmp_store_plans;
CREATE TEMPORARY TABLE tmp_store_plans
 AS SELECT *
          FROM dblink('con_ver_postgres',
                      'select userid, dbid, queryid, planid, plan, calls, total_time, min_time, max_time, mean_time, stddev_time, rows
                          ,shared_blks_hit, shared_blks_read, shared_blks_dirtied, shared_blks_written, local_blks_hit
             ,local_blks_read, local_blks_dirtied, local_blks_written, temp_blks_read, temp_blks_written, blk_read_time
             ,blk_write_time, temp_blk_read_time, temp_blk_write_time, first_call, last_call
      from public.pg_store_plans')
    AS t1(userid oid, dbid oid, queryid bigint, planid bigint, plan text, calls bigint, total_time double precision
             ,min_time double precision , max_time double precision, mean_time double precision, stddev_time double precision
             ,rows bigint
             ,shared_blks_hit bigint, shared_blks_read bigint, shared_blks_dirtied bigint, shared_blks_written bigint, local_blks_hit bigint
             ,local_blks_read bigint, local_blks_dirtied bigint, local_blks_written bigint , temp_blks_read bigint, temp_blks_written bigint
             ,blk_read_time double precision
             ,blk_write_time double precision, temp_blk_read_time double precision, temp_blk_write_time double precision
            ,first_call timestamp with time zone, last_call timestamp with time zone
           );

-- SELECT * FROM tmp_store_plans;

--SELECT dblink_disconnect('con_ver_postgres');

\endif


\qecho '<p></p>'

select * from tmp_store_plans_info;

/*
pg_store_plans.log_buffers = on
pg_store_plans.log_analyze = on
pg_store_plans.log_verbose = on
pg_store_plans.plan_format = 'raw'
pg_store_plans.plan_format = 'json'

select pi.*, (select count(*) from pg_store_plans) as "Количество планов" from pg_store_plans_info pi;
*/


\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H3 class=awr>Планы выполнения на момент подготовки отчета</H3>'
\qecho '<p></p>'

--\qecho '<p></p>'
--select count(distinct p.planid) as "Всего уникальных планов" from pg_store_plans p;
--\qecho '<p></p>'

WITH pl as
             (SELECT * from tmp_store_plans)

select sum(cnt_all_plans)                                             as "Всего планов"
     , sum(cnt_Seq_Scan_plans)                                        as "С Seq Scan"
     , sum(cnt_Seq_Scan_pg_catalog_plans)                             as "Seq Scan по системным"
     , (sum(cnt_Seq_Scan_plans) - sum(cnt_Seq_Scan_pg_catalog_plans)) as "Seq Scan исключая системные"
from (select (select count(*) from pl) as cnt_all_plans,
             null                      as cnt_Seq_Scan_plans,
             null::bigint              as cnt_Seq_Scan_pg_catalog_plans
      union
      select null                                                             as cnt_all_plans,
             (select count(*) from pl where POSITION('Seq Scan' IN plan) > 0) as cnt_Seq_Scan_plans,
             null::bigint                                                     as cnt_Seq_Scan_pg_catalog_plans
      union
      select null                                                   as cnt_all_plans,
             null                                                   as cnt_Seq_Scan_plans,
             (select count(*)
              from pl
              where (POSITION('Seq Scan on pg_catalog' IN plan) > 0
                     OR POSITION('Seq Scan on profile' IN plan) > 0
                     OR POSITION('Function Scan on tmp_store_plans' IN plan) > 0
                     OR POSITION('Seq Scan on cron.job' IN plan) > 0)
              ) as cnt_Seq_Scan_pg_catalog_plans) a1;

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Планы с Seq Scan, исключая Seq Scan по системным представлениям</H5>'
\qecho '<p></p>'
\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

WITH pl as
             (SELECT db.datname as db
     , rl.rolname as role
     , p.queryid
     , p.planid
     , p.calls, p.total_time, p.mean_time
     , p.plan
     , regexp_replace(trim(s.query), '\s+', ' ', 'g')        AS "Query_text"
                 from tmp_store_plans p
                  LEFT JOIN pg_stat_statements s USING (queryid)
                  JOIN pg_roles rl ON (p.userid = rl.oid)
                  JOIN pg_database db ON (p.dbid = db.oid)     )

select *
from pl
where POSITION('Seq Scan' IN plan) > 0
EXCEPT

select *from pl
where (  POSITION('Seq Scan on pg_catalog' IN plan) > 0
      OR POSITION('Seq Scan on profile' IN plan) > 0
      OR POSITION('Function Scan on public.pg_store_plans' IN plan) > 0
      OR POSITION('Seq Scan on cron.job' IN plan) > 0
    );
\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>ВСЕ планы запросов, захваченные на момент создания отчета</H5>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Упорядоченны по db, role, queryid'
\qecho '</UL>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

select db.datname as db
     , rl.rolname as role
     , p.queryid
     , p.planid
     , p.plan
     , regexp_replace(trim(s.query), '\s+', ' ', 'g')        AS "Query_text"
from tmp_store_plans p
         LEFT JOIN pg_stat_statements s USING (queryid)
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
where 1 = 1
  and p.planid in (select distinct p1.planid from tmp_store_plans p1)
  --and p.queryid = '-7761119878818660474'
order by db.datname, rl.rolname, p.queryid;

\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Количество планов на запрос</H5>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

with a1 as
         (select p.queryid, p.dbid
               , count(planid) as cnt_plan
               , max(plan)  as plan
               , max(db.datname) as db
          from tmp_store_plans p
                    JOIN pg_database db ON (p.dbid = db.oid)
          group by p.queryid, p.dbid
          -- order by 3 desc
          )

select a1.queryid, a1.db, a1.cnt_plan, a1.plan
     , regexp_replace(trim(pss.query), '\s+', ' ', 'g') AS "Query_text"

from a1
         left join pg_stat_statements pss on a1.queryid = pss.queryid and a1.dbid = pss.dbid
order by cnt_plan desc;

\qecho </details>

/*
SELECT sum(calls)                                                      AS total_calls
     , max(queryid)                                                    as "queryid"
     , max(to_hex(queryid))                                            AS hexqueryid
     , max(left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                    AS "Query_text"
FROM pg_stat_statements
where queryid = '-7761119878818660474'
GROUP BY query
ORDER BY sum(calls) DESC
LIMIT 10;

select * from pg_store_plans p

select db.datname as db
     , rl.rolname as role
     , p.queryid
     , p.planid
     , p.plan
     -- ,''  AS "Query_text"
from pg_store_plans p
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
where 1 = 1
  and p.planid in (select distinct p1.planid from pg_store_plans p1)
  and p.plan like '%Seq Scan on r_banner_status%'   --'%Seq Scan%'
order by db.datname, rl.rolname, p.queryid, p.plan
;



(
select p.queryid, p.planid
       ,rl.rolname                               as role
       ,db.datname                               as db
       , p.plan
       -- ,''  AS "Query_text"
from pg_store_plans p
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
  where 1=1
        -- db.datname = current_database()
        and round((p.total_time / p.calls)::numeric) >1 LIMIT 20
)
union
(SELECT queryid
      , p.planid
      , rl.rolname as role
      , db.datname as db
      , p.plan
      -- ,s.query AS "Query_text"
 FROM pg_stat_statements s
          JOIN pg_store_plans p USING (queryid)
          JOIN pg_roles rl ON (p.userid = rl.oid)
          JOIN pg_database db ON (p.dbid = db.oid)
 where 1=1
   -- db.datname = current_database()
-- WHERE p.calls < s.calls
 ORDER BY round((p.total_time / p.calls)::numeric, 2) DESC
 LIMIT 20)
union
(SELECT max(s.queryid)  as queryid
      , max(p.planid)   as planid
      , max(rl.rolname) as role
      , max(db.datname) as db
      , p.plan
      -- ,s.query AS "Query_text"
 FROM pg_stat_statements s
          JOIN pg_store_plans p USING (queryid)
          JOIN pg_roles rl ON (p.userid = rl.oid)
          JOIN pg_database db ON (p.dbid = db.oid)
-- WHERE p.calls < s.calls
 where 1= 1
   --db.datname = current_database()
 group by s.query, p.plan
 ORDER BY round((sum(p.total_time) / sum(p.calls))::numeric, 2) DESC
 LIMIT 20);
*/



/*

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Только одиночные планы с наибольшим временем на вызов</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>в порядке убывания time/call_ms, первые 20'
\qecho '</UL>'
\qecho '<p></p>'


select round((p.total_time / p.calls)::numeric, 2)                  as "time/call_ms"
     , p.queryid
     , to_hex(queryid)                                              AS hexqueryid
     , (left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , p.planid
     , md5(regexp_replace(p.plan, '\d', '1', 'g')::text)            as phv
     , rl.rolname                                                   as role
     , db.datname                                                   as db
     --, p.plan
     , p.calls
     , round(p.total_time::numeric, 2)                              as total_t
     , round(p.min_time::numeric, 2)                                as min_t
     , round(p.max_time::numeric, 2)                                as max_t
     , round(p.mean_time::numeric, 2)                               as mean_t
     , round(p.stddev_time::numeric, 2)                             as stddev_t
     , p.rows
     , p.shared_blks_hit
     , shared_blks_read
     , shared_blks_dirtied
     , shared_blks_written
     , local_blks_hit
     , local_blks_read
     , local_blks_dirtied
     , local_blks_written
     , temp_blks_read
     , temp_blks_written
     , round(blk_read_time::numeric, 2)                             as blk_read_t
     , blk_write_time                                               as blk_write_t
     , temp_blk_read_time                                           as tmp_blk_read_t
     , temp_blk_write_time                                          as tmp_blk_write_t
     , to_char(first_call, 'YYYY.MM.DD HH24:MI:SS')                 as first_call
     , to_char(last_call, 'YYYY.MM.DD HH24:MI:SS')                  as last_call
     , to_char(last_call - first_call, 'YYYY.MM.DD HH24:MI:SS')     as live
from pg_store_plans p
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
where 1 = 1
  and db.datname not in ('postgres')
  -- db.datname = current_database()
  -- and round((p.total_time / p.calls)::numeric) >1
order by "time/call_ms" desc
limit 20;
*/

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Одиночные планы с наибольшим временем на вызов</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>в порядке убывания time/call_ms, первые 20'
\qecho '</UL>'
\qecho '<p></p>'
\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

SELECT round((p.total_time / p.calls)::numeric, 2)                        as "time/call_ms"
     , s.queryid
     , to_hex(s.queryid)                                                  AS hexqueryid
     , (left(md5(p.userid::text || p.dbid::text || s.queryid::text), 10)) AS hashed_ids
     , p.planid
     , md5(regexp_replace(p.plan, '\d', '1', 'g')::text)                  as phv
     , rl.rolname                                                         as role
     , db.datname                                                         as db
     , p.plan
     , regexp_replace(trim(s.query), '\s+', ' ', 'g')                     AS "Query_text"
     , p.calls                                                            as "plan calls"
     , s.calls                                                            as "stmt calls"
     -- ,p.total_time / p.calls as "time/call"
     , p.first_call
     , p.last_call
FROM  tmp_store_plans p
         LEFT JOIN  pg_stat_statements s ON p.queryid = s.queryid  and p.dbid = s.dbid
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
where 1 = 1
  and db.datname not in ('postgres')
--  db.datname = current_database()
-- WHERE p.calls < s.calls
ORDER BY "time/call_ms" DESC
LIMIT 20;

\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Планы сгруппированные по queryid с наибольшим средним временем на вызов в ms </H5>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>В порядке убывания time/call_ms, первые 20'
\qecho '<LI class=awr>Для каждого запроса показан один из возможных планов'
\qecho '</UL>'
\qecho '<p></p>'
\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

SELECT round((sum(p.total_time) / sum(p.calls))::numeric, 2) as "time/call_ms"
     , s.queryid                                        as queryid
     , max(p.planid)                                         as planid
     , max(rl.rolname)                                       as role
     , max(db.datname)                                       as db
     , sum(p.calls)                                          as plan_calls
     , sum(s.calls)                                          as stmt_calls
     -- ,s.query
     , max(regexp_replace(trim(s.query), '\s+', ' ', 'g'))   AS "Query_text"
     , max(p.plan)                                           AS plan
     , min(p.first_call)                                     as first_call
     , max(p.last_call)                                      as last_call
FROM  tmp_store_plans p
         LEFT JOIN pg_stat_statements s USING (queryid)
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
WHERE 1 = 1
  and db.datname not in ('postgres')
  --p.calls < s.calls
--         where db.datname = current_database()
group by s.queryid
ORDER BY "time/call_ms" DESC
LIMIT 20;

\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Планы сгруппированные по queryid и planid с наибольшим временем на вызов </H5>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>В порядке убывания time/call_ms, первые 20'
\qecho '<LI class=awr>Для каждого запроса показан один из возможных планов'
\qecho '</UL>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

SELECT round((sum(p.total_time) / sum(p.calls))::numeric, 2) as "time/call_ms"
     , s.queryid                                             as queryid
     , max(p.planid)                                         as planid
     , max(rl.rolname)                                       as role
     , max(db.datname)                                       as db
     , sum(p.calls)                                          as plan_calls
     , sum(s.calls)                                          as stmt_calls
     -- ,s.query
     , max(regexp_replace(trim(s.query), '\s+', ' ', 'g'))   AS "Query_text"
     , max(p.plan)                                           as plan
     , min(p.first_call)                                     as first_call
     , max(p.last_call)                                      as last_call
FROM tmp_store_plans p
         left join pg_stat_statements s ON (p.queryid=s.queryid and p.dbid = s.dbid)
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)
WHERE 1 = 1
  and db.datname not in ('postgres')
  --p.calls < s.calls
--         where db.datname = current_database()
group by s.queryid, p.plan
ORDER BY "time/call_ms" DESC
LIMIT 20;

\qecho </details>

/*
\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Запросы с разными агрегированными планами</H5>'
\qecho '<p></p>'

select *
from (select queryid, planid, role, db, count(*) as cnt
      from (SELECT max(s.queryid)  as queryid
                 , max(p.planid)   as planid
                 , max(rl.rolname) as role
                 , max(db.datname) as db
            FROM pg_stat_statements s
                     JOIN pg_store_plans p USING (queryid)
                     JOIN pg_roles rl ON (p.userid = rl.oid)
                     JOIN pg_database db ON (p.dbid = db.oid)
            where 1 = 1
              and db.datname not in ('postgres')
               -- db.datname = current_database()
           ) a1
      group by queryid, planid, role, db) a2
where cnt > 1
ORDER BY cnt desc;

select *
from (select queryid, planid, count(*) as cnt
      from (SELECT max(s.queryid)  as queryid
                 , max(p.planid)   as planid
                 , max(rl.rolname) as role
                 , max(db.datname) as db
            FROM pg_stat_statements s
                     JOIN pg_store_plans p USING (queryid)
                     JOIN pg_roles rl ON (p.userid = rl.oid)
                     JOIN pg_database db ON (p.dbid = db.oid)
            where 1 = 1
              and db.datname not in ('postgres')
               -- db.datname = current_database()
           ) a1
      group by queryid, planid) a1
where cnt > 1
ORDER BY cnt desc;
*/

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>20 самых свежих планов на момент создания отчета </H5>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>\В порядке убывания first_call, первые 20'
\qecho '</UL>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

select to_char(first_call, 'YYYY.MM.DD HH24:MI:SS')                       as first_call
     --, to_char(last_call, 'YYYY.MM.DD HH24:MI:SS')                        as last_call
     --, to_char(last_call - first_call, 'YYYY.MM.DD HH24:MI:SS')           as life_t
     , round((p.total_time / p.calls)::numeric, 2)                        as "time/call_ms"
     , p.calls
     , p.queryid
     , to_hex(p.queryid)                                                  AS hexqueryid
     , (left(md5(p.userid::text || p.dbid::text || p.queryid::text), 10)) AS hashed_ids
     , p.planid
     , md5(regexp_replace(p.plan, '\d', '1', 'g')::text)                  as phv
     , rl.rolname                                                         as role
     , db.datname                                                         as db
     , regexp_replace(trim(s.query), '\s+', ' ', 'g')        AS "Query_text"
     , p.plan
     , round(p.total_time::numeric, 2)                                    as total_t
     , round(p.min_time::numeric, 2)                                      as min_t
     , round(p.max_time::numeric, 2)                                      as max_t
     , round(p.mean_time::numeric, 2)                                     as mean_t
     , round(p.stddev_time::numeric, 2)                                   as stddev_t
     , p.rows
     , p.shared_blks_hit
     , p.shared_blks_read
     , p.shared_blks_dirtied
     , p.shared_blks_written
     , p.local_blks_hit
     , p.local_blks_read
     , p.local_blks_dirtied
     , p.local_blks_written
     , p.temp_blks_read
     , p.temp_blks_written
     , round(p.blk_read_time::numeric, 2)                                   as blk_read_t
     , p.blk_write_time                                                     as blk_write_t
     , p.temp_blk_read_time                                                 as tmp_blk_read_t
     , p.temp_blk_write_time                                                as tmp_blk_write_t
from tmp_store_plans p
         JOIN pg_stat_statements s USING (queryid)
         JOIN pg_roles rl ON (p.userid = rl.oid)
         JOIN pg_database db ON (p.dbid = db.oid)

where 1 = 1
  --db.datname = current_database()
  and round((p.total_time / p.calls)::numeric) > 1
  and lower(rl.rolname) not in ('u_m01ue')
order by first_call desc
limit 20;

\qecho </details>

\qecho <P><A class=awr href="#171">Back to Планы выполнения запросов</A> <BR><A class=awr href="#top">Back to Top</A>


