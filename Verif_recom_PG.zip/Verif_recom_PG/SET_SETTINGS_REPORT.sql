\encoding 'UTF-8'
\pset null '(null)'

\set vt_scripts_ver '2025-03-19'


-- HTML Tutorial
-- https://www.w3schools.com/html/html_formatting.asp

select current_setting('server_version_num')::integer < 130000::integer as ver_less_13;
\gset
--\qecho ':ver_less_13' :ver_less_13

select current_setting('server_version_num')::integer >= 140000::integer  as ver_14;
\gset

select current_setting('server_version_num')::integer >= 150000::integer  as ver_15;
\gset
--\qecho ':ver_15' :ver_15

select current_setting('server_version_num')::integer >= 160000::integer  as ver_16;
\gset

select current_setting('server_version_num')::integer >= 170000::integer  as ver_17;
\gset

SELECT current_user;

SELECT pg_read_file(current_setting('data_directory') || '/postmaster.pid');

-- SELECT pg_ls_dir('d:/PostgreSQL/SQL/Verif_recom_PG');

-- SELECT pg_read_file('/project_name.txt');
-- SELECT pg_read_file('/report_path.txt');

-- \set vt_get_project 'P01'
\set vt_enpty_string '''^'''
\set vt_single_quotation_mark ''''
\set vt_double_quotes '"'

\qecho 'vt_double_quotes:' :vt_double_quotes

-- \qecho 'vt_get_project:' :vt_get_project
-- \qecho 'vt_enpty_string:' :vt_enpty_string

\qecho 'vt_project:' :vt_project

-- SELECT :vt_project:vt_enpty_string='^' AS vt_no_set_project;
--SELECT {?:vt_project} AS vt_no_set_project;

--\gset

--\qecho 'vt_no_set_project:' :vt_no_set_project
\qecho :{?vt_project}

--\if :vt_no_set_project
\if :{?vt_project}
\else
-- \qecho 'Задайте имя проекта латинскими'
\prompt 'Enter the project name in Latin, for example: SFA_PDB_PROD in SINGLE QUOTE :' vt_get_project

\qecho 'vt_get_project:' :vt_get_project
\qecho :'vt_get_project'


--\qecho 'vt_get_project' :vt_get_project
--SELECT ':vt_get_project';
--SELECT char_length(:vt_get_project)=0;

-- SELECT char_length(:vt_get_project)=0 AS vt_no_set_project;

--SELECT ''':vt_get_project''' AS vt_get_project_1;
--\gset
--\qecho 'vt_get_project_1:' :vt_get_project_1

SELECT :vt_get_project:vt_enpty_string='^' AS vt_no_get_project;
\gset

-- \qecho 'vt_no_get_project:' :vt_no_set_project

\if :vt_no_get_project
 \set vt_project 'PROJECT'
\else
 SELECT :vt_get_project AS vt_project;
 \gset
\endif

\qecho 'vt_project:' :vt_project

\endif
-- Окончание по if :{?vt_project}

\set vt_project_mark :vt_single_quotation_mark:vt_project:vt_single_quotation_mark


\if :{?vt_path_reports}
\else
\qecho 'Set the full path to the existing directory for the reports in Latin'
\prompt 'For example(default): d:/temp/ in SINGLE QUOTE :' vt_get_path

\qecho 'vt_get_path:' :vt_get_path

SELECT :vt_get_path:vt_enpty_string='^' AS vt_no_set_path
\gset

\qecho 'vc_no_set_path:' :vt_no_set_path

\if :vt_no_set_path
 \set vt_path_reports 'd:/temp/'
 -- \set vt_path_reports 'd:\temp\'
\else
SELECT :vt_get_path AS vt_path_reports;
 \gset
\endif
\qecho 'vt_path_reports:' :vt_path_reports
\endif
-- Окончание по if :{?vt_path_reports}

\set vt_tail_html '.html'
\set vt_tail_csv '.csv'
\set vt_tail_zip '.zip'
\set vt_underscore '_'


\set vt_verify '_verify'
\set vt_pg_settings '_pg_settings'


SET TIME ZONE +3 ;
SELECT to_char(LOCALTIMESTAMP, '_YYYY_MM_DD_HH24_MI_SS') AS vt_time;
\gset
-- \qecho 'Время:' :vt_time
SELECT '_' AS vt_;
\gset

select current_database() AS vt_current_db;
\gset

select REPLACE(current_database(),'.','_') AS vt_current_db_file;
\gset

select EXISTS (SELECT  1  FROM pg_extension ex
WHERE ex.extname =  'dblink') AS set_dblink;
\gset

\if :current_db_postgres
\else
\if :set_dblink

-- Устанавливаем соединение с БД postgres

-- select public.ver_if_conn_name_exists(ver_get_conn_name_db2postgres()); Проверка, что точно такое соединение открыто есть в

select public.ver_create_conn_db2postgres() AS conn_status_db2postgres;
\gset
\qecho 'conn_status_db2postgres: ' :conn_status_db2postgres

\else
-- \qecho '<P><A class=awr name=171></A>'
\qecho '<H2 class=awr>Расширение не установлено в текущей БД</H2>'
\qecho '<p></p>'
\endif
\endif

-- Получение  признака установки расширения pg_store_plans
\if :current_db_postgres
select EXISTS (SELECT  1  FROM pg_extension ex
WHERE ex.extname =  'pg_store_plans') AS set_pg_store_plans;
\gset
\else

select EXISTS (SELECT  1  FROM (SELECT *
                                 FROM dblink(public.ver_get_conn_name_db2postgres(),
-- FROM dblink('ver_con_bookkeeping_db_3873242_2postgres',
                                            'select oid oid, extname, extowner, extnamespace, extrelocatable, extversion, extconfig, extcondition from pg_extension')
                                         AS t2(oid oid, extname name, extowner oid, extnamespace oid,
                                               extrelocatable boolean, extversion text, extconfig oid[],
                                               extcondition text[])) a1
WHERE extname =  'pg_store_plans') AS set_pg_store_plans;

\gset

\qecho  'set_pg_store_plans: ' :set_pg_store_plans
\endif

select EXISTS (SELECT  1  FROM pg_extension ex
WHERE ex.extname =  'pg_hint_plan') AS set_pg_hint_plan;
\gset

select EXISTS (SELECT  1  FROM pg_extension ex
WHERE ex.extname =  'pg_wait_sampling') AS set_pg_wait_sampling;
\gset

select EXISTS (SELECT  1  FROM pg_extension ex
WHERE ex.extname =  'pg_buffercache') AS set_pg_buffercache ;
\gset

select EXISTS (SELECT  1  FROM pg_extension ex
WHERE ex.extname =  'system_stats') AS set_system_stats;
\gset


\pset format html
-- включают или отключают вывод результирующей строки с количеством выбранных записей (n строк)
\pset footer off
--Отключает вывод имён столбцов и результирующей строки с количеством выбранных записей
\pset tuples_only off

-- Формирование полного названия головного файла-отчета формата html
\set vt_out_file :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_verify:vt_tail_html
\o :vt_out_file

\timing off

\qecho '<HTML lang=en><HEAD><TITLE>':vt_project:vt_:vt_current_db:vt_time' PG Report</TITLE>'
\qecho '<STYLE type=text/css>'
\qecho 'body.awr {font:bold 10pt Arial,Helvetica,Geneva,sans-serif;color:black; background:White;}'
\qecho 'pre.awr  {font:8pt Courier;color:black; background:White;}'
\qecho 'th {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:White; background:#0066CC;padding-left:4px; padding-right:4px;padding-bottom:2px}'
\qecho 'h1.awr   {font:bold 20pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;border-bottom:1px solid #cccc99;margin-top:0pt; margin-bottom:0pt;padding:0px 0px 0px 0px;}'
\qecho 'h2.awr   {font:bold 18pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}'
\qecho 'h3.awr {font:bold 16pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}'
\qecho 'h4.awr {font:bold 14pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}'
\qecho 'h5.awr {font:bold 12pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}'
\qecho 'li.awr {font: 8pt Arial,Helvetica,Geneva,sans-serif; color:black; background:White;}'
\qecho 'th.awrnobg {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:black; background:White;padding-left:4px; padding-right:4px;padding-bottom:2px}'
\qecho 'th.awrbg {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:White; background:#0066CC;padding-left:4px; padding-right:4px;padding-bottom:2px}'
\qecho 'td    {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:#FFFFCC; vertical-align:top;}'
\qecho 'td.awrnc {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:White;vertical-align:top;}'
\qecho 'td.awrc    {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:#FFFFCC; vertical-align:top;}'
\qecho 'a.awr {font:bold 8pt Arial,Helvetica,sans-serif;color:#663300; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}'
\qecho 'a.awr_ital {font:italic 8pt Arial,Helvetica,sans-serif;color:#663300; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}'
\qecho 'a.awr_href {font:italic 8pt Arial,Helvetica,sans-serif;color:blue; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}'


\qecho 'table.tdiff {  border_collapse: collapse; }'
\qecho '.hidden   {position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden;}'
\qecho '.pad   {margin-left:17px;}'
\qecho '.doublepad {margin-left:34px;}'

\qecho '</STYLE>'
\qecho '</HEAD>'

\qecho '<BODY class=awr><H1 class=awr>Отчет по проверке рекомендаций PosgreSQL для КОНКРЕТНОЙ БД </H1>'
\qecho '<p></p>'

\qecho '<A class=awr_ital>Корневой скрипт Verif_recom_PG.sql</A>'
\qecho '<p></p>'
\qecho '<A class=awr_ital>Скрипт SET_SETTINGS_REPORT.sql</A>'
\qecho '<p></p>'

\pset border 2
\pset tableattr class=tdiff
-- \pset tableattr bgcolor="#0066CC"
--\pset TH class=awrbg scope=col

SELECT :'vt_project'  as "Проект",
       :'vt_current_db' as "База Данных",
       to_char(LOCALTIMESTAMP, 'YYYY-MM-DD_HH24:MI:SS') as "Дата подготовки",
       :'vt_out_file'  as "Файл отчета",
       :'vt_scripts_ver' as "Версия скрипов от" ;

\qecho '<p></p>'

\qecho <p><a class=awr_ital>Параметры и настройки задаются в : </a>
\qecho <a class=awr_href href="https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=609228333">Стандарт по вводу в эксплуатацию БД PostgreSQL</a>
\qecho <a class=awr_ital>Контролируются : </a>
\qecho <a class=awr_href href="https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1067554531">Стандарт мониторинга PostgreSQL</a></p>

\qecho <p><a class=awr_ital>Скрипты и инструкции по запуску можно скачать с : </a>
\qecho <a class=awr_href href="https://confluence.moscow.alfaintra.net/pages/viewpage.action?pageId=1335023310">Скрипты проверки рекомендаций PostgreSQL</a>
\qecho <a class=awr_ital> Замечания и пожелания по скриптам можно направлять : </a>
\qecho <a class=awr_href href="http://alfa/profile/Pages/view.aspx#/info?accountname=MOSCOW\U_M01UE">Шумеев Сергей Дмитриевич, Отдел оптимизации производительности </a></p>

\qecho <P><A class=awr name=top></A>
\qecho <H2 class=awr>Основные разделы отчета </H2>

\qecho  <UL>
-- \qecho  <LI class=awr><A class=awr href="#99999">Report Summary</A>
-- \qecho  <LI class=awr><A class=awr href="#11">Параметры сессии, в которой выполнялся скрипт</A>
\qecho <LI class=awr><A class=awr href="#21">Версия, Хост, Инстанс, Базы Данных</A>
\qecho  <LI class=awr><A class=awr href="#31">Расширения, Дополнительные модули</A>
\qecho  <LI class=awr><A class=awr href="#41">Настройки инстанса, сравнение, история изменений</A>
\qecho  <LI class=awr><A class=awr href="#51">Настройки логирования в журнал</A>

\qecho  <LI class=awr><A class=awr href="#61">Информация по соединениям</A>
\qecho  <LI class=awr><A class=awr href="#81">Трансакции</A>
\qecho  <LI class=awr><A class=awr href="#141">Блокировки</A>

\qecho  <LI class=awr><A class=awr href="#601">Разделяемая память</A>
\qecho  <LI class=awr><A class=awr href="#71">Временные файлы, таблицы</A>
\qecho <LI class=awr><A class=awr href="#161">Запросы, функции</A>
\qecho <LI class=awr><A class=awr href="#171">Планы выполнения запросов</A>

-- Эти пункты только для БД postgres
\if :current_db_postgres
\qecho <LI class=awr><A class=awr href="#181">События ожидания</A>
\qecho <LI class=awr><A class=awr href="#191">Системная статистика</A>
\endif
-- Окончание по :current_db_postgres

\qecho <LI class=awr><A class=awr href="#91">WAL</A>
\qecho <LI class=awr><A class=awr href="#101">VACUUM, ANALYZE, Заморозка</A>
\qecho <LI class=awr><A class=awr href="#151">PLANNER/OPTIMIZER</A>
\qecho <LI class=awr><A class=awr href="#131">BLOAT</A>

-- -- Эти пункты для всех БД кроме postgres
\if :current_db_postgres
\else
\qecho <LI class=awr><A class=awr href="#111">Таблицы. Партиции. Последовательности.</A>
\qecho <LI class=awr><A class=awr href="#121">Индексы</A>
\endif

\qecho '</UL>'

-- \qecho <LI class=awr><A class=awr href="#501">Запросы, на которые следует обратить внимание.</A>
-- \qecho </LI></UL>
