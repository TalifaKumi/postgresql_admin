-- Получить отчет pg_profile между двумя последними снимками

-- Устанавливаем соединение с БД postgres
select public.ver_create_conn_db2postgres() AS conn_status_db2postgres;

\set vt_pg_profile '_pg_profile'

-- \pset format aligned
\pset format unaligned
-- включают или отключают вывод результирующей строки с количеством выбранных записей (n строк)
\pset footer off
--Отключает вывод имён столбцов и результирующей строки с количеством выбранных записей
\pset tuples_only

\set vt_out_file_profile :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_pg_profile:vt_tail_html
\o :vt_out_file_profile

SELECT a1
            FROM dblink(public.ver_get_conn_name_db2postgres(), 'SELECT profile.get_report((SELECT t.server_id
                           FROM profile.samples t
                                    join profile.servers s on t.server_id = s.server_id
                           ORDER BY sample_time DESC
                           LIMIT 1), (SELECT t.sample_id - 1
                                      FROM profile.samples t
                                               join profile.servers s on t.server_id = s.server_id
                                      ORDER BY sample_time DESC
                                      LIMIT 1), (SELECT t.sample_id
                                                 FROM profile.samples t
                                                          join profile.servers s on t.server_id = s.server_id
                                                 ORDER BY sample_time DESC
                                                 LIMIT 1)) as a1') AS t(a1 text);


