\qecho '<P><A class=awr name=71></A>'
\qecho '<H2 class=awr>Временные файлы, таблицы</H2>'

\qecho '<A class=awr_ital>Скрипт TMP_Files.sql</A>'
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=710></A>'
\qecho '<H3 class=awr>Настройки инстанса по временным файлам.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны только те настройки, которые проверялись'
\qecho '<LI class=awr>check = 0 Обязательно изменить!'
\qecho '<LI class=awr>check = 1 Соответствует рекомендациям.!'
\qecho '<LI class=awr>check = 2 Следует обратить внимание.'
\qecho '</UL>'
\qecho '<p></p>'

select name                                     "parameter",
       setting                                  "setting",
       CASE WHEN char_length(setting)=0 THEN 0 ELSE 1 END "check",
       CASE WHEN char_length(setting)=0 THEN '- Задать отдельные табличные пространства для временных файлов'
           ELSE ' + Задано отдельное табличное пространство для временных файлов'  END "Comment",
           'Указывает на размещение временных таблиц и индексов, а также файлов, создаваемых, ' ||
           'при операциях сортировки больших наборов данных. Предпочтительнее, в качестве значения этого параметра, ' ||
           'указывать не одно имя, а список из нескольких табличных пространств.'
                                 "Рекомендации"
        ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'temp_tablespaces'

union

select name                                                                                                       "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = 'kB'
                                                               THEN to_number(setting, '999999999999') * 1024
                                                           ELSE to_number(setting, '999999999999') * 1024 END) as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
       --    ELSE to_number(setting, '999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END > 0 THEN 1
           ELSE 2 END                                                                                             "check",
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END > 0
               THEN ' Задано логирование информации о временных файлах более заданного размера'

               WHEN CASE WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END = 0
               THEN ' Задано логирование информации о всех временных файлах'
           ELSE ''
           END                                                                                                    "Comment",
          'Управляет регистрацией в журнале имён и размеров временных файлов. ' ||
          'Временные файлы могут использоваться для сортировки, хеширования и временного хранения результатов запросов. ' ||
          'Когда этот параметр включён, при удалении временного файла информация о нём может записываться в журнал. ' ||
          'При нулевом значении записывается информация обо всех файлах, а при положительном — о файлах,' ||
          ' размер которых не меньше заданной величины. Если это значение задаётся без единиц измерения, оно считается заданным в килобайтах.' ||
          ' Значение по умолчанию равно -1, то есть запись такой информации отключена.'
                                            "Рекомендации"
          , context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'log_temp_files'

union

select name                                                                                                       "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = 'kB'
                                                               THEN to_number(setting, '999999999999') * 1024
                                                           ELSE to_number(setting, '999999999999') * 1024 END) as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
       --    ELSE to_number(setting, '999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END < 4 * 1024 * 1024 THEN 0
           ELSE 2 END                                                                                             "check",
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END < 4 * 1024 * 1024
               THEN '- Задано меньше по умолчанию 4 Мб'
           ELSE ''
           END                                                                                                    "Comment",
       CASE
           WHEN to_number(setting, '999999999999') < 0
               THEN
               ''
           ELSE
                   'Базовый максимальный объём памяти, который будет использоваться во внутренних операциях при обработке запросов' ||
                   ' (например, для сортировки или хеш-таблиц), прежде чем будут задействованы временные файлы на диске.'
           END                                                                                                    "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'work_mem'

union

(select 'hash_mem_multiplier'        "parameter",
        NULL                         "setting",
        NULL                         "check",
        'Параметр отсутствует в версии ' || current_setting('server_version_num')::text "Comment",
        NULL                         "Рекомендации",
        NULL                         "context"
 UNION DISTINCT
 select COALESCE(name, 'hash_mem_multiplier') "parameter"
         ,
        setting as                            "setting"
         ,
        CASE
            WHEN to_number(setting, '999999999999') < 2 THEN 0
            ELSE 2 END                        "check",
        CASE
            WHEN to_number(setting, '999999999999') < 2
                THEN '- Задано меньше по умолчанию 2'
            ELSE ''
            END                               "Comment",
                    'Определяет максимальный объёма памяти, который может выделяться для операций с хешированием. ' ||
                    'Итоговый объём определяется произведением work_mem и hash_mem_multiplier. Значение по умолчанию равно 2.0'
                                          "Рекомендации"
        ,
        context
 from pg_catalog.pg_settings lc_set
 where lc_set.name = 'hash_mem_multiplier' order by 2 LIMIT 1
                                                   )
union

select name                                                                                                       "parameter",
    --   setting,
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN to_number(setting,'999999999999') <0
                                                               THEN to_number(setting,'999999999999')
                                                           WHEN unit = 'kB' and to_number(setting,'999999999999') >0
                                                               THEN to_number(setting, '999999999999') * 1024
                                                           ELSE to_number(setting, '999999999999') * 1024 END) as "setting"
       --,CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
       --    ELSE to_number(setting, '999G999G999') END "size_bt"
        ,
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END = -1 THEN 1
           ELSE 2 END                                                                                             "check",
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END = -1
               THEN '+ Задано по умолчанию -1'
           ELSE ''
           END                                                                                                    "Comment",
          'Задаёт максимальный объём дискового пространства, который сможет использовать один процесс для временных файлов, например, при сортировке и хешировании, или для сохранения удерживаемого курсора. Транзакция, которая попытается превысить этот предел, будет отменена. Этот параметр задаётся в килобайтах, а значение -1 (по умолчанию) означает, что предел отсутствует.'
                                                                                                          "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'temp_file_limit'

union

select name                                                                                                "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = '8kB'
                                                               THEN to_number(setting, '999999999999') * 8 * 1024
                                                           ELSE to_number(setting, '999999999999') END) as "setting"
        ,
       CASE
           WHEN unit = '8kB' AND to_number(setting, '999999999999') * 8 < 8 * 1024 THEN 2

           ELSE 2 END                                                                                      "check",

       CASE
           WHEN unit = '8kB' AND to_number(setting, '999999999999') * 8 < 8 * 1024
               THEN 'Задано значение менее дефолтного'

           WHEN unit = '8kB' AND to_number(setting, '999999999999') * 8 = 8 * 1024
               THEN ' Задано дефолтное значение '
           ELSE 'Задано значение ОЛИЧНОЕ от дефолтного'
           END                                                                                             "Comment",
       'Задаёт максимальный объём памяти, выделяемой для временных буферов в каждом сеансе. Эти существующие только в рамках сеанса буферы используются исключительно для работы с временными таблицами. Если это значение задаётся без единиц измерения, оно считается заданным в блоках (размер которых равен BLCKSZ байт, обычно это 8 КБ). Значение по умолчанию — 8 мегабайт (8MB).Этот параметр можно изменить в отдельном сеансе, но только до первого обращения к временным таблицам; после этого изменения его значения не будут влиять на текущий сеанс.'
                                                                                                           "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'temp_buffers'

order by "check", "parameter";

\qecho '<p></p>'
\qecho '<P><A class=awr name=720></A>'
\qecho '<H3 class=awr>Суммарный базовый размер памяти, который может быть выделен на инстансе под рабочие операции.</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>В действительности может быть больше'
\qecho '</UL>'
\qecho '<p></p>'

WITH a_work_mem AS (SELECT CASE
                               WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                               ELSE to_number(setting, '999G999G999') END "work_mem_bt"
                    from pg_catalog.pg_settings lc_set
                    where lc_set.name = 'work_mem')

    , a_conn_cnt AS (select  count(*) AS "conn_cnt" from pg_stat_activity)
    , a_active_con_cnt AS (SELECT COUNT(*) as "active_con_cnt" FROM pg_stat_activity where  state = 'active')

select current_setting('max_connections') AS "max_connections",
       current_setting('work_mem') AS "work_mem",
       pg_size_pretty(a_work_mem.work_mem_bt * current_setting('max_connections')::integer) as "max_connections*work_mem"
       -- ,a_conn_cnt.conn_cnt
       , a_active_con_cnt.active_con_cnt
       ,pg_size_pretty(a_work_mem.work_mem_bt * a_active_con_cnt.active_con_cnt) as "active_con*work_mem"
 from a_work_mem, a_conn_cnt, a_active_con_cnt;


\qecho '<p></p>'
\qecho '<P><A class=awr name=730></A>'
\qecho '<H3 class=awr>Временные файлы, используемые БД</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>temp_files - Количество временных файлов, созданных запросами в этой базе данных. Подсчитываются все временные файлы независимо от причины их создания (например, для сортировки или для хеширования) и независимо от установленного значения log_temp_files'
\qecho '<LI class=awr>temp_bytes - Общий объём данных, записанных во временные файлы запросами в этой базе данных. Учитываются все временные файлы, вне зависимости от того, по какой причине они созданы и вне зависимости от значения log_temp_files'
\qecho '</UL>'
\qecho '<p></p>'

SELECT datname                    AS "database"
     , temp_files
     , temp_bytes
     , pg_size_pretty(temp_bytes) AS "Size temporary files"
FROM pg_stat_database
where temp_bytes > 0
order by temp_bytes desc;


\qecho '<p></p>'
\qecho '<P><A class=awr name=730></A>'
\qecho '<H3 class=awr>Осиротевшие временные файлы</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Временные файлы могут остаться в случаях, когда процесc, который их генерировал, завершился нештатным образом, например был прерван OOMkiller''ом.'
\qecho '<LI class=awr>temp_bytes - Общий объём данных, записанных во временные файлы запросами в этой базе данных. Учитываются все временные файлы, вне зависимости от того, по какой причине они созданы и вне зависимости от значения log_temp_files'
\qecho '</UL>'
\qecho '<p></p>'

WITH dir AS (
  SELECT
    current_setting('data_directory') || '/base/pgsql_tmp' dir
),
    ls AS (
        SELECT  *,
                pg_ls_dir(dir) fn
        FROM    dir
),
    tmp AS (
        SELECT  *,
                regexp_replace(fn, '^pgsql_tmp(\d+).*$', '\1')::integer pid,
                (pg_stat_file(dir || '/' || fn)).*
        FROM    ls
)
SELECT
        dir || '/' || fn
FROM
        tmp
LEFT JOIN   pg_stat_activity sa USING(pid)
WHERE sa IS NOT DISTINCT FROM NULL;

\qecho '<p></p>'
\qecho '<P><A class=awr name=740></A>'
\qecho '<H3 class=awr>Top 20 запросов по количеству записанных блоков во временные файлы</H3>'
\qecho '<UL>'
\qecho '<LI class=awr> Упорядочены по количеству записанных блоков temp_blks_written DESC'
\qecho '<LI class=awr> Времена указаны в секундах'
\qecho '</UL>'
\qecho '<p></p>'

-- \qecho ':ver_less_13' :ver_less_13

\if :ver_less_13
   -- версия меньше 13

SELECT ROUND(total_exec_time  / 1000)            AS "total_exec_time_s",
       to_char(calls, 'FM999G999G999G990') AS "calls",
       ROUND(total_exec_time  / calls / 1000)    AS avg_exec_time_s,
       -- ROUND((temp_blk_read_time + temp_blk_write_time)/1000) AS sync_io_time,
       temp_blks_written,
       queryid
       --query                               AS query
     , regexp_replace(trim(query), '\s+', ' ', 'g') AS "Query_text"

FROM pg_stat_statements
WHERE temp_blks_written > 0
ORDER BY temp_blks_written DESC
LIMIT 20;


\else

SELECT ROUND(ss.total_exec_time / 1000)            AS "total_exec_time_s",
       to_char(calls, 'FM999G999G999G990') AS "calls",
       ROUND(total_exec_time / calls / 1000)    AS avg_exec_time_s,
       -- ROUND((temp_blk_read_time + temp_blk_write_time)/1000) AS sync_io_time,
       temp_blks_written,
       queryid
--       query                               AS query
     , regexp_replace(trim(query), '\s+', ' ', 'g') AS "Query_text"

FROM pg_stat_statements ss
WHERE temp_blks_written > 0
ORDER BY temp_blks_written DESC
LIMIT 20;

\endif

\qecho <P><A class=awr href="#71">Back to Временные файлы, таблицы</A> <BR><A class=awr href="#top">Back to Top</A>

/*
select *
from pg_ls_tmpdir();

select replace(left(name, strpos(name, '.') - 1), 'pgsql_tmp', '') as pid, count(*), sum(size)
from pg_ls_tmpdir()
group by pid;

select queryid,
       substr(query, 1, 25),
       calls,
       temp_blks_read / calls    temp_blks_read_per_call,
       temp_blks_written / calls temp_blks_written_per_call
from pg_stat_statements
where queryid = -7170349228837045701;

 */
