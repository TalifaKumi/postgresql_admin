\qecho '<P><A class=awr name=81></A>'
\qecho '<H2 class=awr>ТРАНСАКЦИИ</H2>'
\qecho '<LI class=awr>Скрипт TRANSACTIONS.sql'

\qecho '<P><A class=awr name=810></A>'
\qecho '<H3 class=awr>Настройки инстанса в части трансакций</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>check = 0 Обязательно изменить!'
\qecho '<LI class=awr>check = 1 Соответствует рекомендациям.!'
\qecho '<LI class=awr>check = 2 Следует обратить внимание.'
\qecho '</UL>'


select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '64' THEN 2 ELSE 1 END "check",
       CASE setting
           WHEN '64' THEN ' Количество блокировок на трансакцию задано по умолчанию'
           ELSE ' '
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Если используются таблицы с большим количеством партиций - следует увеличить'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_locks_per_transaction'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Не задан интервал прерывания сессий для idle_in_transaction '
           ELSE 'Задан интервал прерывания сессий для idle_in_transaction'
           END                                  "Comment",
          'Завершать любые сеансы, простаивающие (то есть ожидающие запросов от клиентов) дольше заданного времени в открытой транзакции. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. При значении, равном нулю (по умолчанию), этот контроль длительности отключается'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'idle_in_transaction_session_timeout'

union

select name                                     "parameter",
       setting || ' ' || unit                                 "setting"
       --,CASE
       --    WHEN unit = 'min' THEN to_number(setting, '999G999G999')*60*1000
       --    ELSE to_number(setting, '999G999G999G999') END "size_ms"
       ,CASE setting WHEN '0' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN  '0' THEN 'Не задан интервал прерывания для сессий вне открытой транзакции'
           ELSE 'Задан интервал прерывания для сессий вне открытой транзакции'
           END                                  "Comment",
          'Завершать любые сеансы, простаивающие (то есть ожидающие запросов от клиентов) дольше заданного времени вне открытой транзакции. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. При значении, равном нулю (по умолчанию), этот контроль длительности отключается.'
                                            "Рекомендации"
       ,  context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'idle_session_timeout'


order by "check", "parameter";



\qecho '<p></p>'
-- \qecho ' <b style="color:red">Ищем того, кто мешает замораживать номера транзакций и объекты, в которых требуется провести заморозку.</b><br>'

\qecho '<P><A class=awr name=811></A>'
\qecho '<H3 class=awr>Долгие трансакции</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Проверка на уровне кластера'
\qecho '<LI class=awr>ordered by age(backend_xmin) desc'
\qecho '</UL>'

SELECT
       age(backend_xmin)                                              age_xmin
     , to_char(localtimestamp - sa.xact_start, 'DD HH24:MI:SS:MS') AS "xact_dur"
     , state
     , sa.wait_event_type AS "WaEvType"
     , sa.wait_event
     , to_char(sa.xact_start, 'DD HH24:MI:SS:MS')  AS "xact_start"
     , to_char(sa.query_start, 'DD HH24:MI:SS:MS') AS "query_start"
     , to_char(sa.state_change, 'DD HH24:MI:SS:MS') AS "state_change"
     , CASE WHEN sa.query_start = sa.xact_start THEN '1' ELSE 'N' END "FQ"
     , to_char(sa.query_start - sa.xact_start, 'MI:SS:US') AS "Q_st-xact"
     , to_char(sa.state_change - sa.xact_start, 'MI:SS:US') AS "state_ch-xact"
     , to_char(sa.state_change - sa.query_start, 'MI:SS:US') AS "state_ch-Q_st"
     , pid
     , pg_blocking_pids(pid) AS "bl_pid"
     , datname
     , usename
     --, backend_xmin
     --age(backend_xid)      age_xid
     , regexp_replace(trim(sa.query), '\s+', ' ', 'g') AS "Query_text"
/* VR_PG */
FROM pg_stat_activity sa
WHERE backend_xmin IS NOT NULL
   AND sa.usename not in ('u_m01ue')
   AND position('VR_PG' IN sa.query) = 0
order by age(backend_xmin) desc;


\qecho '<P><A class=awr name=812></A>'
\qecho '<H3 class=awr>Долгие запросы и давно работающие бэкенды</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Проверка на уровне кластера'
\qecho '<LI class=awr>Могут быть временные таблицы'
\qecho '<LI class=awr>s - second, ms - millisecond - 1000th of a second'
\qecho '<LI class=awr>ordered by age(backend_xid),	age(backend_xmin)'
\qecho '</UL>'

select
	to_char(now() - backend_start,'MM-DD HH24:MI:SS') backend_duration,
	pid,
	datname AS "DB_name",
	usename AS "USER",
	age(backend_xid) age_xid,
	age(backend_xmin) age_xmin,
	state
	,backend_type
    ,wait_event_type
	--,query_id
	--,query AS "Query_text"
	,regexp_replace(trim(query), '\s+', ' ', 'g')     AS "Query_text"
/* VR_PG */
from
	pg_stat_activity
    where age(backend_xmin) IS NOT NULL
       AND position('VR_PG' IN query) = 0
order by
	age(backend_xid),
	age(backend_xmin);

\qecho '<P><A class=awr name=812></A>'
\qecho '<H3 class=awr>Осиротевшие подготовленные транзакции</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Проверка на уровне кластера'
\qecho '<LI class=awr>Могут быть временные таблицы'
\qecho '<LI class=awr>s - second, ms - millisecond - 1000th of a second'
\qecho '<LI class=awr>ordered by age(backend_xid),	age(backend_xmin)'
\qecho '</UL>'

SELECT gid, prepared, owner, database, transaction AS xmin
FROM pg_prepared_xacts
ORDER BY age(transaction) DESC;
/*


\qecho <br>
\qecho <h4> During two-phase commit, a distributed transaction is first prepared with the PREPARE statement and then committed with the COMMIT PREPARED statement </h4>
\qecho <h4> Once a transaction has been prepared, it is kept hanging around until it is committed or aborted. It </h4>
\qecho <h4> even has to survive a server restart! Normally, transactions don not remain in the prepared state for long,  </h4>
\qecho <h4> but sometimes things go wrong and a prepared transaction has to be removed manually by an administrator.  </h4>
\qecho <h4> any Orphaned prepared transactions will prevent the VACUUM to remove the dead rows   </h4>
\qecho <h4>  EXAMPLE: DETAIL:  50000 dead row versions cannot be removed yet,oldest xmin: 22300 </h4>
\qecho <br>
\qecho <h4>  Use the ROLLBACK PREPARED transaction_id SQL statement to  remove prepared transactions    </h4>
*/

\qecho <P><A class=awr href="#81">Back to ТРАНСАКЦИИ</A> <BR><A class=awr href="#top">Back to Top</A>
