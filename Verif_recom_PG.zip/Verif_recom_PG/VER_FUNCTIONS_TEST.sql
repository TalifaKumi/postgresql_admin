CREATE OR REPLACE FUNCTION ver_get_locktype_counts()
RETURNS TABLE (locktypes JSON)
LANGUAGE plpgsql
AS $$
DECLARE
    cols TEXT;
    sql TEXT;
BEGIN
    -- Собираем все уникальные типы блокировок
    SELECT string_agg(
        format('COUNT(*) FILTER (WHERE locktype = %L) AS %I',
               locktype,
               locktype),
        ', '
    ) INTO cols
    FROM (SELECT DISTINCT locktype FROM pg_locks) t;

    -- Формируем SQL-запрос
    IF cols IS NULL THEN
        -- Если блокировок нет
        sql := 'SELECT NULL::JSON';
    ELSE
        sql := format('SELECT json_build_object(%s) AS locktypes FROM pg_locks',
               (SELECT string_agg(format('%L, %I', locktype, locktype), ', ')
                FROM (SELECT DISTINCT locktype FROM pg_locks) t));
    END IF;

    -- Возвращаем результат в JSON
    RETURN QUERY EXECUTE sql;
END;
$$;





CREATE or REPLACE FUNCTION public.ver_if_table_exists( p_nspname varchar,p_tablename varchar)
RETURNS pg_catalog.bool AS
$BODY$
DECLARE
 BEGIN

 /* check the table exist in database and is visible v.1.1

    select public.ver_if_table_exists('public','ver_imported_pg_settings');
*/

 perform n.nspname, c.relname
 FROM pg_catalog.pg_class c
          LEFT JOIN pg_catalog.pg_namespace n ON n.oid
     = c.relnamespace
 where n.nspname = p_nspname
   AND pg_catalog.pg_table_is_visible(c.oid)
   AND Upper(relname) = Upper(p_tablename);

     IF FOUND THEN
        RETURN TRUE;
     ELSE
        RETURN FALSE;
     END IF;

 END;
$BODY$
LANGUAGE 'plpgsql' VOLATILE;

select public.ver_if_table_exists('public','ver_imported_pg_settings');







create OR REPLACE function public.ver_create_conn_db2postgres(conn_name_prefix character varying) returns text
/*
  Cоздание коннекта через dblink из текущей БД к БД postgres
  Имя коннекта формируется по правилу: conn_name_prefix ||_||имя текущей БД||_to_postgres
  Например: 'ver_con_str_to_postgres'

  Возращает имя
  1. Созданного соединения, если такое соединение не было открыто
  2. Имя соединения, если оно уже открыто
  3. null - в случае проблем с созданием соединения

  Примерр вызова
  select public.ver_create_conn_db2postgres('ver_con'::varchar);

 */
    SET search_path = puplic
    language plpgsql
as
$$
DECLARE
    return_conn_name    text;
    lvb_ex_dblink       bool;
    lvt_get_con_name    text[];
    vt_connetction_name text;
    vi_port             integer;
    vt_connstr          text;
BEGIN

    return_conn_name = null;

    IF current_database() <> 'postgres' --Для отличных от postgres
    THEN

        lvb_ex_dblink := (select EXISTS(SELECT 1 FROM pg_extension ex WHERE ex.extname = 'dblink'));

        IF lvb_ex_dblink -- dblink установлено на текущей DB
        THEN

            -- Формируем имя соединения
            vt_connetction_name := conn_name_prefix || '_' || current_database() || '_to_postgres';

            -- Получить значение порта для коннекта
            SELECT inet_server_port() INTO vi_port;

            -- Формируем строку подключения
            if vi_port = 5432 then
                vt_connstr = 'dbname=postgres options=-csearch_path=';
            else
                vt_connstr = 'dbname=postgres options=-csearch_path=  host=/tmp/ port=' || vi_port::text;
            end if;

            RAISE NOTICE ', vt_connection_name: %, vt_connstr: %', vt_connetction_name, vt_connstr;


            lvt_get_con_name := (SELECT public.dblink_get_connections()::text[]);

            IF lvt_get_con_name::text[] is null
            THEN
                PERFORM public.dblink_connect(vt_connetction_name, vt_connstr);
                return_conn_name = vt_connetction_name;
            ELSE
                IF array_position(lvt_get_con_name, vt_connetction_name) < 0
                    --(SELECT POSITION(connetction_name::varchar in lvt_get_con_name)::integer < 0)
                THEN
                    PERFORM public.dblink_connect(vt_connetction_name, vt_connstr);
                    return_conn_name = vt_connetction_name;
                ELSE
                    return_conn_name = vt_connetction_name;
                END IF;

            END IF;

        ELSE
            return_conn_name = null;
        END IF; -- dblink установлено на текущей DB

    ELSE
        return_conn_name = null;
    END IF;
    --Для отличных от postgres

    --UPDATE servers SET enabled = TRUE WHERE server_name = server;
    --GET DIAGNOSTICS upd_rows = ROW_COUNT;

    RETURN return_conn_name;
END
$$;

select public.ver_create_conn_db2postgres('ver_con'::varchar);

-- perform public.ver_connect_to_db_postgres('con_ver_postgres'::varchar);


 select public.dblink_disconnect('ver_con_bookkeeping_db_to_postgres');
-- DROP FUNCTION ver_create_conn_db2postgres;


CREATE or REPLACE FUNCTION ver_get_conn_name_db2postgres() returns text
    SET search_path = puplic
    language plpgsql
as
$$
DECLARE
    return_conn_name    text;
BEGIN

    IF current_database() <> 'postgres' --Для отличных от postgres
    THEN
        return_conn_name = 'ver_con' || '_' || current_database() || '_2postgres';
    ELSE
        return_conn_name = null;
    END IF;

    RETURN return_conn_name;
END;
$$;

select public.ver_get_conn_name_db2postgres();








