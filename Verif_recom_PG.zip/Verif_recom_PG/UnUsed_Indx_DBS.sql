DO
$do$

DECLARE
	--Cursor for db list
	c_dblist CURSOR FOR
	SELECT datname FROM pg_catalog.pg_database dbs where not datistemplate and datallowconn
    and datname<>'postgres';

    curs1               refcursor;
	qres				record;
    rec                 record;
	connstr				text;
	db_connstr			text;
	t_query				text;
    t_is_connect        text;

BEGIN
    t_is_connect := '???';
		--t_query := 'select indexrelid from pg_index limit 1';
t_query := 'select pxcommitdatetime from data.abr_data_dict limit 3';

		connstr := (select 'port='||current_setting('port'));
		--RAISE NOTICE '������������ � �� %', t_query;

		FOR qres IN c_dblist
		LOOP
			db_connstr := concat_ws(' ',connstr, format($o$dbname=%s$o$,replace(qres.datname,$o$'$o$,$o$\'$o$)));
			RAISE NOTICE '������������ � �� %', db_connstr;
			--SELECT '222' as t_is_connect ;

			-- SELECT dblink_connect(db_connstr) as t_is_connect ;
-- RAISE NOTICE '������� ��  %', t_is_connect;
-- SELECT *     FROM dblink(db_connstr, t_query)       AS t1(indexrelid bigint);

-- SELECT *     FROM dblink(db_connstr, t_query)       AS t1(pxcommitdatetime timestamp)    WHERE pxcommitdatetime is not null;

OPEN curs1 FOR
 			SELECT *
    FROM dblink('port=5432 dbname=pega',
                'select pxcommitdatetime from data.abr_data_dict limit 5')
      AS t1(pxcommitdatetime timestamp)
    WHERE pxcommitdatetime is not null
     ;

/*
            LOOP
                FETCH NEXT FROM curs1 INTO rec;
                EXIT WHEN rec IS NULL;

                RAISE NOTICE 'rec: %', rec;
            END LOOP;

CLOSE curs1;

FOR recordvar IN curs1 LOOP
                RAISE NOTICE 'recordvar: %', recordvar;
END LOOP;
*/
-- FETCH curs1 INTO rowvar;

			--PERFORM dblink_exec(db_connstr, t_query);
				--RAISE NOTICE '� �� % ������ %', qres, t_query;


		END LOOP;

END
$do$;
