-- Получить отчеты pg_profile между двумя последними снимками

SELECT COUNT(*)>0 AS vb_is_profile_server FROM profile.servers WHERE enabled is true;
\gset

-- Есть хоть один profile server
\if :vb_is_profile_server

\set vt_pg_profile '_pg_profile'

\set vt_primary '_primary'

\set vt_replica '_pg_replica'


-- \pset format aligned
\pset format unaligned
-- включают или отключают вывод результирующей строки с количеством выбранных записей (n строк)
\pset footer off
--Отключает вывод имён столбцов и результирующей строки с количеством выбранных записей
\pset tuples_only

select public.ver_get_profile_primary_server_name() AS vt_primary_server;
\gset

select public.ver_get_profile_primary_server_id() AS vi_primary_server_id;
\gset

/*
select sample_id as vi_end_sample_id
FROM profile.samples t
where server_id = :vi_primary_server_id
ORDER BY sample_time DESC
limit 1;
\gset
 */

-- Вариант получения последнего номера снимка через функцию
select public.ver_get_end_sample_id(:vi_primary_server_id) as vi_end_sample_id;
\gset

select public.ver_get_end_sample_id(1) as vi_end_sample_id;

/*
select sample_id as vi_start_sample_id from (select sample_id, sample_time
                       FROM profile.samples t
                       where server_id = :vi_primary_server_id
                       ORDER BY sample_time DESC
                       limit 2) a1
ORDER BY sample_time limit 1;
\gset
*/

-- Вариант получения последнего номера снимка через функцию
select public.ver_get_second_to_last_sample_id(:vi_primary_server_id) as vi_start_sample_id;
\gset

-- Формируем имя файла для вывода отчета pg_profile с primary инстанса
\set vt_out_file_primary_profile :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_pg_profile:vt_underscore:vt_primary_server:vt_primary:vt_tail_html
\o :vt_out_file_primary_profile


-- Получение отчета с primary инстанса
SELECT profile.get_report(:vi_primary_server_id, :vi_start_sample_id, :vi_end_sample_id);


\o
\qecho 'File Created:':vt_out_file_primary_profile

select public.ver_get_profile_second_server_name() is not null AS vb_is_second_server;
\gset

-- Если второй инстанс существует
\if :vb_is_second_server

select public.ver_get_profile_second_server_name() AS vt_second_server;
\gset

select public.ver_get_profile_second_server_id() AS vi_second_server_id;
\gset

select sample_id as vi_end_sample_id
FROM profile.samples t
where server_id = :vi_second_server_id
ORDER BY sample_time DESC
limit 1;
\gset

select sample_id as vi_start_sample_id from (select sample_id, sample_time
                       FROM profile.samples t
                       where server_id = :vi_second_server_id
                       ORDER BY sample_time DESC
                       limit 2) a1
ORDER BY sample_time limit 1;
\gset


-- Формируем имя файла для вывода отчета pg_profile с second инстанса
\set vt_out_file_second_profile :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_pg_profile:vt_underscore:vt_second_server:vt_replica:vt_tail_html
\o :vt_out_file_second_profile

-- Получение отчета с second инстанса
SELECT profile.get_report(:vi_second_server_id, :vi_start_sample_id, :vi_end_sample_id);

/*
Вариант для проверки количества вызовов функции с использованием plprofiler
SELECT profile.get_report(public.ver_get_profile_primary_server_id(), (select sample_id
                                                                       FROM profile.samples t
                                                                       where server_id = public.ver_get_profile_second_server_id()
                                                                         and sample_id <> (select sample_id
                                                                                           FROM profile.samples t
                                                                                           where server_id = public.ver_get_profile_second_server_id()
                                                                                           ORDER BY sample_time DESC
                                                                                           limit 1)
                                                                       ORDER BY sample_time DESC
                                                                       limit 1), (select sample_id
                                                                                  FROM profile.samples t
                                                                                  where server_id = public.ver_get_profile_second_server_id()
                                                                                  ORDER BY sample_time DESC
                                                                                  limit 1)) as ":vt_project:vt_time";
*/

\o
\qecho 'File Created:':vt_out_file_second_profile
\else
\qecho 'Second instance missing'
\endif
-- Завершение по второму инстансу

select public.ver_get_profile_third_server_name() is not null AS vb_is_third_server;
\gset

-- Если третий инстанс существует
\if :vb_is_third_server

select public.ver_get_profile_third_server_name() AS vt_third_server;
\gset

select public.ver_get_profile_third_server_id() AS vi_third_server_id;
\gset

select sample_id as vi_end_sample_id
FROM profile.samples t
where server_id = :vi_third_server_id
ORDER BY sample_time DESC
limit 1;
\gset

select sample_id as vi_start_sample_id from (select sample_id, sample_time
                       FROM profile.samples t
                       where server_id = :vi_third_server_id
                       ORDER BY sample_time DESC
                       limit 2) a1
ORDER BY sample_time limit 1;
\gset


-- Формируем имя файла для вывода отчета pg_profile с third инстанса
\set vt_out_file_third_profile :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_pg_profile:vt_underscore:vt_third_server:vt_replica:vt_tail_html
\o :vt_out_file_third_profile

-- Получение отчета с third инстанса

SELECT profile.get_report(:vi_third_server_id, :vi_start_sample_id, :vi_end_sample_id);

\o
\qecho 'File Created:':vt_out_file_third_profile
\else
\qecho 'Third instance missing'
\endif
-- Завершение по третьему инстансу

\else
\qecho 'There is not one profile server'
\endif
-- Есть хоть один profile server

