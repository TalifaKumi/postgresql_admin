\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H3 class=awr>Настройки инстанса, сравнение, история изменений</H3>'

\qecho '<A class=awr_ital>Скрипт Basic_Setting.sql</A>'
\qecho '<p></p>'

\qecho '<UL>'
\qecho '<LI class=awr>Специфические настройки приведены в соответствующих разделах'
\qecho '<LI class=awr>Показаны только те настройки, которые проверялись'
\qecho '<LI class=awr>check = 0 Обязательно изменить!'
\qecho '<LI class=awr>check = 1 Соответствует рекомендациям.!'
\qecho '<LI class=awr>check = 2 Следует обратить внимание.'
\qecho '</UL>'
\qecho '<p></p>'

SELECT 'internal'                                       as "context",
       'изменить нельзя, значение задано при установке' as "Значение"
union
SELECT 'postmaster'                   as "context",
       'требуется перезапуск сервера' as "Значение"
union
SELECT 'sighup'                                  as "context",
       'требуется перечитать файлы конфигурации' as "Значение"
union
SELECT 'superuser'                                          as "context",
       'суперпользователь может изменить для своего сеанса' as "Значение"
union
SELECT 'user'                                                as "context",
       'любой пользователь может изменить для своего сеанса' as "Значение"
order by 1;

\qecho '<p></p>'
--select  sum(pg_database_size(datname))              AS  dbs_size_bytes
--from pg_database;


select name                                                                                               "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = '8kB'
                                                               THEN to_number(setting, '999999999999') * 8 * 1024
                                                           ELSE to_number(setting, '999999999999') END) as "setting",
       /*CASE
           WHEN unit = '8kB' THEN to_number(setting, '999999999999') * 8 * 1024
           ELSE to_number(setting, '999999999999') END                                                     "size_bt",
       pg_size_pretty(CASE
                          WHEN unit = '8kB' THEN to_number(setting, '999999999999') * 8 * 1024
                          ELSE to_number(setting, '999999999999') END)                                     "pretty",
       */
       CASE
           WHEN CASE
                    WHEN unit = '8kB' THEN to_number(setting, '999999999999') * 8 * 1024
                    ELSE to_number(setting, '999999999999') END <= 128 * 1024 THEN 0
           ELSE 2 END                                                                                     "check",
       CASE
           WHEN CASE
                    WHEN unit = '8kB' THEN to_number(setting, '999G999G999') * 8 * 1024
                    ELSE to_number(setting, '999999999999') END <= 128 * 1024 THEN '- Не должно быть менее 128 Кб'
           ELSE ''
           END                                                                                            "Comment",
       CASE
           WHEN to_number(setting, '999999999999') > 0
               THEN
               'По умолчанию 128MB Рекомендованное значение от 25% до 40% доступной оперативной памяти на хосте'
           ELSE
               ''
           END                                                                                            "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'shared_buffers'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Режим синхронной репликации включен'
           ELSE '- Режим синхронной репликации НЕ включен'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Должен быть on '
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'synchronous_commit'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Сбор статистики активности в БД включен'
           ELSE '- Сбор статистики активности в БД отключен'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Должен быть on Cобранная информация требуется демону автоочистки'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'track_counts'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Сбор сбор сведений о текущих командах включен'
           ELSE '- Сбор сбор сведений о текущих командах отключен'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Должен быть on Включает сбор сведений о текущих командах, выполняющихся во всех сеансах (в частности, отслеживается идентификатор и время запуска команды)'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'track_activities'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ замер времени операций ввода/вывода включен'
           ELSE '- замер времени операций ввода/вывода отключен'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Должен быть on Нужен для pg_profile По умолчанию отключён'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'track_io_timing'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ замер времени операций ввода/вывода WAL включен'
           ELSE '- замер времени операций ввода/вывода WAL отключен'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Должен быть on Нужен для pg_profile По умолчанию отключён. Рекомендованное значение on '
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'track_wal_io_timing'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'all' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'all' THEN '+ подсчёт вызовов функций и времени их выполнения включен'
           ELSE '- подсчёт вызовов функций и времени их выполнения отключен'
           END                                  "Comment",
       CASE setting
           WHEN 'all'
               THEN
               ''
           ELSE
               'Должен быть all Нужен для pg_profile По умолчанию отключён'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'track_functions'


union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '1.1' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN '4' THEN ' - задано по умолчанию'
           WHEN '1.1' THEN '+ Задано значение для SSD дисков'
           ELSE ' '
           END                                  "Comment",
       CASE setting
           WHEN '4'
               THEN
               'Если используются  SSD диски следует задать 1.1'
           ELSE
               ''
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'random_page_cost'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '64' THEN 2 ELSE 1 END "check",
       CASE setting
           WHEN '64' THEN ' Количество блокировок на трансакцию задано по умолчанию'
           ELSE ' '
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Если используются таблицы с большим количеством партиций - следует увеличить'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_locks_per_transaction'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Вычисление идентификатора запроса в ядре включено'
           ELSE ' - Вычисление идентификатора запроса в ядре НЕ включено'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Должен задаваться в postgresql.conf Рекомендованное значение on'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'compute_query_id'

union
select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Вычисление контрольных сумм включено'
           ELSE ' - Вычисление контрольных сумм НЕ включено'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Контрольные суммы обычно включают при инициализации кластера с помощью initdb'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'data_checksums'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'on' THEN '+ Синхронная запись на диск включена'
           ELSE ' - Синхронная запись на диск НЕ включена'
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Параметр fsync можно задать только в файле postgresql.conf '
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'fsync'

union

select name                                           "parameter",
       setting || ' ' || unit || '=' || pg_size_pretty(CASE
                                                           WHEN unit = 'kB'
                                                               THEN to_number(setting, '999999999999') * 1024
                                                           ELSE to_number(setting, '999999999999') END) as "setting"
       --CASE
       --    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
       --    ELSE to_number(setting, '999999999999') END "size_bt",
      , CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END <= 64 * 1024 * 1024 THEN 0
           ELSE 2 END                                 "check",
       CASE
           WHEN CASE
                    WHEN unit = 'kB' THEN to_number(setting, '999999999999') * 1024
                    ELSE to_number(setting, '999999999999') END <= 64 * 1024 * 1024
               THEN '- Задано меньше\равно по умолчанию 64 Мб'
           ELSE ''
           END                                        "Comment",
       CASE
           WHEN to_number(setting, '999999999999') < 0
               THEN
               ''
           ELSE
               'Задаёт максимальный объём памяти для операций обслуживания БД, в частности VACUUM, CREATE INDEX и ALTER TABLE ADD FOREIGN KEY. По умолчанию 64 Мб'
           END                                        "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'maintenance_work_mem'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'try' THEN 1 ELSE 0 END "check",
       CASE setting
           WHEN 'try' THEN '+ Задано использование больших страниц по умолчанию'
           WHEN 'off' THEN '- большие страницы не будут запрашиваться'
           WHEN 'on' THEN '- если получить огромные страницы не удастся, сервер не будет запущен'
           ELSE '- не определено'
           END                                  "Comment",
               'Определяет, будут ли огромные страницы запрашиваться из основной области общей памяти. Допустимые значения: try (по умолчанию), on и off. Когда параметр huge_pages равен try, сервер будет пытаться запрашивать огромные страницы, но если это ему не удастся, вернётся к стандартному поведению.'
                                "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'huge_pages'

union

select name                    "parameter",
       CASE
           WHEN setting = '0' THEN '0'
           ELSE setting END as "setting"
        ,
       CASE
           WHEN setting = '0' THEN 1
           ELSE 0 END          "check",
       CASE
           WHEN setting = '0' THEN '+ Задано по умолчанию'
           ELSE '- Задано значение НЕ по умолчанию' END
                               "Comment",
       'Задаёт размер огромных страниц, если их использование включено параметром huge_pages. Значение по умолчанию — ноль (0). При таком значении будет использоваться размер огромных страниц, заданный в системе по умолчанию'
                               "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'huge_page_size'

order by "check", "parameter";

\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H4 class=awr>Настройки инстанса по параллелизму.</H4>'


select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '8' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN '8' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт максимальное число фоновых процессов, которое можно запустить в текущей системе. Этот параметр можно задать только при запуске сервера. Значение по умолчанию — 8.
           Для ведомого сервера значение этого параметра должно быть больше или равно значению на ведущем. В противном случае на ведомом сервере не будут разрешены запросы'
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_worker_processes'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '8' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN '8' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт максимальное число рабочих процессов, которое система сможет поддерживать для параллельных операций. Значение по умолчанию — 8. При изменении этого значения также может иметь смысл скорректировать max_parallel_maintenance_workers и max_parallel_workers_per_gather'
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_parallel_workers'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '2' THEN 1 WHEN '0' THEN 0
           ELSE 2 END "check",
       CASE setting
           WHEN '2' THEN 'Задано значение по умолчанию'
           WHEN '0' THEN 'Параллельное выполнение запросов отключено'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт максимальное число рабочих процессов, которые могут запускаться одним узлом Gather или Gather Merge. Параллельные рабочие процессы берутся из пула процессов, контролируемого параметром max_worker_processes, в количестве, ограничиваемом значением max_parallel_workers. Значение по умолчанию — 2. Значение 0 отключает параллельное выполнение запросов.'
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_parallel_workers_per_gather'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '2' THEN 1 WHEN '0' THEN 0
           ELSE 2 END "check",
       CASE setting
           WHEN '2' THEN 'Задано значение по умолчанию'
           WHEN '0' THEN 'Параллельное выполнение запросов отключено'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Задаёт максимальное число рабочих процессов, которые могут запускаться одной служебной командой. В настоящее время параллельные процессы может использовать только CREATE INDEX при построении индекса-B-дерева и VACUUM без указания FULL. Параллельные рабочие процессы берутся из пула процессов, контролируемого параметром max_worker_processes, в количестве, ограничиваемом значением max_parallel_workers. Значение по умолчанию — 2. Значение 0 отключает использование параллельных исполнителей служебными командами.'
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_parallel_maintenance_workers'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN 'on' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN 'on' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Позволяет ведущему процессу выполнять план запроса ниже узлов Gather и Gather Merge, не ожидая рабочие процессы. По умолчанию этот параметр включён (on). Значение off снижает вероятность блокировки рабочих процессов в случае, если ведущий процесс будет читать кортежи недостаточно быстро, но тогда ведущему приходится дожидаться запуска рабочих процессов, и только затем выдавать первые кортежи. Степень положительного или отрицательного влияния ведущего зависит от типа плана, числа рабочих процессов и длительности запроса.'
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'parallel_leader_participation'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '4' THEN 1 ELSE 2 END "check",
       CASE setting
           WHEN '4' THEN 'Задано значение по умолчанию'
           ELSE 'Задано значение НЕ по умолчанию'
           END                                  "Comment",
          'Максимально возможное число рабочих процессов логической репликации. В это число входят как ведущие и параллельные рабочие процессы, применяющие изменения, так и процессы, синхронизирующие таблицы.
           Рабочие процессы логической репликации берутся из пула, контролируемого параметром max_worker_processes. Значение по умолчанию — 4'
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_logical_replication_workers'

union

select name                                                                                               "parameter",
       setting  as "setting",

       CASE
           WHEN  (to_number(setting, '999999999999') >= 1 and to_number(setting, '999999999999') <= 1000)  THEN 1
           ELSE 2
       END                                                                           "check",
      ''                                                                             "Comment",
     'Задаёт допустимое число параллельных операций ввода/вывода, которое говорит ПГ  о том, сколько операций ввода/вывода могут быть выполнены одновременно. Чем больше это число, тем больше операций ввода/вывода будет пытаться выполнить параллельно ПГ в отдельном сеансе. Допустимые значения лежат в интервале от 1 до 1000, а нулевое значение отключает асинхронные запросы ввода/вывода. В настоящее время этот параметр влияет только на сканирование по битовой карте.'
                                                                                           "Рекомендации"
        , context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'effective_io_concurrency'
;

\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H3 class=awr>Сравнениие настроек текущего инстанса и настроек из файла example_settings_01.csv </H3>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H5 class=awr>Настройки, которые есть в обоих сравниваемых списках, но имеют разные значения</H5>'

\qecho '<UL>'
\qecho '<LI class=awr>В первой строке с name = 0_Project в setting = имя текущего проекта, в imported_setting = имя импорртированного проекта:'
\qecho '<LI class=awr>Первая строка НЕ ЯВЛЯЕТСЯ настройкой и добавлена для удобства сравнения'
\qecho '</UL>'
\qecho '<p></p>'

WITH a1_set_pro as
         (select cs.name
               , cs.setting
               , cs.unit
               , cs.vartype
               , cs.source
               , cs.short_desc
          from pg_catalog.pg_settings cs
          union
          select '0_Project'        as name
               , :vt_project_mark as setting
               , null                  unit
               , null                  vartype
               , null                  source
               , null                  short_desc
          order by name)

select * from
(
select cs.name
                    , cs.setting
                    , im.setting as                                       imported_setting
                    , im.name    as                                       imported_name
                    , CASE WHEN cs.setting = im.setting THEN 1 ELSE 0 END "check"
                    , cs.unit
                    , im.unit as imported_unit
                    , cs.vartype
                    , cs.source
                    , cs.short_desc
from a1_set_pro cs
                        JOIN public.ver_imported_pg_settings im on cs.name = im.name
    ) a1
where a1.check =0
order by name;

\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H5 class=awr>Настройки, которые есть ТОЛЬКО в текущем инстансе</H5>'

\qecho '<UL>'
\qecho '<LI class=awr>В первой строке с name = 0_Project в setting = имя текущего проекта, в imported_setting = имя импорртированного проекта:'
\qecho '<LI class=awr>Первая строка НЕ ЯВЛЯЕТСЯ настройкой и добавлена для удобства сравнения'
\qecho '</UL>'
\qecho '<p></p>'

WITH a1_set_pro as
         (select cs.name
               , cs.setting
               , cs.unit
               , cs.vartype
               , cs.source
               , cs.short_desc
          from pg_catalog.pg_settings cs
          union
          select '0_Project'        as name
               , :vt_project_mark as setting
               , null                  unit
               , null                  vartype
               , null                  source
               , null                  short_desc
          order by name)

select * from
(
select cs.name
                    , cs.setting
                    , im.setting as                                       imported_setting
                    , im.name    as                                       imported_name
                    , CASE WHEN cs.setting = im.setting THEN 1 ELSE 0 END "check"
                    , cs.unit
                    , im.unit as imported_unit
                    , cs.vartype
                    , cs.source
                    , cs.short_desc
from a1_set_pro cs
                        left join public.ver_imported_pg_settings im on cs.name = im.name
    ) a1
where a1.check =0
and a1.imported_name is null
order by name;

\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H5 class=awr>Настройки, которые есть ТОЛЬКО во внешнем файле настроек</H5>'

\qecho '<UL>'
\qecho '<LI class=awr>В первой строке с name = 0_Project в setting = имя текущего проекта, в imported_setting = имя импорртированного проекта:'
\qecho '<LI class=awr>Первая строка НЕ ЯВЛЯЕТСЯ настройкой и добавлена для удобства сравнения'
\qecho '</UL>'
\qecho '<p></p>'


WITH a1_set_pro as
         (select cs.name
               , cs.setting
               , cs.unit
               , cs.vartype
               , cs.source
               , cs.short_desc
          from pg_catalog.pg_settings cs
          union
          select '0_Project'        as name
               , :vt_project_mark as setting
               , null                  unit
               , null                  vartype
               , null                  source
               , null                  short_desc
          order by name)

select * from
(
select cs.name
                    , cs.setting
                    , im.setting as                                       imported_setting
                    , im.name    as                                       imported_name
                    , CASE WHEN cs.setting = im.setting THEN 1 ELSE 0 END "check"
                    , cs.unit
                    , im.unit as imported_unit
                    , im.vartype
                    , im.source
                    , im.short_desc
from a1_set_pro cs
                        right join public.ver_imported_pg_settings im on cs.name = im.name
    ) a1
where a1.check =0
and a1.name is null
order by name;

-- SELECT * FROM public.ver_imported_pg_settings

\qecho '<p></p>'
\qecho '<P><A class=awr name=41></A>'
\qecho '<H5 class=awr>История изменения значений параметров настроек инстанса</H5>'

\qecho '<UL>'
\qecho '<LI class=awr>Упорядочены по серверам и убыванию времени последнего изменения значения параметра server_id, t.first_seen DESC'
\qecho '</UL>'
\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>
\qecho '<p></p>'

SELECT *
FROM profile.sample_settings t
WHERE name <> 'pg_conf_load_time'
ORDER BY t.server_id, t.first_seen DESC;

\qecho </details>

\qecho <P><A class=awr href="#41">Back to Настройки инстанса, сравнение, история изменений </A> <BR><A class=awr href="#top">Back to Top</A>

