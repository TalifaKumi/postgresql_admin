\qecho '<P><A class=awr name=161></A>'
\qecho '<H2 class=awr>Запросы, функции</H2>'
\qecho '<LI class=awr>Скрипт Queries_TOP_10.sql'


\qecho '<UL>'
\qecho '<LI class=awr><A class=awr href="#1610">Настройки pg_stat_statements</A>'
\qecho '<LI class=awr><A class=awr href="#1611">Кумулятивная статистика по успешно выполненным запросам</A>'
\qecho '<LI class=awr><A class=awr href="#1612">Функции</A>'
-- \qecho '<LI class=awr><A class=awr href="#614">Таблицы, кандидаты на изменение порога запуска сбора статистики autovacuum_analyze_scale_factor</A>'
\qecho '</LI></UL>'
\qecho '<p></p>'

\qecho '<P><A class=awr name=1610></A>'
\qecho '<H3 class=awr>Настройки pg_stat_statements</H3>'
\qecho '<p></p>'

SELECT ps.name,
       ps.setting,
       ps.short_desc,
       ps.context,
       ps.source,
       ps.min_val,
       ps.max_val,
       ps.boot_val,
       ps.reset_val,
       ps.pending_restart
from pg_catalog.pg_settings ps
WHERE NAME LIKE '%pg_stat_statements%';

-- SELECT dblink_connect_u('dbname=postgres options=-csearch_path=');

\qecho '<p></p>'

select si.stats_reset, now() - stats_reset "time_from_reset", si.dealloc
from public.pg_stat_statements_info si;
\qecho '<p></p>'

\qecho '<P><A class=awr name=1611></A>'
\qecho '<H3 class=awr>Открытые курсоры на момент создания отчета</H3>'
\qecho '<p></p>'

select * from pg_cursors;

\qecho '<P><A class=awr name=1611></A>'
\qecho '<H3 class=awr>Кумулятивная статистика по успешно выполненным запросам</H3>'
\qecho '<p></p>'

-- На данный момент уже накоплена статистика по Х типам запросов
SELECT count(*) "Количество типов запросов", sum(calls) AS "Количество вызовов"
FROM pg_stat_statements;
\qecho '<p></p>'

\qecho '<H5 class=awr>Количество запросов по отдельным пользователям, базам данных или группам</H5>'
SELECT pg_get_userbyid(s.userid) AS username, d.datname, count(*)
FROM pg_stat_statements s,
     pg_database d
WHERE s.dbid = d.oid
GROUP BY 1, 2
ORDER BY 3 DESC;
\qecho '<p></p>'

\qecho '<H5 class=awr>Доля ввода\\вывода для всех зарегистрированных запросов</H5>'

select round(io_percent::numeric, 2) AS io_percent, round(cpu_percent::numeric, 2) AS cpu_percent
from (SELECT (sum(blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time
                  ) * 100 / sum(total_exec_time)) AS io_percent,
             sum(total_exec_time -
                 (blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time)
                 ) * 100 / sum(total_exec_time)   AS cpu_percent
      FROM pg_stat_statements) a1;
\qecho '<p></p>'

\qecho '<H5 class=awr>Запросы с самым большим суммарным временем выполнения</H5>'

\if :ver_15
-- OR :ver_16

SELECT max(rl.rolname)                                                          as rolname
     , max(db.datname)                                                          as datname
--       ,max(SS.toplevel::INT)                       as toplevel
     , bool_or(SS.toplevel)                                                     as toplevel
--       ,round(sum(SS.total_exec_time/1000)) "tot_exe_t_sec"
     , to_char(
            interval '1 millisecond' * sum(total_exec_time),
            'HH24:MI:SS'
    )                                                                           AS "tot_exe_time"
     , (100 * sum(
            blk_read_time + blk_write_time +
            temp_blk_read_time + temp_blk_write_time
    ) / sum(total_exec_time))::numeric(5, 2)::text || ' , ' ||
       (100 * sum(total_exec_time - (
               blk_read_time + blk_write_time +
               temp_blk_read_time + temp_blk_write_time)
           ) / sum(total_exec_time))::numeric(5, 2)                             AS "io , cpu, %"

     , sum(SS.calls)                                                            as "calls"
     , sum(SS.rows)                                                             as "rows"
     , sum(SS.plans)                                                            as "plans"
     , sum(SS.total_plan_time)                                                  as "tot_plan_t_ms" -- 13 wer
     -- round(SS.total_exec_time) tot_exe_t_ms,
     , round(min(SS.min_exec_time))                                             as "min_exe_t_ms"
     , round(max(SS.max_exec_time))                                             as "max_exe_t_ms"
     , round(avg(SS.mean_exec_time))                                            as "mean_exe_t_ms"
     , round(max(SS.stddev_exec_time))                                          as "stddev_exe_t_ms"
     , sum(SS.shared_blks_hit)                                                  as "shared_blks_hit"
     , sum(SS.shared_blks_read)                                                 as "shared_blks_read"
     , sum(SS.shared_blks_dirtied)                                              as "shared_blks_dirtied"
     , sum(SS.shared_blks_written)                                              as "shared_blks_wr"
     , sum(SS.local_blks_hit)                                                   as "local_blks_hit"
     , sum(SS.local_blks_read)                                                  as "local_blks_read"
     , sum(SS.local_blks_dirtied)                                               as "local_blks_dirtied"
     , sum(SS.local_blks_written)                                               as "local_blks_wr"
     , sum(SS.temp_blks_read)                                                   as "temp_blks_read)"
     , sum(SS.temp_blks_written)                                                as "temp_blks_written"
     , sum(SS.blk_read_time)                                                    as "blk_read_time"
     , sum(SS.blk_write_time)                                                   as "blk_write_time"
     , max(ss.queryid)                                                          as "queryid"
     , max(to_hex(queryid))                                                     AS hexqueryid
     , max(left(md5(ss.userid::text || ss.dbid::text || ss.queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                             AS "Query_text"

FROM pg_stat_statements SS
         JOIN pg_roles rl ON (SS.userid = rl.oid)
         JOIN pg_database db ON (SS.dbid = db.oid)
WHERE 1 = 1
      -- AND db.datname = current_database()
GROUP BY query
ORDER BY sum(total_exec_time) DESC
LIMIT 10;

\else
select now();

\endif


\qecho '<H5 class=awr>Десять наиболее часто выполняемых запросов</H5>'
SELECT sum(calls)                                                      AS total_calls
     , max(queryid)                                                    as "queryid"
     , max(to_hex(queryid))                                            AS hexqueryid
     , max(left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                    AS "Query_text"
FROM pg_stat_statements
GROUP BY query
ORDER BY sum(calls) DESC
LIMIT 10;
\qecho '<p></p>'

\qecho '<H5 class=awr>Запросы с наибольшим количеством затронутых строк</H5>'
SELECT sum(rows)                                                       AS total_rows
     , max(queryid)                                                    as "queryid"
     , max(to_hex(queryid))                                            AS hexqueryid
     , max(left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                    AS "Query_text"
FROM pg_stat_statements
GROUP BY query
ORDER BY sum(rows) DESC
LIMIT 10;
\qecho '<p></p>'

\qecho '<H5 class=awr>Запросы с наибольшим временем исполнения</H5>'

SELECT to_char(
            interval '1 millisecond' * sum(total_exec_time), 'HH24:MI:SS'
    )                                                                  AS exec_time
     , max(queryid)                                                    as "queryid"
     , max(to_hex(queryid))                                            AS hexqueryid
     , max(left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                    AS "Query_text"
FROM pg_stat_statements
GROUP BY query
ORDER BY sum(total_exec_time) DESC
LIMIT 10;
\qecho '<p></p>'


\qecho '<H5 class=awr>Запросы с наибольшим временем ввода-вывода</H5>'

SELECT to_char(
            interval '1 millisecond' * sum(
                blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time
            ), 'HH24:MI:SS.MS'
    )                                                                  AS io_time
     , max(queryid)                                                    as "queryid"
     , max(to_hex(queryid))                                            AS hexqueryid
     , max(left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                    AS "Query_text"
FROM pg_stat_statements
WHERE blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time > 0
GROUP BY query
ORDER BY sum(blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time) DESC
LIMIT 10;

\qecho '<p></p>'

-- В ОС Linux сброситькеш можно следующей командой, выполненной от пользователя root (не делайте этого в производственных окружениях, это негативно скажется на производительности):
-- # echo 3 > /proc/sys/vm/drop_caches

\qecho '<H5 class=awr>Запросы с наибольшим временем выполнения без учета ввода-вывода(CPU + другие ожидания)</H5>'

SELECT to_char(
            interval '1 millisecond' * sum(total_exec_time - (
            blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time)), 'HH24:MI:SS') AS cpu_time
     , max(queryid)                                                                                    as "queryid"
     , max(to_hex(queryid))                                            AS hexqueryid
     , max(left(md5(userid::text || dbid::text || queryid::text), 10)) AS hashed_ids
     , regexp_replace(trim(query), '\s+', ' ', 'g')                                                    AS "Query_text"
FROM pg_stat_statements
GROUP BY query
ORDER BY sum(total_exec_time - (
    blk_read_time + blk_write_time + temp_blk_read_time + temp_blk_write_time)
             ) DESC
LIMIT 10;
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=1613></A>'
\qecho '<H5 class=awr>Количество запросов в активных сессиях по событиям ожидания</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Покзаны на момент формирования отчета'
\qecho '<LI class=awr>в порядке убывания количества запросов cnt_queryes'
\qecho '</UL>'
\qecho '<p></p>'

select  now() as "Время снимка";
\qecho '<p></p>'
select wait_type_event, query_id, query, count(*) as cnt_queryes from (SELECT pid,
                                           datname,
                                           usename,
                                           application_name,
                                           client_addr,
                                           pg_catalog.to_char(backend_start, 'YYYY-MM-DD HH24:MI:SS TZ') AS backend_start,
                                           state,
                                           wait_event_type || ': ' || wait_event                         AS wait_type_event,
                                           array_to_string(pg_catalog.pg_blocking_pids(pid), ', ')       AS blocking_pids,
                                           query_id,
                                           query,
                                           pg_catalog.to_char(state_change, 'YYYY-MM-DD HH24:MI:SS TZ')  AS state_change,
                                           pg_catalog.to_char(query_start, 'YYYY-MM-DD HH24:MI:SS TZ')   AS query_start,
                                           pg_catalog.to_char(xact_start, 'YYYY-MM-DD HH24:MI:SS TZ')    AS xact_start,
                                           backend_type,
                                           CASE
                                               WHEN state = 'active'
                                                   THEN ROUND((extract(epoch from now() - query_start) / 60)::numeric, 2)
                                               ELSE 0 END                                                AS active_since
                                    FROM pg_catalog.pg_stat_activity
                                    WHERE 1 = 1
                                      and state = 'active'
                                      and wait_event is not null) a1
group by wait_type_event, query_id, query
order by 4 desc;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1613></A>'
\qecho '<H5 class=awr>Запросы в активных сессиях по событиям ожидания</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>Покзаны на момент формирования отчета'
\qecho '<LI class=awr>отсортированиы по wait_type_event'
\qecho '</UL>'
\qecho '<p></p>'

select  now() as "Время снимка";
\qecho '<p></p>'

SELECT
    pid,
    datname,
    usename,
    application_name,
    client_addr,
    pg_catalog.to_char(backend_start, 'YYYY-MM-DD HH24:MI:SS TZ') AS backend_start,
    state,
    wait_event_type || ': ' || wait_event AS wait_type_event,
    array_to_string(pg_catalog.pg_blocking_pids(pid), ', ') AS blocking_pids,
    query,
    pg_catalog.to_char(state_change, 'YYYY-MM-DD HH24:MI:SS TZ') AS state_change,
    pg_catalog.to_char(query_start, 'YYYY-MM-DD HH24:MI:SS TZ') AS query_start,
    pg_catalog.to_char(xact_start, 'YYYY-MM-DD HH24:MI:SS TZ') AS xact_start,
    backend_type,
    CASE WHEN state = 'active' THEN ROUND((extract(epoch from now() - query_start) / 60)::numeric, 2) ELSE 0 END AS active_since
FROM
    pg_catalog.pg_stat_activity
WHERE 1=1
    -- datname = (SELECT datname FROM pg_catalog.pg_database WHERE oid = 5)ORDER BY pid
    and state = 'active'
    and wait_event is not null
    order by  wait_type_event;




\qecho '<p></p>'
\qecho '<P><A class=awr name=1613></A>'
\qecho '<H5 class=awr>Функции</H5>'
\qecho '<UL>'
\qecho '<LI class=awr>в порядке убывания суммарного времени выполнения, секунды'
\qecho '</UL>'
\qecho '<p></p>'

SELECT uf.funcid,
       uf.schemaname,
       uf.funcname,
       uf.calls,
       round(uf.total_time / 100)                                  as "total_time_sec",
       round(uf.self_time / 100)                                   as "self_time_sec",
       round((uf.total_time - uf.self_time) / 100)                 as "total-self_sec"
        ,
       round((uf.total_time - uf.self_time) * 100 / uf.total_time) as "total-self_%"
FROM pg_stat_user_functions uf
where uf.total_time > 1000
order by uf.total_time desc
LIMIT 15;


\qecho <P><A class=awr href="#161">Back to Запросы, функции</A> <BR><A class=awr href="#top">Back to Top</A>




