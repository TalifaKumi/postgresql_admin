-- Проверка избыточно установленных расширений по всем БД инстанса, исключая postgres
-- Check for over-installed extensions
-- + Информация обо всех расширениях установленных на каждой пользовательской БД
-- + Каких обязательных расширений не хватает на каждой пользовательской БД
-- File: Over_Installed_Extensions.sql

DO LANGUAGE plpgsql
$$
    DECLARE
      --Cursor over databases  c_dblist CURSOR FOR
      r record;
      vt_port text;
      vi_port integer;
      vt_connection_name text;
      vt_connstr text;
      vt_over_ext_name text;
      vt_ext_name  text;
      vt_miss_ext_name  text;

    BEGIN

IF current_database() = 'postgres' --Только из под postgres
     THEN

         IF public.ver_if_tmp_table_exists('tmp_ov_ins_ext_list') THEN
             TRUNCATE TABLE tmp_ov_ins_ext_list;
         ELSE
             -- Creating temporary table for over-installed extensions
             CREATE TEMPORARY TABLE IF NOT EXISTS tmp_ov_ins_ext_list
             (
                 datname       name,
                 over_ext_name text
             );
         END IF;

         IF public.ver_if_tmp_table_exists('tmp_installed_ext_list') THEN
             TRUNCATE TABLE tmp_installed_ext_list;
         ELSE
             -- Creating temporary table for installed extensions
             CREATE TEMPORARY TABLE IF NOT EXISTS tmp_installed_ext_list
             (
                 datname       name,
                 ext_name      text
             );
         END IF;

         IF public.ver_if_tmp_table_exists('tmp_missing_required_ext_list') THEN
             TRUNCATE TABLE tmp_missing_required_ext_list;
         ELSE
             -- Creating temporary table for missing required extensions extensions
             CREATE TEMPORARY TABLE IF NOT EXISTS tmp_missing_required_ext_list
             (
                 datname       name,
                 ext_name      text
             );
         END IF;

         -- Получить значение порта для коннекта
         SELECT inet_server_port() INTO vi_port;

         -- SELECT setting INTO vi_port FROM pg_settings WHERE name = 'port';
         -- SELECT * FROM pg_settings  WHERE name = 'port';
         -- SELECT * FROM pg_settings WHERE name='listen_addresses';

        FOR r IN select *
                     -- db.datname
                 from pg_database db
                 where db.datistemplate = false
                   and db.datname not in ('postgres')
                   and db.datallowconn =  true -- разрешено подключение
                   -- and db.datacl is not null  -- Есть хоть какие то права доступа

            LOOP

            -- Формируем имя соединения
            vt_connection_name = 'con_ver_pg_to_' ||r.datname;
            if public.ver_if_conn_name_exists(vt_connection_name) then
                         PERFORM public.dblink_disconnect(vt_connection_name);
            end if;

            -- строка соединения
            if vi_port = 5432 then
                vt_connstr = 'dbname=' ||r.datname || ' options=-csearch_path=';
            else
                vt_connstr = 'dbname=' ||r.datname || ' options=-csearch_path=  host=/tmp/ port=' || vi_port::text ;
            end if;

            -- RAISE NOTICE 'Подключение БД: %, vt_connection_name: %, vt_connstr: %', r.datname, vt_connection_name, vt_connstr;

            perform public.dblink_connect(vt_connection_name, vt_connstr);

            -- select public.dblink_connect('con_ver_pg_to_fias', 'dbname=fias options=-csearch_path=');
            --select public.dblink_connect('con_ver_pg_to_ocrmdb', 'dbname=g2g options=-csearch_path=');
            -- select public.dblink_connect('con_ver_pg_to_g2g', 'dbname=g2g options=-csearch_path= host=/tmp/ port=5432');
            -- select public.dblink_disconnect('con_ver_pg_to_fias');

            SELECT over_ext_name
            into vt_over_ext_name
            FROM dblink(vt_connection_name, '
            select STRING_AGG(ex.extname, '', '' order by ex.extname)
            FROM pg_extension ex
            where ex.extname in
                (''pg_alfasys'', ''pg_cron'', ''pg_hint_plan'', ''pg_profile'', ''pg_stat_kcache'', ''pg_stat_statements'',
                    ''pg_store_plans'', ''pg_wait_sampling'', ''system_stats'')
            ') AS t(over_ext_name text);

            /*
            select STRING_AGG (ex.extname,', ' order by ex.extname)
               into vt_over_ext_name
            FROM pg_extension ex
            where ex.extname in
                  ('pg_alfasys', 'pg_cron', 'pg_hint_plan', 'pg_profile', 'pg_stat_kcache', 'pg_stat_statements',
                   'pg_store_plans', 'pg_wait_sampling', 'plpgsql', 'system_stats')  ;
            */

            --RAISE NOTICE 'БД: %, Избыточно установленные расширения: %', r.datname, vt_over_ext_name;
            --IF NOT FOUND THEN
            -- END IF;

            insert into tmp_ov_ins_ext_list(datname, over_ext_name) VALUES (r.datname, vt_over_ext_name);

            SELECT ext_name
            into vt_ext_name
            FROM dblink(vt_connection_name, '
            select STRING_AGG(ex.extname, '', '' order by ex.extname)
            FROM pg_extension ex
            ') AS t(ext_name text);

            -- RAISE NOTICE 'БД: %, Все установленные расширения: %', r.datname, vt_ext_name;

            insert into tmp_installed_ext_list(datname, ext_name) VALUES (r.datname, vt_ext_name);

            WITH compulsory_ex_user_db AS
                     (SELECT *
                      FROM (VALUES ('dblink')
                                 , ('plpgsql')
                              --   , ('sd_tets')
                            ) AS Q (extname)),

                 remote_ext as
                     (select extname
                      from dblink(vt_connection_name, '
                      select extname from pg_extension
                      ') AS t(extname text))

            SELECT STRING_AGG(extname, ', ' order by extname)
            into vt_miss_ext_name
            FROM compulsory_ex_user_db t1
            WHERE NOT EXISTS(SELECT 1 FROM remote_ext t2 WHERE t2.extname = t1.extname);
            -- EXCEPT SELECT extname FROM remote_ext;

            -- RAISE NOTICE 'vt_miss_ext_name: %', vt_miss_ext_name;

            /*select STRING_AGG(ext_name, ', ' order by ext_name)
            into vt_missing_ext_name
            from (select ext_name
                       , extname
                  from tmp_required_ext_list rl
                        left outer join  remote_ext ex on rl.ext_name = ex.extname) a1
             where extname is null
            ;
            */

            -- RAISE NOTICE 'БД: %, Нужно установить расширения: %', r.datname, vt_miss_ext_name;

            insert into tmp_missing_required_ext_list(datname, ext_name) VALUES (r.datname, vt_miss_ext_name);

            PERFORM public.dblink_disconnect(vt_connection_name);
            -- select public.dblink_disconnect('con_ver_pg_to_ocrmdb');

            END LOOP;

    END IF;
END
$$;

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Все установленные на пользовательских базах данных расширения </H5>'
\qecho '<p></p>'

select datname as db, ext_name as List_all_extentons from tmp_installed_ext_list
order by datname;
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Избыточно установленные на пользовательских базах расширения</H5>'
\qecho '<p></p>'

select datname as db, over_ext_name as List_over_setup_extentons from tmp_ov_ins_ext_list
order by datname;
\qecho '<p></p>'


\qecho '<p></p>'
\qecho '<P><A class=awr name=32></A>'
\qecho '<H5 class=awr>Расширения, которые нужно установить на пользовательских базах данных</H5>'
\qecho '<p></p>'

select datname as db, ext_name as List_missing_required_extentons from tmp_missing_required_ext_list
order by datname;
\qecho '<p></p>'


