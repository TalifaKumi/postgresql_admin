\qecho '<P><A class=awr name=181></A>'
\qecho '<H2 class=awr>События ожидания</H2>'

\qecho '<A class=awr_ital>Скрипт WAITING_EVENTS.sql</A>'
\qecho '<p></p>'

\qecho '<A class=awr_ital>Сбросить профиль ожиданий и очистить память расширепния команда SELECT pg_wait_sampling_reset_profile()</A>'
\qecho '<p></p>'


\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>Текущие настройки расширения pg_wait_sampling</H3>'
\qecho '<p></p>'

SELECT *
from pg_catalog.pg_settings
WHERE  NAME LIKE  '%pg_wait_sampling%'
ORDER BY  1;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Типы событий ожидания</H3>'
\qecho '<p></p>'

WITH cnt_snap_shot_ab as (
                       select sum(count) as "sum_snap_shot"
                       FROM pg_wait_sampling_profile
                       ),
cnt_snap_shot_st as (select sum(count) as "sum_snap_shot"
                       FROM pg_wait_sampling_profile
                       WHERE (queryid <> '0' OR queryid IS NOT NULL)
                       ),
all_0 as (SELECT event_type, sum(count) as "sum_snap_shot"
   , round(sum(count) * 100 / (select sum_snap_shot from cnt_snap_shot_ab), 2) as "%Total"
FROM pg_wait_sampling_profile sp
group by  event_type
order by  event_type)

SELECT  * FROM all_0
;


\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Cобытия ожидания, зафиксированные при выполнении запросов</H3>'
\qecho '<p></p>'

WITH cnt_snap_shot as (select sum(count) as "sum_snap_shot"
                       FROM pg_wait_sampling_profile
                       WHERE (queryid <> '0' OR queryid IS NOT NULL))

SELECT st.event_type
     , st.event
     , sum(count)                                                             as "sum_snapshots"
     , round(sum(count) * 100 / (select sum_snap_shot from cnt_snap_shot), 2) as "%Total"
FROM pg_wait_sampling_profile st
WHERE (st.queryid <> '0' OR st.queryid IS NOT NULL)
GROUP BY st.event_type, st.event
ORDER BY st.event_type, st.event;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Cобытия ожидания, для всех backends</H3>'
\qecho '<p></p>'

WITH cnt_snap_shot as (select sum(count) as "sum_snap_shot"
                       FROM pg_wait_sampling_profile)

SELECT st.event_type
     , st.event
     , sum(count)                                                             as "sum_snapshots"
     , round(sum(count) * 100 / (select sum_snap_shot from cnt_snap_shot), 2) as "%Total"
FROM pg_wait_sampling_profile st
GROUP BY st.event_type, st.event
ORDER BY st.event_type, st.event;



\qecho '<p></p>'
\qecho '<P><A class=awr name=1813></A>'
\qecho '<H3 class=awr>Процессы в порядке убывания количества снимков</H3>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 в порядке убывания кроме event_type NOT IN (''Client'') AND event NOT IN (''ClientRead'')'
\qecho '</UL>'
\qecho '<p></p>'

SELECT * FROM pg_wait_sampling_profile sp
WHERE (event_type NOT IN ('Client') AND event NOT IN ('ClientRead'))
order by sp.count DESC
LIMIT 20;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1813></A>'
\qecho '<H3 class=awr>Процессы с ЗАПРОСАМИ в порядке убывания количества снимков</H3>'
\qecho '<p></p>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны первые 20 в порядке убывания кроме event_type NOT IN (''Client'') AND event NOT IN (''ClientRead'')'
\qecho '</UL>'
\qecho '<p></p>'

SELECT * FROM pg_wait_sampling_profile sp
WHERE (event_type NOT IN ('Client') AND event NOT IN ('ClientRead'))
 and sp.queryid <> 0
order by sp.count DESC
LIMIT 20;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1814></A>'
\qecho '<H3 class=awr>События ожидания сгруппированные по  процессам</H3>'
\qecho '<p></p>'

SELECT * FROM pg_wait_sampling_profile sp
order by pid
LIMIT 20;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1815></A>'
\qecho '<H3 class=awr>Хронология cобытий ожидания за последние минуты </H3>'
\qecho '<p></p>'
--\qecho '<UL>'
--\qecho '<LI class=awr>Показаны первые 10 в порядке убывания blks_read'
--\qecho '</UL>'
--\qecho '<p></p>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

SELECT ts, event_type, event,  count(*) as cnt FROM pg_wait_sampling_history pwsh
group by  ts, event_type, event
order by  ts;

\qecho </details>

--SELECT * FROM pg_wait_sampling_history w1 where queryid > 0;
--SELECT * FROM pg_wait_sampling_current;

\qecho <P><A class=awr href="#181">Back to События ожидания</A> <BR><A class=awr href="#top">Back to Top</A>
