
select sample_time
     , round(CAST(NULLIF(active_time / 1000/step_time_sec ::double precision, 0) AS numeric), 2) AS "active_time_sec"
     , round(CAST(NULLIF(idle_in_transaction_time / 1000/step_time_sec ::double precision, 0) AS numeric),2) AS "idle_in_transaction_time_sec"
     --, a1.step_time::interval
     --, step_time_sec
from (
SELECT s.sample_time::text
                    , t.server_id                                                                                   AS server_id
                    , t.datid                                                                                       AS datid
                    , t.datname                                                                                     AS dbname
                    , t.sample_id
                    , t.active_time
                    , t.idle_in_transaction_time
                    ,(select sample_time from profile.samples sa where sa.server_id = t.server_id and sa.sample_id = (t.sample_id -1)) as previous_sample_time
                    ,(s.sample_time - (select sample_time from profile.samples sa where sa.server_id = t.server_id and sa.sample_id = (t.sample_id -1))) as step_time
                    , EXTRACT(EPOCH FROM s.sample_time)
                      -EXTRACT(EPOCH FROM (select sample_time from profile.samples sa where sa.server_id = t.server_id and sa.sample_id = (t.sample_id -1))) as step_time_sec
               FROM profile.sample_stat_database t
                        join profile.samples s on s.server_id = t.server_id and s.sample_id = t.sample_id
               where t.datname = 'ocrmdb'
                 and t.server_id = 1
               order by t.sample_id desc
               LIMIT 200
               ) a1;

with at_all as
         (select a1.sample_time
               , sum(round(CAST(NULLIF(active_time / 1000 / step_time_sec ::double precision, 0) AS numeric),
                           2)) AS "active_time_all_db_s/s"
               --, sum(round(CAST(NULLIF(idle_in_transaction_time / 1000/step_time_sec ::double precision, 0) AS numeric),2)) AS "idle_in_transaction_time_s/s"
               --, a1.step_time::interval
               --, step_time_sec
          from (SELECT s.sample_time::text
                     , t.server_id                                                                               AS server_id
                     , t.datid                                                                                   AS datid
                     , t.datname                                                                                 AS dbname
                     , t.sample_id
                     , t.active_time
                     , t.idle_in_transaction_time
                     , (select sample_time
                        from profile.samples sa
                        where sa.server_id = t.server_id
                          and sa.sample_id = (t.sample_id - 1))                                                  as previous_sample_time
                     , (s.sample_time - (select sample_time
                                         from profile.samples sa
                                         where sa.server_id = t.server_id
                                           and sa.sample_id = (t.sample_id - 1)))                                as step_time
                     , EXTRACT(EPOCH FROM s.sample_time)
                  - EXTRACT(EPOCH FROM (select sample_time
                                        from profile.samples sa
                                        where sa.server_id = t.server_id
                                          and sa.sample_id = (t.sample_id - 1)))                                 as step_time_sec
                FROM profile.sample_stat_database t
                         join profile.samples s on s.server_id = t.server_id and s.sample_id = t.sample_id
                where t.server_id = 1
                order by t.sample_id desc
                   --LIMIT 700
               ) a1
          group by a1.sample_time
          order by a1.sample_time desc),

at_postgres as
         (select a1.sample_time
               , sum(round(CAST(NULLIF(active_time / 1000 / step_time_sec ::double precision, 0) AS numeric),
                           2)) AS "active_time_postgres_s/s"
               --, sum(round(CAST(NULLIF(idle_in_transaction_time / 1000/step_time_sec ::double precision, 0) AS numeric),2)) AS "idle_in_transaction_time_s/s"
               --, a1.step_time::interval
               --, step_time_sec
          from (SELECT s.sample_time::text
                     , t.server_id                                                                               AS server_id
                     , t.datid                                                                                   AS datid
                     , t.datname                                                                                 AS dbname
                     , t.sample_id
                     , t.active_time
                     , t.idle_in_transaction_time
                     , (select sample_time
                        from profile.samples sa
                        where sa.server_id = t.server_id
                          and sa.sample_id = (t.sample_id - 1))                                                  as previous_sample_time
                     , (s.sample_time - (select sample_time
                                         from profile.samples sa
                                         where sa.server_id = t.server_id
                                           and sa.sample_id = (t.sample_id - 1)))                                as step_time
                     , EXTRACT(EPOCH FROM s.sample_time)
                  - EXTRACT(EPOCH FROM (select sample_time
                                        from profile.samples sa
                                        where sa.server_id = t.server_id
                                          and sa.sample_id = (t.sample_id - 1)))                                 as step_time_sec
                FROM profile.sample_stat_database t
                         join profile.samples s on s.server_id = t.server_id and s.sample_id = t.sample_id
                where t.server_id = 1
                      and t.datname = 'postgres'
                order by t.sample_id desc
                   --LIMIT 700
               ) a1
          group by a1.sample_time
          order by a1.sample_time desc),

at_top_1_db as
         (select a1.sample_time
               , sum(round(CAST(NULLIF(active_time / 1000 / step_time_sec ::double precision, 0) AS numeric),
                           2)) AS "active_time_top_1_db_s/s"
               --, sum(round(CAST(NULLIF(idle_in_transaction_time / 1000/step_time_sec ::double precision, 0) AS numeric),2)) AS "idle_in_transaction_time_s/s"
               --, a1.step_time::interval
               --, step_time_sec
          from (SELECT s.sample_time::text
                     , t.server_id                                                                               AS server_id
                     , t.datid                                                                                   AS datid
                     , t.datname                                                                                 AS dbname
                     , t.sample_id
                     , t.active_time
                     , t.idle_in_transaction_time
                     , (select sample_time
                        from profile.samples sa
                        where sa.server_id = t.server_id
                          and sa.sample_id = (t.sample_id - 1))                                                  as previous_sample_time
                     , (s.sample_time - (select sample_time
                                         from profile.samples sa
                                         where sa.server_id = t.server_id
                                           and sa.sample_id = (t.sample_id - 1)))                                as step_time
                     , EXTRACT(EPOCH FROM s.sample_time)
                  - EXTRACT(EPOCH FROM (select sample_time
                                        from profile.samples sa
                                        where sa.server_id = t.server_id
                                          and sa.sample_id = (t.sample_id - 1)))                                 as step_time_sec
                FROM profile.sample_stat_database t
                         join profile.samples s on s.server_id = t.server_id and s.sample_id = t.sample_id
                where t.server_id = 1
                      and t.datname = (select datname
from (select t.datname, round(sum(t.active_time) / 1000) as sum_active_time
      FROM profile.sample_stat_database t
      group by t.datname
      order by 2 desc)
where datname <> 'postgres'
  and sum_active_time > 0
limit 1)
                order by t.sample_id desc
                   --LIMIT 700
               ) a1
          group by a1.sample_time
          order by a1.sample_time desc)

select at_all.*
  , at_postgres."active_time_postgres_s/s"
  , at_top_1_db."active_time_top_1_db_s/s"
from at_all
         join at_postgres on at_all.sample_time = at_postgres.sample_time
         join at_top_1_db on at_all.sample_time = at_top_1_db.sample_time
;


--select * from at_postgres;

;



select *
from (select t.datname, round(sum(t.idle_in_transaction_time) / 1000) as sum_idle_in_transaction_time
      FROM profile.sample_stat_database t
      group by t.datname
      order by 2 desc)
where datname <> 'postgres'
    and sum_idle_in_transaction_time > 0
limit 1;

select datname
from (select t.datname, round(sum(t.active_time) / 1000) as sum_active_time
      FROM profile.sample_stat_database t
      group by t.datname
      order by 2 desc)
where datname <> 'postgres'
  and sum_active_time > 0
limit 1;


select * from profile.samples order by sample_time desc;

select current_setting('pg_profile.topn')::integer;


    SELECT
        st.server_id AS server_id,
        st.datid AS datid,
        st.datname AS dbname,
        sum(xact_commit)::bigint AS xact_commit,
        sum(xact_rollback)::bigint AS xact_rollback,
        sum(blks_read)::bigint AS blks_read,
        sum(blks_hit)::bigint AS blks_hit,
        sum(tup_returned)::bigint AS tup_returned,
        sum(tup_fetched)::bigint AS tup_fetched,
        sum(tup_inserted)::bigint AS tup_inserted,
        sum(tup_updated)::bigint AS tup_updated,
        sum(tup_deleted)::bigint AS tup_deleted,
        sum(temp_files)::bigint AS temp_files,
        sum(temp_bytes)::bigint AS temp_bytes,
        sum(datsize_delta)::bigint AS datsize_delta,
        sum(deadlocks)::bigint AS deadlocks,
        sum(checksum_failures)::bigint AS checksum_failures,
        max(checksum_last_failure)::timestamp with time zone AS checksum_last_failure,
        sum(blk_read_time)/1000::double precision AS blk_read_time,
        sum(blk_write_time)/1000::double precision AS blk_write_time,
        sum(session_time)/1000::double precision AS session_time,
        sum(active_time)/1000::double precision AS active_time,
        sum(idle_in_transaction_time)/1000::double precision AS idle_in_transaction_time,
        sum(sessions)::bigint AS sessions,
        sum(sessions_abandoned)::bigint AS sessions_abandoned,
        sum(sessions_fatal)::bigint AS sessions_fatal,
        sum(sessions_killed)::bigint AS sessions_killed
    FROM sample_stat_database st
    WHERE st.server_id = sserver_id AND NOT datistemplate AND st.sample_id BETWEEN start_id + 1 AND end_id
    GROUP BY st.server_id, st.datid, st.datname

SELECT
        st.datid AS datid,
        COALESCE(st.dbname,'Total') AS dbname,
        NULLIF(sum(st.xact_commit), 0) AS xact_commit,
        NULLIF(sum(st.xact_rollback), 0) AS xact_rollback,
        NULLIF(sum(st.blks_read), 0) AS blks_read,
        NULLIF(sum(st.blks_hit), 0) AS blks_hit,
        NULLIF(sum(st.tup_returned), 0) AS tup_returned,
        NULLIF(sum(st.tup_fetched), 0) AS tup_fetched,
        NULLIF(sum(st.tup_inserted), 0) AS tup_inserted,
        NULLIF(sum(st.tup_updated), 0) AS tup_updated,
        NULLIF(sum(st.tup_deleted), 0) AS tup_deleted,
        NULLIF(sum(st.temp_files), 0) AS temp_files,
        pg_size_pretty(NULLIF(sum(st.temp_bytes), 0)) AS temp_bytes,
        pg_size_pretty(NULLIF(sum(st_last.datsize), 0)) AS datsize,
        pg_size_pretty(NULLIF(sum(st.datsize_delta), 0)) AS datsize_delta,
        NULLIF(sum(st.deadlocks), 0) AS deadlocks,
        round(CAST((sum(st.blks_hit)*100/NULLIF(sum(st.blks_hit)+sum(st.blks_read),0)) AS numeric),2) AS blks_hit_pct,
        NULLIF(sum(st.checksum_failures), 0) AS checksum_failures,
        max(st.checksum_last_failure)::text AS checksum_last_failure,
        round(CAST(NULLIF(sum(st.blk_read_time), 0) AS numeric),2) AS blk_read_time,
        round(CAST(NULLIF(sum(st.blk_write_time), 0) AS numeric),2) AS blk_write_time,
        round(CAST(NULLIF(sum(st.session_time), 0) AS numeric),2) AS session_time,
        round(CAST(NULLIF(sum(st.active_time), 0) AS numeric),2) AS active_time,
        round(CAST(NULLIF(sum(st.idle_in_transaction_time), 0) AS numeric),2) AS idle_in_transaction_time,
        NULLIF(sum(st.sessions), 0) AS sessions,
        NULLIF(sum(st.sessions_abandoned), 0) AS sessions_abandoned,
        NULLIF(sum(st.sessions_fatal), 0) AS sessions_fatal,
        NULLIF(sum(st.sessions_killed), 0) AS sessions_killed,
        -- ordering fields
        row_number() OVER (ORDER BY st.dbname NULLS LAST)::integer AS ord_db
    FROM dbstats(sserver_id, start_id, end_id) st
      LEFT OUTER JOIN sample_stat_database st_last ON
        (st_last.server_id = st.server_id AND st_last.datid = st.datid
          AND st_last.sample_id = end_id)
    GROUP BY GROUPING SETS ((st.datid, st.dbname), ())