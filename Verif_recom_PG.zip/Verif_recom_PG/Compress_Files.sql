-- Сжать все файлы отчетов в один  файл-архив zip
-- \i Compress_Files.sql

-- Формирование полного названия директории, в которой будут сжиматься отчеты
\set vt_out_dir :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_verify
-- \qecho :vt_out_dir

\set vt_out_dir_single_q :vt_single_quotation_mark:vt_out_dir:vt_single_quotation_mark
--\qecho :vt_out_dir_single_q

\set vt_out_dir_dq :vt_single_quotation_mark:vt_double_quotes:vt_out_dir:vt_double_quotes:vt_single_quotation_mark
--\qecho :vt_out_dir_dq

\set vt_out_file_dq :vt_single_quotation_mark:vt_double_quotes:vt_out_file:vt_double_quotes:vt_single_quotation_mark
--\qecho 'vt_out_file_dq: ' :vt_out_file_dq

\set vt_out_file_txt_dq :vt_single_quotation_mark:vt_double_quotes:vt_out_file_txt:vt_double_quotes:vt_single_quotation_mark
--\qecho 'vt_out_file_txt_dq: ' :vt_out_file_txt_dq

\set vt_out_file_primary_profile_dq :vt_single_quotation_mark:vt_double_quotes:vt_out_file_primary_profile:vt_double_quotes:vt_single_quotation_mark
--\qecho 'vt_out_file_profile_dq: ' :vt_out_file_profile_dq

\set vt_out_file_second_profile_dq :vt_single_quotation_mark:vt_double_quotes:vt_out_file_second_profile:vt_double_quotes:vt_single_quotation_mark
\set vt_out_file_third_profile_dq :vt_single_quotation_mark:vt_double_quotes:vt_out_file_third_profile:vt_double_quotes:vt_single_quotation_mark


\set vt_out_csv_file_pg_setting_dq :vt_single_quotation_mark:vt_double_quotes:vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_pg_settings:vt_tail_csv:vt_double_quotes:vt_single_quotation_mark
--\qecho 'vt_out_csv_file_pg_setting_dq: ' :vt_out_csv_file_pg_setting_dq

\set vt_out_zip_file :vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_verify:vt_tail_zip

\set vt_out_zip_file_dq :vt_single_quotation_mark:vt_double_quotes:vt_path_reports:vt_project:vt_:vt_current_db_file:vt_time:vt_verify:vt_tail_zip:vt_double_quotes:vt_single_quotation_mark
--\qecho 'vt_out_zip_file_dq:' :vt_out_zip_file_dq


\set vt_create_dir_zip 'tmp_compress_report_files_into_zip.sql'
-- \qecho 'vt_create_dir_zip:'  :vt_create_dir_zip

\o :vt_create_dir_zip
\pset tuples_only on
\pset border 0
\pset format aligned

-- Создать директорию для файлов, в которой будет упаковка
SELECT '\! md '|| :vt_out_dir_dq ||'';

-- Перенести файлы в директорию для упаковки
SELECT replace('\! move ' || :vt_out_file_dq || ' ' || :vt_out_dir_dq ||'','/','\\');
SELECT replace('\! move ' || :vt_out_file_txt_dq || ' ' || :vt_out_dir_dq ||'','/','\\');
SELECT replace('\! move ' || :vt_out_csv_file_pg_setting_dq || ' ' || :vt_out_dir_dq ||'','/','\\');

SELECT replace('\! move ' || :vt_out_file_primary_profile_dq || ' ' || :vt_out_dir_dq ||'','/','\\');

-- Если второй инстанс существует
\if :vb_is_second_server
SELECT replace('\! move ' || :vt_out_file_second_profile_dq || ' ' || :vt_out_dir_dq ||'','/','\\');
\endif

-- Если третий инстанс существует
\if :vb_is_third_server
SELECT replace('\! move ' || :vt_out_file_third_profile_dq || ' ' || :vt_out_dir_dq ||'','/','\\');
\endif

-- Перейти в директорию с файлами для упаковки
SELECT '\cd '|| :vt_out_dir_single_q ;

-- \cd d:/temp/ALFA_FACTOR_postgres_2025_01_06_20_27_40_verify

SELECT replace('\! tar -a -c -f '|| :vt_out_zip_file_dq ||'','/','\\') || ' *.*';

-- Перейти в директорию со скриптами
-- SELECT '\cd d:/PostgreSQL/SQL/Verif_recom_PG';
\set vt_scripts_dir_single_q :vt_single_quotation_mark:vt_scripts_dir:vt_single_quotation_mark
-- \qecho 'vt_scripts_dir_single_q:' :vt_scripts_dir_single_q

SELECT '\cd '|| replace(:vt_scripts_dir_single_q,'\','/');

-- Удалить директорию для файлов, в которой была упаковка
SELECT '\! rmdir /s /q '|| replace(:vt_out_dir_dq ||'','/','\\');
-- \! rmdir /s /q "d:/temp/af2_ld_06_postgres_2025_01_06_17_47_48_verify/"

\pset tuples_only off
\o
\i :vt_create_dir_zip
\o

\qecho 'Zip file Created:':vt_out_zip_file









