\qecho '<P><A class=awr name=141></A>'
\qecho '<H2 class=awr>БЛОКИРОВКИ</H2>'

\qecho '<A class=awr_ital>Скрипт LOCKS.sql</A>'
\qecho '<p></p>'

select name                      "parameter",
       setting || ' ' || unit as "setting"
        ,
       CASE
           WHEN unit = 's' and to_number(setting, '999G999G999') = 1000 THEN 1
           WHEN unit = 's' and to_number(setting, '999G999G999') <> 1000 THEN 2
           WHEN unit = 'ms' and to_number(setting, '999G999G999') = 1000 THEN 1
           WHEN unit = 'ms' and to_number(setting, '999G999G999') <> 1000 THEN 2
           END                   "check",
       CASE
           WHEN unit = 's' and to_number(setting, '999G999G999') = 1 THEN 'Задано значение по умолчанию 1000 ms'
           WHEN unit = 's' and to_number(setting, '999G999G999') <> 1 THEN 'Задано значение отличное от 1000 ms'
           WHEN unit = 'ms' and to_number(setting, '999G999G999') = 1000 THEN 'Задано значение по умолчанию 1000 ms'
           WHEN unit = 'ms' and to_number(setting, '999G999G999') <> 1000 THEN 'Задано значение отличное от 1000 ms'
           END                   "Comment",
       'Время ожидания блокировки, по истечении которого будет выполняться проверка состояния взаимоблокировки. Если это значение задаётся без единиц измерения, оно считается заданным в миллисекундах. Значение по умолчанию — одна секунда (1s), что близко к минимальному значению, которое стоит применять на практике'
                                 "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'deadlock_timeout'

union


select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '64' THEN 2 ELSE 1 END "check",
       CASE setting
           WHEN '64' THEN ' Количество блокировок на трансакцию задано по умолчанию'
           ELSE ' '
           END                                  "Comment",
       CASE setting
           WHEN 'on'
               THEN
               ''
           ELSE
               'Если используются таблицы с большим количеством партиций - следует увеличить'
           END                                  "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_locks_per_transaction'

union

select name                                     "parameter",
       setting                                  "setting",
       CASE setting WHEN '64' THEN 2 ELSE 2 END "check",
       CASE setting
           WHEN '64' THEN 'Количество предикатных блокировок на трансакцию задано по умолчанию'
           ELSE 'Количество предикатных блокировок на трансакцию задано НЕ по умолчанию'
           END                                  "Comment",

               'В общей таблице предикатных блокировок хранится max_pred_locks_per_transaction объектов (например, таблиц) для каждого серверного процесса или подготовленной транзакции, таким образом, в один момент времени может быть заблокировано не больше этого числа различных объектов. Этот параметр ограничивает среднее число блокировок объектов, используемых каждой транзакцией; отдельные транзакции могут заблокировать и больше объектов, если все они умещаются в таблице блокировок'
                                 "Рекомендации"
        ,
       context
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_pred_locks_per_transaction'
order by "check", "parameter";

--select * from pg_catalog.pg_settings lc_set order by 1;

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Запас по количеству тяжелых блокировок</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Определяется как max_connections * max_locks_per_transaction '
\qecho '</UL>'

with mlpt as
(select setting::numeric as cnt
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_locks_per_transaction'),
max_con as
(select setting::numeric as cnt
from pg_catalog.pg_settings lc_set
where lc_set.name = 'max_connections'),
curr_lock as
(select count(*) cnt from pg_locks)
select mlpt.cnt * max_con.cnt as "reserve for the number of heavy blockings", curr_lock.cnt as "current_locks" from  mlpt, max_con, curr_lock;

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Количество объектов по режимам(mode) блокировки</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

select lo.mode, count(*)
from pg_locks lo
group by lo.mode
order by lo.mode;

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Количество объектов по типам(locktype) блокировки</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

select locktype, count(*) from pg_locks
group by locktype;

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Количество процессов, ожидающих получение блокировки</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'


WITH q AS (SELECT clock_timestamp() - l.waitstart AS wait_age
           FROM pg_stat_activity a,
                pg_locks l
           WHERE a.pid = l.pid
             AND NOT l.granted)
select count(*) from
(
SELECT clock_timestamp()::timestamp,
       count(*)                               as process_cnt,
       coalesce(max(wait_age), '0'::interval) AS max_wait,
       coalesce(sum(wait_age), '0'::interval) AS sum_wait_all_process_cnt
FROM q);

\qecho '<p></p>'

WITH q AS (SELECT clock_timestamp() - l.waitstart AS wait_age
           FROM pg_stat_activity a,
                pg_locks l
           WHERE a.pid = l.pid
             AND NOT l.granted)
SELECT clock_timestamp()::timestamp,
       count(*)                               as process_cnt,
       coalesce(max(wait_age), '0'::interval) AS max_wait,
       coalesce(sum(wait_age), '0'::interval) AS sum_wait_all_process_cnt
FROM q;



\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Количество fastpath по различным объектам и режимам(mode) блокировки</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

with a2 as(
select     locktype
           , datname
           , relname
           , page
           , tuple
           , mode
           , CASE
                 WHEN granted = true THEN 'Получена'
                 WHEN granted = false THEN 'Ждет'
            END           as "granted"
           --, granted
           , waitstart
           , pid
           , virtualtransaction
           --, locktype
           , usename
           , application_name
           , client_hostname
           , wait_event
           , state
           , backend_type
           , fastpath
           , query_id
           --, query
      from (select lo.*
                 , (select datname from pg_database where oid = lo.database)
                 , (select relname from pg_class where oid = lo.relation)
                 , sa.usename
                 , sa.application_name
                 , sa.client_hostname
                 , sa.wait_event
                 , sa.state
                 , sa.backend_type
                 , sa.query_id
                 , sa.query
            from pg_locks lo
                     join pg_catalog.pg_stat_activity sa on lo.pid = sa.pid
               -- where relation is not null
           ) a1)

-- select * from a2;

select a2.locktype
     , a2.datname
     , a2.relname
     , a2.page
     , a2.tuple
     , a2.mode
     , a2.wait_event
     , a2.state
     , a2.backend_type
     , a2.fastpath
     , count(*)
from a2
group by a2.locktype
     , a2.datname
     , a2.relname
     , a2.page
     , a2.tuple
     , a2.mode
     , a2.wait_event
     , a2.state
     , a2.backend_type
     , a2.fastpath
order by a2.locktype
     , a2.datname
     , a2.relname
     , a2.page
     , a2.tuple
     , a2.mode
     , a2.wait_event
     , a2.state
     , a2.backend_type
     , a2.fastpath;

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Количество fastpath по сессиям</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

with a2 as(
select     locktype
           , datname
           , relname
           , page
           , tuple
           , mode
           , CASE
                 WHEN granted = true THEN 'Получена'
                 WHEN granted = false THEN 'Ждет'
            END           as "granted"
           --, granted
           , waitstart
           , pid
           , virtualtransaction
           --, locktype
           , usename
           , application_name
           , client_hostname
           , wait_event
           , state
           , backend_type
           , fastpath
           , query_id
           --, query

      from (select lo.*
                 , (select datname from pg_database where oid = lo.database)
                 , (select relname from pg_class where oid = lo.relation)
                 , sa.usename
                 , sa.application_name
                 , sa.client_hostname
                 , sa.wait_event
                 , sa.state
                 , sa.backend_type
                 , sa.query_id
                 , sa.query
            from pg_locks lo
                     join pg_catalog.pg_stat_activity sa on lo.pid = sa.pid
               -- where relation is not null
           ) a1)

select pid, state,  fastpath , count(*) from a2
group by  pid, state, fastpath
order by pid, state, fastpath
;


\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Заблокированные объекты по режимам(mode) блокировки</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

\qecho <details>
\qecho   <summary>Раскрыть</summary>

select locktype as "locktype"
     , datname
     , relname
     , page
     , tuple
     , mode
     , CASE
           WHEN granted = true THEN 'Получена'
           WHEN granted = false THEN 'Ждет'
    END         as "granted"
     --, granted
     , waitstart
     , pid
     , virtualtransaction
     , locktype
     , usename
     , application_name
     , client_hostname
     , wait_event
     , state
     , backend_type
     , fastpath
     , query_id
     --, query
from (select lo.*
           , (select datname from pg_database where oid = lo.database)
           , (select relname from pg_class where oid = lo.relation)
           , sa.usename
           , sa.application_name
           , sa.client_hostname
           , sa.wait_event
           , sa.state
           , sa.backend_type
           , sa.query_id
           , sa.query
      from pg_locks lo
               join pg_catalog.pg_stat_activity sa on lo.pid = sa.pid
         -- where relation is not null
     ) a1
order by mode;

\qecho </details>

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Времена ожидания всех процессов, ожидающих получение блокировки</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

SELECT clock_timestamp()::timestamp,
       a.pid,
       a.state,
       l.granted,
       a.wait_event || '.' || a.wait_event_type AS wait,
       clock_timestamp() - l.waitstart          AS wait_age
FROM pg_stat_activity a,
     pg_locks l
WHERE a.pid = l.pid
  AND NOT l.granted;

\qecho '<p></p>'
\qecho '<P><A class=awr name=143></A>'
\qecho '<H3 class=awr>Дерево блокировок</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'
\qecho '<p></p>'

-- Добалено имя заблокированного relation
WITH RECURSIVE
    l AS (SELECT pid,
                 locktype,
                 mode,
                 granted,
                 relation as                                                                                 "relation_oid",
                 ROW (locktype,database,relation,page,tuple,virtualxid,transactionid,classid,objid,objsubid) obj
          FROM pg_locks),
    pairs AS (SELECT w.pid             waiter
                   , l.pid             locker
                   , l.obj
                   , l.mode
                   , l.granted
                   , l.relation_oid as "relation_oid_l"
                   , w.relation_oid as "relation_oid_w"
              FROM l w
                       JOIN l ON l.obj IS NOT DISTINCT FROM w.obj AND l.locktype = w.locktype AND NOT l.pid = w.pid AND
                                 l.granted
              WHERE NOT w.granted),
    tree AS (SELECT l.locker                    pid
                  , l.locker                    root
                  , NULL::record                obj
                  , NULL      AS                mode
                  , 0                           lvl
                  , locker::text                path
                  , array_agg(l.locker) OVER () all_pids
                  , NULL::oid AS                relation_oid_l
                  , NULL::oid AS                relation_oid_w
             FROM (SELECT DISTINCT locker FROM pairs l WHERE NOT EXISTS(SELECT 1 FROM pairs WHERE waiter = l.locker)) l
             UNION ALL
             SELECT w.waiter pid
                  , tree.root
                  , w.obj
                  , w.mode
                  , tree.lvl + 1
                  , tree.path || '.' || w.waiter
                  , all_pids || array_agg(w.waiter) OVER ()
                  , w.relation_oid_l
                  , w.relation_oid_w
             FROM tree
                      JOIN pairs w ON tree.pid = w.locker AND NOT w.waiter = ANY (all_pids))

-- select * from pairs
-- select * from tree
-- select * from tree

SELECT
--(clock_timestamp() - a.xact_start)::interval(3) AS ts_age
    to_char(localtimestamp - a.xact_start, 'DD HH24:MI:SS:MS')    AS                              "xact_dur"
     , replace(a.state, 'idle in transaction', 'idletx')                                          state
     --(clock_timestamp() - state_change)::interval(3) AS change_age,
     , to_char(localtimestamp - state_change, 'DD HH24:MI:SS:MS') AS                              "change_age"
     , tree.pid
     , tree.root                                                  as                              "root_pid"
     , tree.path                                                  as                              "path_pid"
     --, tree.relation_oid_l, tree.relation_oid_w
     , a.datname
     , (select relname as "relname_l" from pg_class where oid = tree.relation_oid_l)
     , (select relname as "relname_w" from pg_class where oid = tree.relation_oid_w)
     , tree.obj
     , tree.mode
     -- , tree.all_pids
     , a.usename
     , a.client_addr
     , lvl
     , (SELECT count(*) FROM tree p WHERE p.path ~ ('^' || tree.path) AND NOT p.path = tree.path) blocked
     , repeat(' .', lvl) || ' ' || left(regexp_replace(query, '\s+', ' ', 'g'), 100)              query
FROM tree
         JOIN pg_stat_activity a USING (pid)
ORDER BY path;

\qecho '<p></p>'
\qecho '<P><A class=awr name=142></A>'
\qecho '<H3 class=awr>Объекты заблокированные процессами из дерева блокировок</H3>'
\qecho '<UL>'
\qecho '<LI class=awr>Показаны на момент формирования отчета'
\qecho '</UL>'

select locktype as "locktype"
     , datname
     , relname
     , page
     , tuple
     , mode
     , CASE
           WHEN granted = true THEN 'Получена'
           WHEN granted = false THEN 'Ждет'
    END         as "granted"
     --, granted
     , waitstart
     , pid
     , virtualtransaction
     , locktype
     , usename
     , application_name
     , client_hostname
     , wait_event
     , state
     , backend_type
     , fastpath
     , query_id
     --, query
from (select lo.*
           , (select datname from pg_database where oid = lo.database)
           , (select relname from pg_class where oid = lo.relation)
           , sa.usename
           , sa.application_name
           , sa.client_hostname
           , sa.wait_event
           , sa.state
           , sa.backend_type
           , sa.query_id
           , sa.query
      from pg_locks lo
               join pg_catalog.pg_stat_activity sa on lo.pid = sa.pid
      where relation is not null) a1
where a1.pid in (WITH RECURSIVE
                     l AS (SELECT pid,
                                  locktype,
                                  mode,
                                  granted,
                                  relation as                                                                                 "relation_oid",
                                  ROW (locktype,database,relation,page,tuple,virtualxid,transactionid,classid,objid,objsubid) obj
                           FROM pg_locks),
                     pairs AS (SELECT w.pid             waiter
                                    , l.pid             locker
                                    , l.obj
                                    , l.mode
                                    , l.granted
                                    , l.relation_oid as "relation_oid_l"
                                    , w.relation_oid as "relation_oid_w"
                               FROM l w
                                        JOIN l ON l.obj IS NOT DISTINCT FROM w.obj AND l.locktype = w.locktype AND
                                                  NOT l.pid = w.pid AND l.granted
                               WHERE NOT w.granted),
                     tree AS (SELECT l.locker                    pid
                                   , l.locker                    root
                                   , NULL::record                obj
                                   , NULL      AS                mode
                                   , 0                           lvl
                                   , locker::text                path
                                   , array_agg(l.locker) OVER () all_pids
                                   , NULL::oid AS                relation_oid_l
                                   , NULL::oid AS                relation_oid_w
                              FROM (SELECT DISTINCT locker
                                    FROM pairs l
                                    WHERE NOT EXISTS(SELECT 1 FROM pairs WHERE waiter = l.locker)) l
                              UNION ALL
                              SELECT w.waiter pid
                                   , tree.root
                                   , w.obj
                                   , w.mode
                                   , tree.lvl + 1
                                   , tree.path || '.' || w.waiter
                                   , all_pids || array_agg(w.waiter) OVER ()
                                   , w.relation_oid_l
                                   , w.relation_oid_w
                              FROM tree
                                       JOIN pairs w ON tree.pid = w.locker AND NOT w.waiter = ANY (all_pids))

-- select * from pairs
-- select * from tree
-- select * from tree

                 SELECT tree.pid
                        --, tree.root as "root_pid",
                 FROM tree
                          JOIN pg_stat_activity a USING (pid)
                 ORDER BY path)
order by pid;


\qecho <P><A class=awr href="#141">Back to БЛОКИРОВКИ</A> <BR><A class=awr href="#top">Back to Top</A>

