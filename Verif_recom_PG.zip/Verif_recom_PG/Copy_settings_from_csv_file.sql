-- Копировние настроек инстанса из внешнего файла csv в таблицу public.ver_imported_pg_settings
-- Скрипт Copy_settings_from_csv_file.sql

DO LANGUAGE plpgsql
$$
     DECLARE
      vt_string text;
    BEGIN
         -- RAISE NOTICE 'priznak: %', public.ver_if_table_exists('public','ver_imported_pg_settings') ;
         IF public.ver_if_table_exists('public','ver_imported_pg_settings') THEN
            --  RAISE NOTICE 'priznak: TRUNCATE ' ;
             TRUNCATE TABLE public.ver_imported_pg_settings;
         ELSE
             -- Creating table for comparing settings
             CREATE TABLE IF NOT EXISTS public.ver_imported_pg_settings AS select * from pg_catalog.pg_settings WHERE name ='000';
         END IF;
END
$$;

\o
\set vt_out_csv_file_pg_setting '''example_settings_01.csv'''
-- \qecho ':vt_out_csv_file_pg_setting' :vt_out_csv_file_pg_setting
\set vt_copy_settings_from_csv_file 'tmp_copy_settings_from_csv_file.sql'
-- \qecho ':vt_copy_settings_from_csv_file'  :vt_copy_settings_from_csv_file

\o :vt_copy_settings_from_csv_file
\pset tuples_only on
\pset border 0
\pset format aligned
-- SELECT '\COPY public.ver_imported_pg_settings FROM '''|| :vt_out_file_pg_setting_csv ||''' CSV HEADER;';
SELECT '\COPY public.ver_imported_pg_settings FROM '|| :vt_out_csv_file_pg_setting ||' CSV HEADER;';
\pset tuples_only off
\o
\i :vt_copy_settings_from_csv_file
\o

\qecho 'Finished copying instance settings from external example_settings_01.csv file to public.ver_imported_pg_settings table'

-- Запросы для отладки
--select count(*) from  public.ver_imported_pg_settings;
-- truncate table  public.ver_imported_pg_settings;





