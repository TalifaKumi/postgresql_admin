DO
$do$

DECLARE
	--Cursor for db stats
	c_dblist CURSOR FOR
	SELECT datname FROM pg_catalog.pg_database dbs where not datistemplate and datallowconn;

	qres				record;
	connstr				text;
	db_connstr			text;
	t_query				text;
	t_query_grants		text;
	create_rol_name		text;


BEGIN
	create_rol_name := 'rol_capacity';

	IF EXISTS (
		SELECT FROM pg_catalog.pg_roles
		WHERE  rolname = create_rol_name)
	THEN
		RAISE NOTICE 'Role % already exists. Skipping.', create_rol_name;
		EXECUTE 'grant pg_monitor to "' || create_rol_name || '"';
	ELSE
		EXECUTE 'CREATE ROLE "'|| create_rol_name ||'"';
		EXECUTE 'grant pg_monitor to "' || create_rol_name || '"';
	END IF;
   
	IF (select floor(setting::numeric) from pg_settings where name = 'server_version') >= 14
	THEN
		EXECUTE 'grant pg_read_all_data to "' || create_rol_name || '"';
	ELSE

		-- Adding dblink extension schema to search_path if it does not already there
		SELECT extnamespace::regnamespace AS dblink_schema INTO STRICT qres FROM pg_catalog.pg_extension WHERE extname = 'dblink';
		IF NOT string_to_array(current_setting('search_path'),',') @> ARRAY[qres.dblink_schema::text] THEN
			EXECUTE 'SET LOCAL search_path TO ' || qres.dblink_schema||','|| current_setting('search_path');
		END IF;
		-- Disconnecting existing connection
		IF dblink_get_connections() @> ARRAY['db_connstr'] THEN
			PERFORM dblink_disconnect(db_connstr);
		END IF;



		t_query := 'WITH rolname AS ( select rolname from  pg_catalog.pg_roles where rolname = ''' || create_rol_name || ''') '
'select ''GRANT USAGE ON SCHEMA "''||schema_name||''"  TO ''||(select rolname from rolname)|| '';'' from information_schema.schemata '
'union all '
'select ''GRANT SELECT ON ALL TABLES IN SCHEMA "''||schema_name||''"  TO ''||(select rolname from rolname)||'';'' from information_schema.schemata '
'union all '
'select ''ALTER DEFAULT PRIVILEGES IN SCHEMA "''||schema_name||''" GRANT SELECT ON TABLES TO ''||(select rolname from rolname)||'';'' from information_schema.schemata '
;
		connstr := (select 'port='||current_setting('port'));
		--RAISE NOTICE 'Подключаемся к БД %', t_query;

		FOR qres IN c_dblist
		LOOP
			db_connstr := concat_ws(' ',connstr, format($o$dbname=%s$o$,replace(qres.datname,$o$'$o$,$o$\'$o$)));
			--RAISE NOTICE 'Подключаемся к БД %', db_connstr;
			FOR t_query_grants IN select grants from dblink(db_connstr, t_query) as grants(grants text)
			LOOP
				PERFORM dblink_exec(db_connstr, t_query_grants);
				--RAISE NOTICE 'в БД % выдаем %', qres, t_query_grants;
			END LOOP;

		END LOOP;
	END IF;
END
$do$;
