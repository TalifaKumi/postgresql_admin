-- Проверить версии функций, обновить версии и создать функции, если их нет

DO LANGUAGE plpgsql
$$
    DECLARE

    BEGIN


        --SELECT

            perform
            n.nspname,
            p.proname,
            p.proargnames,
            p.prosrc
        FROM pg_proc p
                 LEFT JOIN pg_catalog.pg_namespace n ON n.oid
            = p.pronamespace
        WHERE LOWER(n.nspname) = 'public'
          AND LOWER(p.proname) = 'ver_if_func_exists'
          AND p.prosrc ILIKE '%v.1.1%';

        IF NOT FOUND THEN

            -- Create or recreate a function to check for the existence of functions

            CREATE OR REPLACE FUNCTION public.ver_if_func_exists(
                p_nspname text,
                p_proname text,
                p_version text
            )
                RETURNS boolean
                LANGUAGE plpgsql
                VOLATILE
            AS
            $BODY$
            BEGIN
                /* check the function exist in database v.1.1
                   select public.ver_if_func_exists('public','ver_if_func_exists','v.1.1');
               */
                PERFORM 1
                FROM pg_proc p
                         JOIN pg_namespace n ON p.pronamespace = n.oid
                WHERE n.nspname = LOWER(p_nspname)
                  AND p.proname = LOWER(p_proname)
                  AND (p_version IS NULL OR p.prosrc ILIKE '%' || p_version || '%');

                RETURN FOUND;
            END;
            $BODY$;

        END IF;

        /*
        select d.description, p.* FROM pg_proc p
                left join pg_description d on p.oid =d.objoid
                where p.proname  = 'ver_if_func_exists';

        select * from pg_description;
        COMMENT ON FUNCTION public.ver_if_func_exists(varchar,varchar,varchar) IS NULL;
        COMMENT ON FUNCTION public.ver_if_func_exists(varchar,varchar,varchar) IS '01.01';
         */

/* Проверка наличия актуальной версии, обновление, добавлениие функций, удаление старых версий функций */

        IF public.ver_if_func_exists('public', 'ver_if_table_exists', 'v.1.0') THEN
            DROP FUNCTION IF EXISTS ver_if_table_exists(varchar);
        END IF;

        IF public.ver_if_func_exists('public', 'ver_if_table_exists', 'v.1.1') THEN
            --  RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_if_table_exists(p_nspname varchar, p_tablename varchar)
                RETURNS pg_catalog.bool AS
            $BODY$
            DECLARE
            BEGIN

                /* check the table exist in database and is visible v.1.1

                   select public.ver_if_table_exists('public','ver_imported_pg_settings');
               */

                perform n.nspname, c.relname
                FROM pg_catalog.pg_class c
                         LEFT JOIN pg_catalog.pg_namespace n ON n.oid
                    = c.relnamespace
                where n.nspname = p_nspname
                  AND pg_catalog.pg_table_is_visible(c.oid)
                  AND Upper(relname) = Upper(p_tablename);

                IF FOUND THEN
                    RETURN TRUE;
                ELSE
                    RETURN FALSE;
                END IF;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;


        IF public.ver_if_func_exists('public', 'ver_if_tmp_table_exists', 'v.1.0') THEN
            --  RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            create function public.ver_if_tmp_table_exists(character varying) returns boolean
            as
            $BODY$
            DECLARE
            BEGIN

                /* check the table exist in database and is visible v.1.0

               select public.ver_if_tmp_table_exists('tmp_ov_ins_ext_list');
               */

                perform n.nspname, c.relname
                FROM pg_catalog.pg_class c
                         LEFT JOIN pg_catalog.pg_namespace n ON n.oid
                    = c.relnamespace
                where n.nspname like 'pg_temp_%'
                  AND pg_catalog.pg_table_is_visible(c.oid)
                  AND Upper(relname) = Upper($1);

                IF FOUND THEN
                    RETURN TRUE;
                ELSE
                    RETURN FALSE;
                END IF;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;


-- ver_if_conn_name_exists ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_if_conn_name_exists', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_if_conn_name_exists(p_conn_name varchar)
                RETURNS pg_catalog.bool AS
            $BODY$
            DECLARE
                vt_get_all_con_name text[];

            BEGIN

                /* check the p_conn_name exist  v.1.0
                   select public.ver_if_conn_name_exists('con_ver_pg_to_ocrmdb');
               */

                vt_get_all_con_name := (SELECT public.dblink_get_connections()::text[]);

                IF vt_get_all_con_name::text[] is null
                THEN
                    RETURN FALSE;
                ELSE

                    IF array_position(vt_get_all_con_name, p_conn_name) > 0
                    THEN
                        RETURN TRUE;
                    ELSE
                        RETURN FALSE;
                    END IF;
                END IF;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;

-- ver_get_profile_primary_server_id ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_profile_primary_server_id', 'v.1.1') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_get_profile_primary_server_id()
                RETURNS integer AS
            $BODY$
            DECLARE
                vc_host_from_conninfo        varchar(128);
                vi_profile_primary_server_id integer;

            BEGIN

                /* ver_get_profile_primary_server_id  v.1.1
                   select public.ver_get_profile_primary_server_id();
               */

                -- Extracting host from primary_conninfo using regular expression
                SELECT substring(setting FROM 'host=([^\s]+)')
                INTO vc_host_from_conninfo
                FROM pg_settings
                WHERE name = 'primary_conninfo';

                IF vc_host_from_conninfo IS NOT NULL THEN

                    -- Search for a server with host in connstr (with explicit result limitation)
                    SELECT server_id
                    INTO vi_profile_primary_server_id
                    FROM profile.servers
                    WHERE connstr LIKE '%' || vc_host_from_conninfo || '%'
                      and enabled is true
                    LIMIT 1;

                    IF NOT FOUND THEN
                        -- RAISE EXCEPTION 'Сервер с host=% не найден', vc_host_from_conninfo;

                        SELECT server_id
                        INTO vi_profile_primary_server_id
                        FROM profile.servers
                        WHERE enabled is true
                        ORDER BY server_name
                        LIMIT 1;

                    END IF;

                ELSE
                    -- RAISE EXCEPTION 'Параметр primary_conninfo не настроен';
                    SELECT server_id
                    INTO vi_profile_primary_server_id
                    FROM profile.servers
                    WHERE enabled is true
                    ORDER BY server_name
                    LIMIT 1;
                END IF;

                return vi_profile_primary_server_id;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;

-- ver_get_profile_primary_server_name ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_profile_primary_server_name', 'v.1.1') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE OR REPLACE FUNCTION public.ver_get_profile_primary_server_name()
                RETURNS varchar AS
            $BODY$
            DECLARE
                vc_host_from_conninfo          varchar(128);
                vc_profile_primary_server_name varchar(128) := NULL;
            BEGIN
                /* ver_get_profile_primary_server_name  v.1.1
                   select public.ver_get_profile_primary_server_name();
                */

                -- Extracting host from primary_conninfo using regular expression
                SELECT substring(setting FROM 'host=([^\s]+)')
                INTO vc_host_from_conninfo
                FROM pg_settings
                WHERE name = 'primary_conninfo';

                IF vc_host_from_conninfo IS NOT NULL THEN

                    -- Search for a server with host in connstr (with explicit result limitation)
                    SELECT server_name
                    INTO vc_profile_primary_server_name
                    FROM profile.servers
                    WHERE connstr LIKE '%' || vc_host_from_conninfo || '%'
                      and enabled is true
                    LIMIT 1;

                    IF NOT FOUND THEN
                        -- RAISE EXCEPTION 'Сервер с host=% не найден', vc_host_from_conninfo;

                        SELECT server_name
                        INTO vc_profile_primary_server_name
                        FROM profile.servers
                        WHERE enabled is true
                        ORDER BY server_name
                        LIMIT 1;

                    END IF;

                ELSE
                    -- RAISE EXCEPTION 'Параметр primary_conninfo не настроен';
                    SELECT server_name
                    INTO vc_profile_primary_server_name
                    FROM profile.servers
                    WHERE enabled is true
                    ORDER BY server_name
                    LIMIT 1;
                END IF;

                RETURN vc_profile_primary_server_name;
            END;
            $BODY$
                LANGUAGE plpgsql VOLATILE;

        END IF;

-- ver_get_profile_second_server_id ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_profile_second_server_id', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_get_profile_second_server_id()
                RETURNS integer AS
            $BODY$
            DECLARE
                vi_profile_second_server_id integer;
                vi_cnt_profile_servers      integer;

            BEGIN

                /* ver_get_profile_second_server_id  v.1.0
                   select public.ver_get_profile_second_server_id();
               */

                vi_cnt_profile_servers := (SELECT count(*) FROM profile.servers WHERE  enabled is true);

                IF vi_cnt_profile_servers > 1 THEN

                    vi_profile_second_server_id := (SELECT server_id
                                                    FROM profile.servers s
                                                    where server_id <> public.ver_get_profile_primary_server_id()
                                                                          and enabled is true
                                                    order by server_name
                                                    limit 1);
                ELSE
                    vi_profile_second_server_id := NULL;
                end if;

                return vi_profile_second_server_id;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;



-- ver_get_profile_second_server_name ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_profile_second_server_name', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_get_profile_second_server_name()
                RETURNS varchar AS
            $BODY$
            DECLARE
                vc_profile_second_server_name varchar(128);
                vi_cnt_profile_servers        integer;

            BEGIN

                /* ver_get_profile_second_server_name  v.1.0
                   select public.ver_get_profile_second_server_name();

               */

                vi_cnt_profile_servers := (SELECT count(*) FROM profile.servers where enabled is true);

                IF vi_cnt_profile_servers > 1 THEN


                    vc_profile_second_server_name := (SELECT server_name
                                                      FROM profile.servers s
                                                      where server_id <> public.ver_get_profile_primary_server_id()
                                                                             and enabled is true
                                                      order by server_name
                                                      limit 1);
                ELSE

                    vc_profile_second_server_name := NULL;

                end if;

                return vc_profile_second_server_name;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;


-- ver_get_profile_third_server_id ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_profile_third_server_id', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_get_profile_third_server_id()
                RETURNS integer AS
            $BODY$
            DECLARE
                vi_profile_third_server_id integer;
                vi_cnt_profile_servers     integer;

            BEGIN

                /* ver_get_profile_third_server_id  v.1.0
                   select public.ver_get_profile_third_server_id();
               */

                vi_cnt_profile_servers := (SELECT count(*) FROM profile.servers where enabled is true);

                IF vi_cnt_profile_servers > 2 THEN

                    vi_profile_third_server_id := (SELECT server_id
                                                   FROM profile.servers s
                                                   where server_id not in (public.ver_get_profile_primary_server_id(),
                                                                           public.ver_get_profile_second_server_id())
                                                   and enabled is true
                                                   order by server_name
                                                   limit 1);
                ELSE
                    vi_profile_third_server_id := NULL;
                end if;

                return vi_profile_third_server_id;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;

-- ver_get_profile_third_server_name ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_profile_third_server_name', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE or REPLACE FUNCTION public.ver_get_profile_third_server_name()
                RETURNS varchar AS
            $BODY$
            DECLARE
                vc_profile_third_server_name varchar(128);
                vi_cnt_profile_servers       integer;

            BEGIN

                /* ver_get_profile_third_server_name  v.1.0
                   select public.ver_get_profile_third_server_name();

               */

                vi_cnt_profile_servers := (SELECT count(*) FROM profile.servers where enabled is true);

                IF vi_cnt_profile_servers > 2 THEN


                    vc_profile_third_server_name := (SELECT server_name
                                                     FROM profile.servers s
                                                     where server_id not in (public.ver_get_profile_primary_server_id(),
                                                                             public.ver_get_profile_second_server_id())
                                                     and enabled is true
                                                     order by server_name
                                                     limit 1);
                ELSE

                    vc_profile_third_server_name := NULL;

                end if;

                return vc_profile_third_server_name;

            END;
            $BODY$
                LANGUAGE 'plpgsql' VOLATILE;

        END IF;

-- SELECT public.ver_if_func_exists('public', 'ver_get_end_sample_id', 'v.1.0') ;

-- ver_get_end_sample_id ---------------------------------------------------------

        IF public.ver_if_func_exists('public', 'ver_get_end_sample_id', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE


        CREATE OR REPLACE FUNCTION public.ver_get_end_sample_id(
            p_server_id integer
        )
            RETURNS integer
            LANGUAGE plpgsql
            VOLATILE
        AS
        $BODY$
        DECLARE
            vi_end_sample_id integer;
        BEGIN
             /* Getting the most recent snapshot number for a specific server_id v.1.0
               select public.ver_get_end_sample_id(1);
           */

            SELECT sample_id
            INTO vi_end_sample_id
            FROM profile.samples
            WHERE server_id = p_server_id
            ORDER BY sample_time DESC, sample_id DESC
            LIMIT 1;

            -- Обработка отсутствия данных
            IF vi_end_sample_id IS NULL THEN
                RAISE EXCEPTION 'No samples found for server_id: %', p_server_id;
                -- Или вернуть значение по умолчанию:
                -- RETURN -1;
            END IF;

            RETURN vi_end_sample_id;
        END;
        $BODY$;

END IF;


-- ver_get_second_to_last_sample_id ---------------------------------------------------------

-- SELECT public.ver_if_func_exists('public', 'ver_get_second_to_last_sample_id', 'v.1.0');

        IF public.ver_if_func_exists('public', 'ver_get_second_to_last_sample_id', 'v.1.0') THEN
            -- RAISE NOTICE 'function ver_if_table_exists already exists';
        ELSE
            CREATE OR REPLACE FUNCTION public.ver_get_second_to_last_sample_id(
                p_server_id integer
            )
                RETURNS integer
                LANGUAGE plpgsql
                VOLATILE
            AS
            $BODY$
            DECLARE
                vi_second_to_last_sample_id integer;
                vi_record_count             integer;
            BEGIN
                /* Getting the second to last snapshot number for a specific server_id v.1.0
                   select public.ver_get_second_to_last_sample_id(1);
                */

                -- Проверяем, что есть как минимум две записи
                SELECT COUNT(*)
                INTO vi_record_count
                FROM profile.samples
                WHERE server_id = p_server_id;

                IF vi_record_count < 2 THEN
                    RAISE EXCEPTION 'Not enough samples (found: %) for server_id: %',
                        vi_record_count, p_server_id;
                END IF;

                -- Получаем предпоследний sample_id
                SELECT sample_id
                INTO vi_second_to_last_sample_id
                FROM (SELECT sample_id,
                             sample_time,
                             ROW_NUMBER() OVER (ORDER BY sample_time DESC, sample_id DESC) AS rn
                      FROM profile.samples
                      WHERE server_id = p_server_id) AS sub
                WHERE rn = 2;

                RETURN vi_second_to_last_sample_id;
            END;
            $BODY$;

        END IF;


-- Завершение всего скрипта
    END
$$;

