WITH sch AS (SELECT 'public'::text sch -- schema
)
   , def AS (SELECT clr.relname                                      nmt
                  , cli.relname                                      nmi
                  , pg_get_indexdef(cli.oid)                         def
                  , cli.oid                                          clioid
                  , clr
                  , cli
                  , idx
                  , (SELECT array_agg(T::text ORDER BY f.i)
                     FROM (SELECT clr.oid       rel
                                , i
                                , idx.indkey[i] ik
                           FROM generate_subscripts(idx.indkey, 1) i) f
                              JOIN
                          pg_attribute T
                          ON (T.attrelid, T.attnum) = (f.rel, f.ik)) fld$
                  , (SELECT array_agg(replace(opcname::text, '_ops', '') ORDER BY f.i)
                     FROM (SELECT clr.oid         rel
                                , i
                                , idx.indclass[i] ik
                           FROM generate_subscripts(idx.indclass, 1) i) f
                              JOIN
                          pg_opclass T
                          ON T.oid = f.ik)                           opc$
             FROM pg_class clr
                      JOIN
                  pg_index idx
                  ON idx.indrelid = clr.oid
                      JOIN
                  pg_class cli
                  ON cli.oid = idx.indexrelid
                      JOIN
                  pg_namespace nsp
                  ON nsp.oid = cli.relnamespace AND
                     nsp.nspname = (TABLE sch)
             WHERE NOT idx.indisunique
               AND idx.indisready
               AND idx.indisvalid
             ORDER BY clr.relname, cli.relname)
   , fld AS (SELECT *
                  , ARRAY(
            SELECT (att::pg_attribute).attname
            FROM unnest(fld$) att
        ) nmf$
                  , ARRAY(
            SELECT (SELECT typname
                    FROM pg_type
                    WHERE oid = (att::pg_attribute).atttypid)
            FROM unnest(fld$) att
        ) tpf$
             FROM def)
SELECT nmt
     , nmi
     , def
     , nmf$
     , tpf$
     , opc$
FROM fld
WHERE (
            'bool' = ANY (tpf$) OR
            'bool' = ANY (opc$)
    )
  AND NOT (
        ARRAY(
                SELECT nmf$[i:i + 1]::text
                FROM generate_series(1, array_length(nmf$, 1) - 1) i
            ) &&         ARRAY [ -- add exception pairs to taste
            '{leaf_pid,leaf_type}'
            ]
    )
ORDER BY 1, 2
limit 15;