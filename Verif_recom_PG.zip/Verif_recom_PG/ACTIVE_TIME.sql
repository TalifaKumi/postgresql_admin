with at_all as (
  select
    a1.sample_time::timestamptz(0) as time,
    sum(
      round(
        CAST(
          NULLIF(
            active_time / 1000 / step_time_sec :: double precision,
            0
          ) AS numeric
        ),
        2
      )
    ) AS "active_time_all_db_s/s" --, a1.step_time::interval
    --, step_time_sec
  from
    (
      SELECT
        s.sample_time :: text,
        t.server_id AS server_id,
        t.datid AS datid,
        t.datname AS dbname,
        t.sample_id,
        t.active_time,
        t.idle_in_transaction_time,
        (
          select
            sample_time
          from
            profile.samples sa
          where
            sa.server_id = t.server_id
            and sa.sample_id = (t.sample_id - 1)
        ) as previous_sample_time,
        (
          s.sample_time - (
            select
              sample_time
            from
              profile.samples sa
            where
              sa.server_id = t.server_id
              and sa.sample_id = (t.sample_id - 1)
          )
        ) as step_time,
        EXTRACT(
          EPOCH
          FROM
            s.sample_time
        ) - EXTRACT(
          EPOCH
          FROM
            (
              select
                sample_time
              from
                profile.samples sa
              where
                sa.server_id = t.server_id
                and sa.sample_id = (t.sample_id - 1)
            )
        ) as step_time_sec
      FROM
        profile.sample_stat_database t
        join profile.samples s on s.server_id = t.server_id
        and s.sample_id = t.sample_id
      where
        t.server_id = 1
      order by
        t.sample_id desc --LIMIT 700
    ) a1
  group by
    a1.sample_time::timestamptz(0)
  order by
    a1.sample_time::timestamptz(0) desc
),
at_postgres as (
  select
    a1.sample_time::timestamptz(0) as time,
    sum(
      round(
        CAST(
          NULLIF(
            active_time / 1000 / step_time_sec :: double precision,
            0
          ) AS numeric
        ),
        2
      )
    ) AS "active_time_postgres_s/s" --, a1.step_time::interval
    --, step_time_sec
  from
    (
      SELECT
        s.sample_time :: text,
        t.server_id AS server_id,
        t.datid AS datid,
        t.datname AS dbname,
        t.sample_id,
        t.active_time,
        t.idle_in_transaction_time,
        (
          select
            sample_time
          from
            profile.samples sa
          where
            sa.server_id = t.server_id
            and sa.sample_id = (t.sample_id - 1)
        ) as previous_sample_time,
        (
          s.sample_time - (
            select
              sample_time
            from
              profile.samples sa
            where
              sa.server_id = t.server_id
              and sa.sample_id = (t.sample_id - 1)
          )
        ) as step_time,
        EXTRACT(
          EPOCH
          FROM
            s.sample_time
        ) - EXTRACT(
          EPOCH
          FROM
            (
              select
                sample_time
              from
                profile.samples sa
              where
                sa.server_id = t.server_id
                and sa.sample_id = (t.sample_id - 1)
            )
        ) as step_time_sec
      FROM
        profile.sample_stat_database t
        join profile.samples s on s.server_id = t.server_id
        and s.sample_id = t.sample_id
      where
        t.server_id = 1
        and t.datname = 'postgres'
      order by
        t.sample_id desc --LIMIT 700
    ) a1
  group by
    a1.sample_time::timestamptz(0)
  order by
    a1.sample_time::timestamptz(0) desc
),
at_top_1_db as (
  select
    a1.sample_time::timestamptz(0) as time,
    sum(
      round(
        CAST(
          NULLIF(
            active_time / 1000 / step_time_sec :: double precision,
            0
          ) AS numeric
        ),
        2
      )
    ) AS "active_time_top_1_db_s/s" --, a1.step_time::interval
    --, step_time_sec
  from
    (
      SELECT
        s.sample_time :: text,
        t.server_id AS server_id,
        t.datid AS datid,
        t.datname AS dbname,
        t.sample_id,
        t.active_time,
        t.idle_in_transaction_time,
        (
          select
            sample_time
          from
            profile.samples sa
          where
            sa.server_id = t.server_id
            and sa.sample_id = (t.sample_id - 1)
        ) as previous_sample_time,
        (
          s.sample_time - (
            select
              sample_time
            from
              profile.samples sa
            where
              sa.server_id = t.server_id
              and sa.sample_id = (t.sample_id - 1)
          )
        ) as step_time,
        EXTRACT(
          EPOCH
          FROM
            s.sample_time
        ) - EXTRACT(
          EPOCH
          FROM
            (
              select
                sample_time
              from
                profile.samples sa
              where
                sa.server_id = t.server_id
                and sa.sample_id = (t.sample_id - 1)
            )
        ) as step_time_sec
      FROM
        profile.sample_stat_database t
        join profile.samples s on s.server_id = t.server_id
        and s.sample_id = t.sample_id
      where
        t.server_id = 1
        and t.datname = (
          select
            datname
          from
            (
              select
                t.datname,
                round(sum(t.active_time) / 1000) as sum_active_time
              FROM
                profile.sample_stat_database t
              group by
                t.datname
              order by
                2 desc
            )
          where
            datname <> 'postgres'
            and sum_active_time > 0
          limit
            1
        )
      order by
        t.sample_id desc --LIMIT 700
    ) a1
  group by
    a1.sample_time::timestamptz(0)
  order by
    a1.sample_time::timestamptz(0) desc
)
select
  at_all.time,
  at_all."active_time_all_db_s/s",
  at_postgres."active_time_postgres_s/s",
  at_top_1_db."active_time_top_1_db_s/s"
from
  at_all
  join at_postgres on at_all.time = at_postgres.time
  join at_top_1_db on at_all.time = at_top_1_db.time
order by at_all.time desc;