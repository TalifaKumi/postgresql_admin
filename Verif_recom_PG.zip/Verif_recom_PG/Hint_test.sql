CREATE TABLE orders_test(
    order_id int not null,
    shipping_date date not null,
    PRIMARY KEY (order_id)
);




SELECT * FROM pg_catalog.pg_class

SELECT count(*) FROM hint_plan.hints;

SELECT * FROM hint_plan.hints limit 20;

SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

Aggregate  (cost=2.49..2.50 rows=1 width=8) (actual time=0.043..0.043 rows=1 loops=1)
  ->  Index Only Scan using pg_class_relname_nsp_index on pg_class t  (cost=0.28..2.49 rows=1 width=0) (actual time=0.039..0.040 rows=1 loops=1)
        Index Cond: (relname = 'pg_type'::name)
        Heap Fetches: 1
Planning Time: 0.059 ms
Execution Time: 0.135 ms


SELECT /*+ SeqScan(t) */ count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

Aggregate  (cost=32.00..32.01 rows=1 width=8) (actual time=0.079..0.079 rows=1 loops=1)
  ->  Seq Scan on pg_class t  (cost=0.00..32.00 rows=1 width=0) (actual time=0.008..0.076 rows=1 loops=1)
        Filter: (relname = 'pg_type'::name)
        Rows Removed by Filter: 639
Planning Time: 0.077 ms
Execution Time: 0.166 ms



/*+ SeqScan(t) */ SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

 UPDATE hint_plan.hints
    SET norm_query_string = 'SELECT count(*) FROM pg_catalog.pg_class t where t.relname = ?;'
  WHERE id = 2;
COMMIT;

 DELETE FROM hint_plan.hints WHERE id = 1;
/*
INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;',
         '',
         'SeqScan(t)');
COMMIT;

SELECT count(*)
                  FROM pg_catalog.pg_class t
                  LIMIT 501
-- 1103
SELECT count(*)
                  FROM pg_catalog.pg_class t
where t.relname like '%log%'

SELECT count(*) FROM pg_catalog.pg_class t where t.relname = 'pg_type';

INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT count(*) FROM pg_catalog.pg_class t where t.relname = ''pg_type'';',
         '',
         'SeqScan(t)');
COMMIT;



EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;

INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;',
         '',
         'SeqScan(t)');
COMMIT;



INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT t.* FROM public."BIPF" t where t."CustomerID" = ?;',
         '',
         'SeqScan(t) Parallel(t 4 hard)');

 UPDATE hint_plan.hints
    SET hints = 'SeqScan(t)'
  WHERE id = 2;

 DELETE FROM hint_plan.hints
  WHERE id = 2;


 INSERT INTO hint_plan.hints(norm_query_string, application_name, hints)
     VALUES (
         'EXPLAIN (COSTS false) SELECT * FROM t1 WHERE t1.id = ?;',
         '',
         'SeqScan(t1)');
COMMIT;

-- INSERT 0 1
 UPDATE hint_plan.hints
    SET hints = 'IndexScan(t1)'
  WHERE id = 1;
 UPDATE 1
 DELETE FROM hint_plan.hints
  WHERE id = 1;
 DELETE 1


DELETE FROM hint_plan.hints WHERE ID=1;


SET pg_hint_plan.enable_hint_table TO on;

 SELECT *
from pg_catalog.pg_settings
WHERE  NAME LIKE  '%pgaudit%'
ORDER BY  1;
 */

 SELECT p.planid, count(*)  FROM pg_store_plans p  where p.queryid = '1195287729793156183'
  group by planid
  order by  2 desc;

SELECT regexp_replace(p.plan, '\d', '', 'g'), count(*)
FROM pg_store_plans p
-- where p.queryid = '1195287729793156183'
group by regexp_replace(p.plan, '\d', '', 'g')
order by 2 desc;

select count(*)
from (SELECT distinct (left(md5(regexp_replace(p.plan, '\d', '1', 'g')::text), 1000))
      FROM pg_store_plans p) a1;
-- 595

select count(*)
from (SELECT distinct (left(md5(regexp_replace(p.plan, '\d', '1', 'g')::text), 1000))
      FROM pg_store_plans p) a1;

-- where p.queryid = '1195287729793156183'
group by max(left(md5(regexp_replace(p.plan, '\d', '1', 'g')::text), 10))
order by 2 desc;


max(left(md5(regexp_replace(p.plan, '\d', '', 'g')::text), 10))


 SELECT regexp_replace(p.plan,  '\d', '1', 'g'), count(*)
 FROM pg_store_plans p  where p.queryid = '1195287729793156183'
 group by regexp_replace(p.plan,  '\d', '1', 'g');


 SELECT p.plan, count(*)  FROM pg_store_plans p  where p.queryid = '1195287729793156183'
  group by plan
  order by  2 desc;


 SELECT pg_store_plans_yamlplan(p.plan), count(*)  FROM pg_store_plans p  where p.queryid = '1195287729793156183'
  group by pg_store_plans_yamlplan(p.plan)
  order by  2 desc;


 SELECT pg_store_plans_textplan(p.plan), p.* FROM pg_store_plans p  where p.queryid = '1195287729793156183'
        -- and  calls > 1
  order by  p.userid, p.dbid, p.planid;

 SELECT s.* FROM  pg_stat_statements s  where s.queryid = '1195287729793156183';

 SELECT p.* FROM pg_store_plans p JOIN pg_stat_statements s USING (queryid)
  where p.queryid = '1195287729793156183';


 SELECT s.query, p.plan, pg_store_plans_textplan(p.plan), pg_store_plans_yamlplan(p.plan) FROM pg_store_plans p JOIN pg_stat_statements s ON (p.queryid=s.queryid and p.userid= s.userid and p.dbid=s.dbid)
  where p.queryid = '1195287729793156183';


select regexp_replace('foobarbaz', 'b..', 'X', 'g');
                                   --fooXX
select regexp_replace('fo123obarb567az', '\d', 'X', 'g');


select decode(md5(regexp_replace(p.plan, '\d', '', 'g')), 'hex'),  regexp_replace(p.plan, '\d', '', 'g')
FROM pg_store_plans p

  SELECT
    -- st.datid,
    -- st.dbname,
    -- st.userid,
    -- st.username,
    st.queryid,
    to_hex(st.queryid) AS hexqueryid,
    st.toplevel
    -- left(md5(st.userid::text || st.datid::text || st.queryid::text), 10) AS hashed_ids
FROM  pg_stat_statements st