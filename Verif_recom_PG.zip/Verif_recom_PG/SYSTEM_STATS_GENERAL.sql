\qecho '<P><A class=awr name=191></A>'
\qecho '<H2 class=awr>Системная статистика</H2>'
\qecho '<H4 class=awr>Обобщенные показатели</H4>'

\qecho '<A class=awr_ital>Скрипт SYSTEM_STATS_GENERAL.sql</A>'
\qecho '<p></p>'

\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>Oперационная система, общие характеристики.</H3>'
\qecho '<p></p>'

select oif.*, round((oif.os_up_since_seconds)/3600,2) as os_up_since_hh from pg_sys_os_info() oif;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>CPU, общие характеристики.</H3>'
\qecho '<p></p>'

select * from pg_sys_cpu_info();

\qecho '<p></p>'
\qecho '<P><A class=awr name=1811></A>'
\qecho '<H3 class=awr>Нагрузка на CPU</H3>'
\qecho '<p></p>'

select * from pg_sys_cpu_usage_info();

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Использование памяти</H3>'
\qecho '<p></p>'

select pg_size_pretty(mi.total_memory) as total_memory
       ,pg_size_pretty(used_memory) as used_memory
       ,pg_size_pretty(free_memory) as free_memory
       ,pg_size_pretty(swap_total) as swap_total
       ,pg_size_pretty(swap_used)  as swap_used
       ,pg_size_pretty(swap_free) as swap_free
       , pg_size_pretty(cache_total) as cache_total
       , kernel_total, kernel_paged, kernel_non_paged, total_page_file, avail_page_file
       from pg_sys_memory_info() mi;

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Чтения, Запись. Показатели  по дискам</H3>'
\qecho '<p></p>'

select device_name
     ,pg_size_pretty(total_reads) as total_reads
     ,pg_size_pretty(total_writes) as total_writes
     ,pg_size_pretty(read_bytes) as read_bytes
     ,pg_size_pretty(write_bytes) as write_bytes
     ,pg_size_pretty(read_time_ms) as read_time_ms
     ,pg_size_pretty(write_time_ms) as write_time_ms
from pg_sys_io_analysis_info();

\qecho '<p></p>'
\qecho '<P><A class=awr name=1812></A>'
\qecho '<H3 class=awr>Файловая система</H3>'
\qecho '<p></p>'

select mount_point
      ,file_system
      ,drive_letter
      ,drive_type
      ,file_system_type
      ,pg_size_pretty(total_space) as total_space
      ,pg_size_pretty(used_space) as used_space
      ,pg_size_pretty(free_space) as free_space
      ,total_inodes
      ,used_inodes
      ,free_inodes
    from pg_sys_disk_info();

\qecho '<p></p>'
\qecho '<P><A class=awr name=1813></A>'
\qecho '<H3 class=awr>Средняя нагрузка на интервалах времени</H3>'
\qecho '<p></p>'

select * from pg_sys_load_avg_info();

\qecho '<p></p>'
\qecho '<P><A class=awr name=1814></A>'
\qecho '<H3 class=awr>Процессы</H3>'
\qecho '<p></p>'

select * from pg_sys_process_info();

\qecho '<p></p>'
\qecho '<P><A class=awr name=1815></A>'
\qecho '<H3 class=awr>Сеть</H3>'
\qecho '<p></p>'
--\qecho '<UL>'
--\qecho '<LI class=awr>Показаны первые 10 в порядке убывания blks_read'
--\qecho '</UL>'
--\qecho '<p></p>'

select interface_name
      ,ip_address
      ,pg_size_pretty(tx_bytes) as tx_bytes
      ,pg_size_pretty(tx_packets) as tx_packets
      ,tx_errors, tx_dropped
      ,pg_size_pretty(rx_bytes) as rx_bytes
      ,pg_size_pretty(rx_packets) as rx_packets
      ,rx_errors, rx_dropped
      ,link_speed_mbps
  from pg_sys_network_info();

\qecho <P><A class=awr href="#181">Back to Системная статистика</A> <BR><A class=awr href="#top">Back to Top</A>
