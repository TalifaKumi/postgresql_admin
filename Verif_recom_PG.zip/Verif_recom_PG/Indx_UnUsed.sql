SELECT
    pg_size_pretty(pg_relation_size(ai.indexrelid)) as size_ind,
    ai.relname,
    indexrelname,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM
    pg_stat_all_indexes ai JOIN pg_index i ON i.indexrelid = ai.indexrelid
    JOIN pg_class C on c.relname = ai.relname
                           --AND C.relispartition = FALSE

WHERE
    -- Primary key cannot be partial
    NOT i.indisprimary
    -- and ai.schemaname = 'public'
    AND ai.indexrelname NOT LIKE 'pg_toast_%'
    AND ai.idx_scan = 0
    AND idx_tup_read = 0
    AND idx_tup_fetch = 0
      -- Larger than 10MB
    -- AND pg_relation_size(ai.indexrelid)>10 * 1024 ^ 2
ORDER BY
    pg_relation_size(ai.indexrelid) DESC
limit 15;





