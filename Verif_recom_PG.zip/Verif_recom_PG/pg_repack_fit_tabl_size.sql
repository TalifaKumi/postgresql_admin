/*
Определение обычных и секционированных таблиц, которые не могут быть обработаны pg_repack
попадают под  ограничение:

ERROR: relation "table" must have a primary key or not-null unique keys
The target table doesn't have a PRIMARY KEY or any UNIQUE constraints defined.

Define a PRIMARY KEY or a UNIQUE constraint on the table.

Упорядочены по  размеру
*/
START TRANSACTION;
with

tabls_comm_part as
-- Список обычных и партиционированных таблиц(не партиций)
(SELECT nspname         as "table_schema"
     , relname          AS "table_name"

     , C.relkind        AS "kind"
     , C.relispartition AS "ispartition"

FROM pg_class C
         LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
WHERE nspname NOT IN ('pg_catalog', 'information_schema')
  AND C.relkind in ('r', 'p')
  AND C.relispartition = FALSE),

tabls_unique_cnstr as
-- Таблицы, поля, на которых unique constraint
          (
          select tco.table_schema
                , tco.table_name
                --, tco.constraint_type
                , kcu.column_name as "fild_unique"
                , kcu.ordinal_position
           from information_schema.table_constraints tco
                    join information_schema.key_column_usage kcu
                         on tco.constraint_catalog = kcu.constraint_catalog
                             and tco.constraint_schema = kcu.constraint_schema
                             and tco.constraint_name = kcu.constraint_name
           where tco.table_schema not in ('pg_catalog', 'information_schema')
             and tco.constraint_type = 'UNIQUE'
           order by tco.table_schema desc,
                    tco.table_name, kcu.column_name, kcu.ordinal_position
           )  ,

 tabls_fild_is_n_null  as
-- Таблицы, поля, на которых CHECK IS NOT NULL
(select tco.table_schema,
       tco.table_name,
       replace(cc.check_clause, ' IS NOT NULL', '') as "fild_is_n_null"
from information_schema.table_constraints tco
         join information_schema.check_constraints cc on tco.constraint_catalog = cc.constraint_catalog
    and tco.constraint_schema = cc.constraint_schema
    and tco.constraint_name = cc.constraint_name
where tco.table_schema not in ('pg_catalog', 'information_schema')
  and tco.constraint_type = 'CHECK'
  and cc.check_clause like '%IS NOT NULL%'
order by tco.table_schema desc,
         tco.table_name, "fild_is_n_null"),

tabls_unique_is_n_null  as
--  Таблицы, на которых unique constraint and IS NOT NULL хотя бы на одном поле
          (select us.table_schema, us.table_name, us.fild_unique, us.ordinal_position
           from tabls_unique_cnstr us
                    join tabls_fild_is_n_null nu on
                       us.table_schema = nu.table_schema
                   and us.table_name = nu.table_name
                   and us.fild_unique = nu.fild_is_n_null
           order by us.table_schema, us.table_name, us.fild_unique, us.ordinal_position),

tabls_comm_size as
--  Обычные таблицы c подробностями по размерам
(SELECT nspname::text                                       as "table_schema"
      , relname::text                                      AS "table_name"
      , pg_size_pretty(pg_total_relation_size(C.oid))::text AS "total_size"
      , pg_total_relation_size(C.oid):: bigint        as "total_size_bt"
      , to_char(C.reltuples, '999 999 999 999')::text       AS "tuples"
    --  , C.relkind                                     AS "kind"
    --  , C.relispartition                              AS "ispartition"
 FROM pg_class C
          LEFT JOIN pg_namespace N ON (N.oid = C.relnamespace)
 WHERE nspname NOT IN ('pg_catalog', 'information_schema')
   AND C.relkind in ('r')
   AND C.relispartition = false
   -- AND nspname !~ '^pg_toast'
),

tabls_part_size as
--  Партиционированный таблицы c подробностями по размерам
    (WITH RECURSIVE
         tables AS (SELECT c.relnamespace,
                           c.oid AS parent,
                           c.oid AS relid,
                           1     AS level,
                           C.reltuples

                    FROM pg_catalog.pg_class c
                             LEFT JOIN pg_catalog.pg_inherits AS i ON c.oid = i.inhrelid
                         -- p = partitioned table, r = normal table
                    WHERE c.relkind IN ('p') -- , 'r'
                      -- not having a parent table -> we only get the partition heads
                      AND i.inhrelid IS NULL
                    UNION ALL
                    SELECT p.relnamespace,
                           p.parent    AS parent,
                           c.oid       AS relid,
                           p.level + 1 AS level,
                           p.reltuples
                    FROM tables AS p
                             LEFT JOIN pg_catalog.pg_inherits AS i ON p.relid = i.inhparent
                             LEFT JOIN pg_catalog.pg_class AS c ON c.oid = i.inhrelid AND c.relispartition
                    WHERE c.oid IS NOT NULL),
         tabls_p_by_size as
             (SELECT relnamespace,
                     parent ::REGCLASS                                  AS table_name,
                     pg_size_pretty(sum(pg_total_relation_size(relid))) AS pretty_total_size,
                     sum(pg_total_relation_size(relid))                 AS total_size_bt,
                     sum(reltuples)                                     AS tuples,
                     array_agg(relid :: REGCLASS)                       AS all_partitions
              FROM tables
              GROUP BY relnamespace, parent
              ORDER BY sum(pg_total_relation_size(relid)) DESC)

     select ns.nspname::text                            as "table_schema"
          , tp.table_name::text                         AS "table_name"
          , tp.pretty_total_size::text                  as "total_size"
          , tp.total_size_bt:: bigint
          , to_char(tp.tuples, '999 999 999 999')::text as "tuples"
          --, tp.all_partitions
     from tabls_p_by_size tp
              join pg_namespace ns
                   on tp.relnamespace = ns.oid
     order by tp.total_size_bt desc),

tabls_no_fit_pg_repack as
--  Таблицы не подходящие для pg_repack
(select * from
-- Все таблицы, кроме схем 'pg_catalog', 'information_schema'
(select t_all.table_schema,
        t_all.table_name
 from information_schema.table_constraints t_all
 where t_all.table_schema not in ('pg_catalog', 'information_schema')
 EXCEPT

-- Таблицы с PRIMARY KEY или с UNIQUE с IS NOT NULL хотя бы на одном из полей в UNIQUE
 select *
 from (select table_schema, table_name
       from tabls_unique_is_n_null
       UNION
--  Таблицы c PRIMARY KEY
       select tco.table_schema,
              tco.table_name
       from information_schema.table_constraints tco
       where tco.table_schema not in ('pg_catalog', 'information_schema')
         and tco.constraint_type = 'PRIMARY KEY') t_pk_uq_null) a3
         ),

tabls_all_size as
    (
    select * from tabls_comm_size
    union
    select * from tabls_part_size
    )

select ta.* from tabls_no_fit_pg_repack nf
 join tabls_comm_part cp on nf.table_schema=cp.table_schema and nf.table_name=cp.table_name
 join tabls_all_size ta on nf.table_schema = ta.table_schema
     and nf.table_name = ta.table_name
      where ta.total_size_bt > 8192
order by  ta.total_size_bt desc
limit 20
;
COMMIT;
