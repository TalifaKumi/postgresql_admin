\COPY public.ver_imported_pg_settings FROM example_settings_01.csv CSV HEADER;

